/* ================================================================
   AI PROMPT TEMPLATES — ai_prompt_templates.js
   Operator Training System

   ✅ Templates:
     AI_SYSTEM_PROMPT          — System prompt สำหรับ OpenAI
     buildAdaptivePrompt()     — Program prompt พร้อม fatigue context
     buildChatPrompt()         — Chat/coach prompt
     buildFatiguePrompt()      — Fatigue analysis prompt (compact)
   ================================================================ */
'use strict';

/* ----------------------------------------------------------
   FIX [CRITICAL]: Prompt Injection Sanitizer
   Strip control characters and prompt-injection patterns from user input
   before embedding into AI prompts
---------------------------------------------------------- */
function _sanitizeUserInput(str, maxLen = 300) {
  if (typeof str !== 'string') return '';
  return str
    .slice(0, maxLen)
    // Remove null bytes and non-printable ASCII control chars (except newline/tab)
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')
    // Strip common prompt injection patterns
    .replace(/ignore (previous|above|all) instructions?/gi, '[filtered]')
    .replace(/you are now|act as|pretend to be|disregard your/gi, '[filtered]')
    .replace(/system prompt|<\|.*?\|>/gi, '[filtered]')
    .trim();
}

/* ----------------------------------------------------------
   SYSTEM PROMPT — ใช้กับ OpenAI messages[system]
---------------------------------------------------------- */
const AI_SYSTEM_PROMPT = `คุณคือโค้ชฝึกทหารหน่วยรบพิเศษ (Operator Training System)
ตอบเป็นภาษาไทยเสมอ
ตอบ JSON เท่านั้น — ห้ามมีข้อความนอก JSON
ห้ามใช้ markdown fences (\`\`\`json หรือ \`\`\`)
JSON ต้องถูกต้องสมบูรณ์ — ห้ามตัดกลางคัน`;

/* ----------------------------------------------------------
   buildAdaptivePrompt — Program 7 วัน
   @param profile    { name, age, weight, height, fitness, goal }
   @param engineData { readiness, muscles, weeklyVolume, phase }
   @param equipment  string[]
   @param goal       string (custom goal)
   คืน string prompt สำหรับ Gemini (single string) หรือ user message
---------------------------------------------------------- */
function buildAdaptivePrompt(profile = {}, engineData = {}, equipment = [], goal = '') {

  const readiness    = engineData.readiness    ?? 100;
  const muscles      = engineData.muscles      ?? {};
  const weeklyVolume = engineData.weeklyVolume ?? {};
  const phase        = engineData.phase        ?? { nameTH: 'Base Building', intensity: 0.70 };

  // Fatigue per muscle (compact)
  const fatigueLines = Object.entries(muscles)
    .map(([m, v]) => `  ${m}: fatigue ${Math.round(v.fatigue ?? 0)}% ready ${Math.round(v.recovery ?? 100)}%`)
    .join('\n') || '  ปกติทุกกลุ่ม';

  // Volume this week
  const volumeLines = Object.entries(weeklyVolume)
    .filter(([, v]) => v > 0)
    .map(([m, v]) => `  ${m}: ${Math.round(v).toLocaleString()} kg`)
    .join('\n') || '  ยังไม่มี';

  // Equipment
  const eqStr = equipment.length > 0 ? equipment.join(', ') : 'Bodyweight เท่านั้น';
  const eqRule = equipment.length === 0
    ? '⚠️ ใช้ Bodyweight เท่านั้น — ห้ามแนะนำท่าที่ต้องอุปกรณ์'
    : `✅ ใช้เฉพาะ: ${eqStr} — ห้ามแนะนำท่าอื่น`;

  // Goal — FIX [CRITICAL]: sanitize user-controlled input before embedding in prompt
  const goalStr = _sanitizeUserInput(goal || profile.goal || 'สอบทหาร');
  const fitnessLabel = { beginner: 'มือใหม่', intermediate: 'ปานกลาง', advanced: 'ขั้นสูง' }[profile.fitness] || _sanitizeUserInput(profile.fitness || 'ปานกลาง', 50);

  // Adaptive intensity note
  let intensityNote = '';
  if (readiness < 40) {
    intensityNote = '🔴 Readiness ต่ำมาก — ให้ Recovery Day เป็นหลัก ลด Volume 50%';
  } else if (readiness < 60) {
    intensityNote = '🟠 Readiness ต่ำ — ลด Volume 20-30% วันนี้';
  } else if (readiness >= 80) {
    intensityNote = '🟢 Readiness ดี — ฝึกหนักได้เต็มที่';
  }

  return `ข้อมูลผู้ฝึก:
ชื่อ: ${_sanitizeUserInput(profile.name || 'Operator', 50)}
อายุ: ${profile.age || '–'} ปี | น้ำหนัก: ${profile.weight || '–'} กก. | ส่วนสูง: ${profile.height || '–'} ซม.
ระดับ: ${fitnessLabel}
เป้าหมาย: ${goalStr}
Phase ปัจจุบัน: ${phase.nameTH} (Intensity ${Math.round((phase.intensity ?? 0.7) * 100)}%)

Fatigue Analysis (Exponential Decay Engine):
Readiness โดยรวม: ${readiness}%
${intensityNote}
กล้ามเนื้อแต่ละส่วน:
${fatigueLines}

Volume สัปดาห์นี้:
${volumeLines}

สภาพแวดล้อม:
${eqRule}

เป้าหมายสอบทหาร (สำคัญ):
- Pushups สูงสุด 100 ครั้ง
- Situps สูงสุด 100 ครั้ง
- Pullups สูงสุด 25 ครั้ง
- วิ่ง 1.6 กม. เร็วที่สุด

คำสั่ง:
สร้างโปรแกรมฝึก 7 วัน โดยคำนึงถึง Fatigue ข้างต้น
กล้ามเนื้อที่ fatigue สูง (>60%) ให้พักหรือ Active Recovery เท่านั้น
ระบุ sets และ reps ทุกท่า

ตอบ JSON เท่านั้น — ไม่มีข้อความอื่น:
{
  "monday":    [{"name":"ชื่อท่า","sets":3,"reps":"15","rest":"60s","tips":""}],
  "tuesday":   [...],
  "wednesday": [...],
  "thursday":  [...],
  "friday":    [...],
  "saturday":  [...],
  "sunday":    [{"name":"พัก","sets":1,"reps":"rest","rest":"–","tips":""}]
}`;
}

/* ----------------------------------------------------------
   buildChatPrompt — สำหรับ AI Coach Chat
   @param systemContext  string (buildSystemPrompt จาก app.js)
   @param userMsg        string
   คืน string รวมสำหรับ Gemini
---------------------------------------------------------- */
function buildChatPrompt(systemContext = '', userMsg = '') {
  // FIX [CRITICAL]: sanitize user message to prevent prompt injection
  const safeMsg = _sanitizeUserInput(userMsg, 500);
  return `${systemContext}

---
คำถามจากผู้ฝึก: ${safeMsg}

ตอบภาษาไทย กระชับ ให้กำลังใจ ใช้ emoji อ่านง่าย
ถ้าแนะนำท่า ให้ระบุ sets/reps ด้วย`;
}

/* ----------------------------------------------------------
   buildFatiguePrompt — สำหรับวิเคราะห์ fatigue ก่อนสร้างโปรแกรม
   ออกแบบให้สั้น maxTokens=150 พอ
   @param engineData { readiness, muscles, phase }
   คืน string prompt
---------------------------------------------------------- */
function buildFatiguePrompt(engineData = {}) {
  const readiness = engineData.readiness ?? 100;
  const muscles   = engineData.muscles   ?? {};
  const phase     = engineData.phase     ?? { nameTH: 'Base Building' };

  const fatigued = Object.entries(muscles)
    .filter(([, v]) => (v.fatigue ?? 0) > 40)
    .map(([m, v]) => `${m}(${Math.round(v.fatigue ?? 0)}%)`)
    .join(', ') || 'ไม่มี';

  const ready = Object.entries(muscles)
    .filter(([, v]) => (v.fatigue ?? 0) <= 40)
    .map(([m]) => m)
    .join(', ') || 'ทุกกลุ่ม';

  return `Readiness: ${readiness}% | Phase: ${phase.nameTH}
กล้ามเนื้อล้า: ${fatigued}
กล้ามเนื้อพร้อม: ${ready}

ในไม่เกิน 2 บรรทัด: ควรเพิ่มหรือลด volume และ ควรเน้นกล้ามเนื้อไหน?
ตอบภาษาไทย กระชับ emoji`;
}

window.AI_SYSTEM_PROMPT      = AI_SYSTEM_PROMPT;
window.buildAdaptivePrompt   = buildAdaptivePrompt;
window.buildChatPrompt       = buildChatPrompt;
window.buildFatiguePrompt    = buildFatiguePrompt;

console.log('%c[AIPromptTemplates] Loaded', 'color:#78cc55');
