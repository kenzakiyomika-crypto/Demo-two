/* ================================================================
   HYBRID AI ENGINE — ai_hybrid_engine.js
   Operator Training System — หัวใจระบบ AI ทั้งหมด

   ✅ Flow:
     1. Readiness < 40%     → LocalAI (บังคับพัก)
     2. ไม่มี API Key        → LocalAI
     3. เกิน daily limit     → LocalAI + แจ้ง
     4. มี cache             → return cache ทันที
     5. เรียก API (+ timeout)
        ✓ parse JSON valid   → cache + return
        ✗ JSON invalid       → retry LocalAI
        ✗ throw              → LocalAI + แสดง error

   ✅ Override:
     window.generateAIProgram — เรียกจาก HTML/app_patches.js
     window.generateHybridProgram — expose สำหรับ direct call
     window.aiAdjustBeforeGenerate — override engine.js version พร้อม cache
   ================================================================ */
'use strict';

/* ============================================================
   CONFIG
============================================================ */
const HYBRID_CONFIG = {
  PROGRAM_DAILY_LIMIT:  5,   // จำนวน AI calls สำหรับ program/วัน
  CHAT_DAILY_LIMIT:     15,  // สำหรับ chat/วัน
  FATIGUE_DAILY_LIMIT:  10,  // สำหรับ fatigue analysis/วัน
  CACHE_TTL_MS:         6 * 60 * 60 * 1000,  // 6 ชั่วโมง
  MIN_READINESS_FOR_AI: 40,  // ต่ำกว่านี้ → LocalAI
};

/* ============================================================
   INTERNAL HELPERS
============================================================ */

function _getEngineSnapshot() {
  const OE = window.OPERATOR_ENGINE;
  if (!OE) return { readiness: 100, fatigue: {}, weeklyVolume: {}, muscles: {}, phase: null };

  const analytics = typeof OE.getAnalytics === 'function' ? OE.getAnalytics() : {};
  return {
    readiness:    analytics.readiness    ?? Math.round(OE.state?.readiness ?? 100),
    fatigue:      OE.state?.fatigue      ?? {},
    weeklyVolume: OE.state?.weeklyVolume ?? {},
    muscles:      analytics.muscles      ?? {},
    phase:        typeof OE.getCurrentPhase === 'function' ? OE.getCurrentPhase() : null,
    weekNumber:   OE.state?.weekNumber   ?? 1,
  };
}

function _safeGetProfile()    { return typeof getProfile    === 'function' ? getProfile()    : {}; }
function _safeGetEquipment()  { return typeof getEquipment  === 'function' ? getEquipment()  : []; }
function _safeGetCustomGoal() { return typeof getCustomGoal === 'function' ? getCustomGoal() : ''; }
function _safeGetProvider()   { return typeof getProvider   === 'function' ? getProvider()   : 'openai'; }
function _safeGetActiveKey()  { return typeof getActiveKey  === 'function' ? getActiveKey()  : ''; }
function _safeShowToast(msg)  { if (typeof showToast === 'function') showToast(msg); }

/* ============================================================
   renderHybridProgramResult — render JSON program สู่ DOM
   รองรับทั้ง JSON object (new) และ text ดิบ (legacy)
============================================================ */
function renderHybridProgramResult(program) {
  const container = document.getElementById('program-content');
  if (!container) return;

  // ถ้าเป็น object (JSON) → render structured
  if (program && typeof program === 'object' && !Array.isArray(program)) {
    const DAY_TH = {
      monday:    '📅 วันจันทร์',
      tuesday:   '📅 วันอังคาร',
      wednesday: '📅 วันพุธ',
      thursday:  '📅 วันพฤหัสบดี',
      friday:    '📅 วันศุกร์',
      saturday:  '📅 วันเสาร์',
      sunday:    '💤 วันอาทิตย์',
    };
    const TYPE_EMOJI = {
      push: '💪', pull: '🔝', run: '🏃', core: '🎯',
      fullbody: '🔥', recovery: '💤', rest: '💤',
    };

    const eq  = _safeGetEquipment();
    const loc = typeof getTrainLocation === 'function' ? getTrainLocation() : 'บ้าน';

    let html = `<div class="ai-program-result">
      <div class="ai-program-meta">
        <span>📍 ${loc}</span>
        <span>🛠️ ${eq.length ? eq.join(' · ') : 'Bodyweight'}</span>
      </div>`;

    Object.entries(DAY_TH).forEach(([day, label]) => {
      const exercises = program[day];
      if (!exercises || !exercises.length) return;

      const firstEx = exercises[0]?.name?.toLowerCase() || '';
      const typeEmoji = /push|วิด/.test(firstEx)  ? TYPE_EMOJI.push
                      : /pull|ดึง/.test(firstEx)  ? TYPE_EMOJI.pull
                      : /run|วิ่ง|sprint/.test(firstEx) ? TYPE_EMOJI.run
                      : /sit|plank|leg|core|russian/.test(firstEx) ? TYPE_EMOJI.core
                      : /พัก|walk|เดิน|stretch|recovery/.test(firstEx) ? TYPE_EMOJI.recovery
                      : '📅';

      html += `<div class="program-day-card">
        <div class="program-day-header">
          <div class="program-day-name">${typeEmoji} ${label}</div>
        </div>
        <div class="program-exercises">`;

      exercises.forEach((ex, idx) => {
        const setsReps = ex.sets && ex.reps
          ? `${ex.sets} เซต × ${ex.reps}${ex.rest && ex.rest !== '–' ? ` · พัก ${ex.rest}` : ''}`
          : (ex.reps || '');
        html += `<div class="program-ex-item">
          <div class="program-ex-num">${idx + 1}</div>
          <div>
            <div class="program-ex-name">${ex.name || '–'}</div>
            <div class="program-ex-detail">${setsReps}</div>
            ${ex.tips ? `<div style="font-size:11px;color:#6a6a70;margin-top:2px">💡 ${ex.tips}</div>` : ''}
          </div>
        </div>`;
      });

      html += `</div></div>`;
    });

    const provider  = _safeGetProvider();
    const modelName = localStorage.getItem('gemini_model') || 'gemini-1.5-flash';
    const source    = (typeof window._lastProgramSource !== 'undefined')
      ? window._lastProgramSource
      : (provider === 'gemini' ? modelName : 'GPT-4o-mini');

    html += `<div class="ai-program-footer">✨ สร้างโดย ${source} · บันทึกแล้ว</div></div>`;
    container.innerHTML = html;
    return;
  }

  // Legacy: text ดิบ → ใช้ renderAIProgramResult เดิม
  if (typeof renderAIProgramResult === 'function') {
    renderAIProgramResult(program);
  }
}

/* ============================================================
   generateHybridProgram — MAIN FUNCTION
   @returns object program JSON { monday:[], ... }
============================================================ */
async function generateHybridProgram() {

  const profile    = _safeGetProfile();
  const engineData = _getEngineSnapshot();
  const equipment  = _safeGetEquipment();
  const goal       = _safeGetCustomGoal();
  const provider   = _safeGetProvider();
  const apiKey     = _safeGetActiveKey();

  window._lastProgramSource = 'Local AI';

  /* --- 1. Readiness ต่ำมาก → LocalAI พัก --- */
  if (engineData.readiness < HYBRID_CONFIG.MIN_READINESS_FOR_AI) {
    console.log('[HybridAI] Low readiness → LocalAI');
    _safeShowToast(`🔴 Readiness ${engineData.readiness}% ต่ำมาก — ใช้โปรแกรมพักฟื้น`);
    return LocalAI.generate(profile, engineData, equipment);
  }

  /* --- 2. ไม่มี API Key → LocalAI --- */
  if (!apiKey || apiKey.length < 10) {
    console.log('[HybridAI] No API key → LocalAI');
    return LocalAI.generate(profile, engineData, equipment);
  }

  /* --- 3. Cache check (ก่อน daily limit — cache hit ไม่กิน quota) --- */
  const prompt   = (typeof buildAdaptivePrompt === 'function')
    ? buildAdaptivePrompt(profile, engineData, equipment, goal)
    : JSON.stringify({ profile, engineData, equipment, goal });

  const cacheKey = AIUtils.hash(prompt);
  const cached   = AIUtils.getCache(cacheKey, HYBRID_CONFIG.CACHE_TTL_MS);

  if (cached && AIUtils.validateProgram(cached)) {
    console.log('[HybridAI] Cache hit → returning cached program (no quota used)');
    window._lastProgramSource = '⚡ Cache';
    return cached;
  }

  /* --- 4. Daily limit (หลัง cache — เฉพาะตอนต้องเรียก API จริง) --- */
  const limitCheck = AIUtils.checkDailyLimit(HYBRID_CONFIG.PROGRAM_DAILY_LIMIT, 'program');
  if (!limitCheck.allowed) {
    console.log('[HybridAI] Daily limit reached → LocalAI');
    _safeShowToast(`📊 ใช้ AI ครบ ${HYBRID_CONFIG.PROGRAM_DAILY_LIMIT} ครั้งแล้ววันนี้ — ใช้ Local AI แทน`);
    return LocalAI.generate(profile, engineData, equipment);
  }

  /* --- 5. API Call --- */
  try {
    let raw;

    if (provider === 'gemini') {
      raw = await askGeminiRaw(prompt, apiKey, 450);
      window._lastProgramSource = localStorage.getItem('gemini_model') || 'gemini-1.5-flash';
    } else {
      const systemPrompt = (typeof AI_SYSTEM_PROMPT !== 'undefined') ? AI_SYSTEM_PROMPT : 'ตอบ JSON เท่านั้น';
      raw = await askOpenAIRaw([
        { role: 'system', content: systemPrompt },
        { role: 'user',   content: prompt },
      ], apiKey, 450);
      window._lastProgramSource = 'GPT-4o-mini';
    }

    /* --- null = _geminiCalling guard blocked --- */
    if (raw === null) {
      _safeShowToast('⏳ AI ยังไม่ว่าง — ใช้ Local AI แทน');
      return LocalAI.generate(profile, engineData, equipment);
    }

    /* --- Parse JSON --- */
    const parsed = AIUtils.parseJSONSafe(raw);

    if (!parsed || !AIUtils.validateProgram(parsed)) {
      console.warn('[HybridAI] Invalid JSON from AI → LocalAI fallback');
      console.debug('[HybridAI] Raw response:', raw?.slice(0, 200));
      _safeShowToast('📋 AI ตอบผิด Format — ใช้ Local AI แทน');
      return LocalAI.generate(profile, engineData, equipment);
    }

    /* --- Cache & return --- */
    AIUtils.setCache(cacheKey, parsed);
    _safeShowToast(`✅ สร้างโปรแกรมสำเร็จ (เหลือ ${limitCheck.remaining} ครั้งวันนี้)`);
    return parsed;

  } catch (err) {
    console.error('[HybridAI] API error:', err.message);
    const errMsg = (typeof AIUtils !== 'undefined')
      ? AIUtils.formatError(err)
      : ('⚠️ ' + err.message);

    _safeShowToast(errMsg.split('\n')[0]); // แสดงแค่บรรทัดแรก
    return LocalAI.generate(profile, engineData, equipment);
  }
}

/* ============================================================
   aiAdjustBeforeGenerate — Override engine.js version
   เพิ่ม cache + ใช้ buildFatiguePrompt
============================================================ */
async function aiAdjustBeforeGenerateHybrid() {
  const engineData = _getEngineSnapshot();
  const readiness  = engineData.readiness;
  const rlObj      = window.OPERATOR_ENGINE?.getReadinessLabel?.()
    ?? { label: '–', color: '#aaa', advice: '' };

  // Base analysis (ไม่ต้อง API)
  const baseAnalysis = `📊 Readiness: ${readiness}%  ${rlObj.label}\n💡 ${rlObj.advice}`;

  const apiKey = _safeGetActiveKey();
  if (!apiKey || apiKey.length < 10) return baseAnalysis;

  // Daily limit (แยก quota จาก program)
  const limitCheck = AIUtils.checkDailyLimit(HYBRID_CONFIG.FATIGUE_DAILY_LIMIT, 'analyze');
  if (!limitCheck.allowed) return baseAnalysis + '\n(Fatigue AI limit reached)';

  // Prompt + cache
  const prompt   = (typeof buildFatiguePrompt === 'function')
    ? buildFatiguePrompt(engineData)
    : `Readiness ${readiness}%`;

  const cacheKey = 'fatigue_' + AIUtils.hash(prompt);
  const cached   = AIUtils.getCache(cacheKey, 30 * 60 * 1000); // 30 นาที
  if (cached && typeof cached === 'string') return cached;

  try {
    const provider = _safeGetProvider();
    let advice = '';

    if (provider === 'gemini') {
      advice = await askGeminiRaw(prompt, apiKey, 150);
    } else {
      advice = await askOpenAIRaw([
        { role: 'system', content: 'คุณคือโค้ชทหาร วิเคราะห์ฟิตเนสสั้นกระชับ ภาษาไทย' },
        { role: 'user',   content: prompt },
      ], apiKey, 150);
    }

    if (!advice) return baseAnalysis;

    const result = baseAnalysis + '\n\n' + advice;
    AIUtils.setCache(cacheKey, result);
    return result;

  } catch (err) {
    console.warn('[HybridAI] Fatigue analysis failed:', err.message);
    return baseAnalysis;
  }
}

/* ============================================================
   generateAIProgram — Main entry point (ถูกเรียกจาก HTML)
   Override app_patches.js + app.js versions
============================================================ */
window.generateAIProgram = async function generateAIProgram() {

  const btn       = document.getElementById('ai-gen-btn');
  const container = document.getElementById('program-content');
  const goalEl    = document.getElementById('custom-goal-input');

  if (goalEl?.value?.trim() && typeof setCustomGoal === 'function') {
    setCustomGoal(goalEl.value.trim());
  }

  // Guard: ป้องกันกดซ้ำ
  if (window._aiProgramCalling) {
    _safeShowToast('⏳ AI กำลังสร้างโปรแกรมอยู่ รอสักครู่...');
    return;
  }
  window._aiProgramCalling = true;

  if (btn) { btn.disabled = true; btn.textContent = '⏳ กำลังวิเคราะห์...'; }
  if (container) {
    container.innerHTML = `<div class="ai-loading">
      <div class="ai-loading-dots"><span></span><span></span><span></span></div>
      <div>🔍 วิเคราะห์ Fatigue ก่อนสร้างโปรแกรม...</div></div>`;
  }

  try {
    /* Step 1: Fatigue analysis (compact) */
    const fatigueAnalysis = await aiAdjustBeforeGenerateHybrid();

    if (container && fatigueAnalysis) {
      container.innerHTML = `
        <div class="fatigue-analysis-banner">
          <div class="fab-title">🤖 AI วิเคราะห์ Fatigue</div>
          <div class="fab-body" style="white-space:pre-wrap">${fatigueAnalysis}</div>
        </div>
        <div class="ai-loading">
          <div class="ai-loading-dots"><span></span><span></span><span></span></div>
          <div>AI กำลังออกแบบโปรแกรม...</div></div>`;
    }

    if (btn) btn.textContent = '⏳ กำลังสร้าง...';

    /* Step 2: Generate program */
    const program = await generateHybridProgram();

    /* Step 3: Validate */
    if (!program || typeof program !== 'object') {
      throw new Error('Program generation returned invalid data');
    }

    /* Step 4: Save + Render */
    // บันทึกทั้ง JSON (ใหม่) และ raw string (legacy compat)
    localStorage.setItem('weekly_program', JSON.stringify(program));
    if (typeof LS === 'object') LS.set('aiProgram', program);

    renderHybridProgramResult(program);

    // แสดง fatigue banner บน program ด้วย
    const pc = document.getElementById('program-content');
    if (pc && fatigueAnalysis && window._lastProgramSource !== '⚡ Cache') {
      const banner = document.createElement('div');
      banner.className = 'fatigue-analysis-banner';
      banner.innerHTML = `<div class="fab-title">🤖 Fatigue Analysis</div>
        <div class="fab-body" style="white-space:pre-wrap;font-size:12px">${fatigueAnalysis}</div>`;
      pc.insertBefore(banner, pc.firstChild);
    }

    if (typeof updateEquipmentSummary === 'function') updateEquipmentSummary();

  } catch (err) {
    console.error('[generateAIProgram] Error:', err);
    _safeShowToast('⚠️ เกิดข้อผิดพลาด — ใช้โปรแกรมพื้นฐานแทน');
    if (typeof generateLocalProgram === 'function') generateLocalProgram();
  } finally {
    window._aiProgramCalling = false;
    if (btn) { btn.disabled = false; btn.textContent = '✨ ให้ AI สร้างโปรแกรม'; }
  }
};

/* ============================================================
   Override aiAdjustBeforeGenerate (engine.js + app.js versions)
============================================================ */
window.aiAdjustBeforeGenerate = aiAdjustBeforeGenerateHybrid;

/* ============================================================
   restoreOrRenderProgram — override app.js version
   รองรับทั้ง JSON ใหม่และ text เดิม
============================================================ */
const _originalRestoreOrRender = window.restoreOrRenderProgram;
window.restoreOrRenderProgram = function restoreOrRenderProgramHybrid() {
  const saved = localStorage.getItem('weekly_program');
  if (!saved) {
    if (typeof renderProgram === 'function') renderProgram();
    return;
  }

  // ลองอ่านเป็น JSON ก่อน
  const parsed = AIUtils.parseJSONSafe(saved);
  if (parsed && AIUtils.validateProgram(parsed)) {
    window._lastProgramSource = '⚡ Saved';
    renderHybridProgramResult(parsed);
    return;
  }

  // Legacy: text ดิบ
  if (typeof renderAIProgramResult === 'function') {
    renderAIProgramResult(saved);
    return;
  }

  if (typeof renderProgram === 'function') renderProgram();
};

/* ============================================================
   Expose
============================================================ */
/* ============================================================
   Expose
============================================================ */
window.generateHybridProgram        = generateHybridProgram;
window.renderHybridProgramResult    = renderHybridProgramResult;
window.aiAdjustBeforeGenerateHybrid = aiAdjustBeforeGenerateHybrid;

// [CRITICAL] late-binding: app.js stub เรียก window._hybridGenerateAIProgram
// เพราะ function declarations ใน app.js จะ overwrite window.generateAIProgram
window._hybridGenerateAIProgram = window.generateAIProgram;

console.log('%c[HybridAI] Loaded — Adaptive + Hybrid + Fail-safe + Cache + Daily Limit', 'color:#78cc55;font-weight:bold');
