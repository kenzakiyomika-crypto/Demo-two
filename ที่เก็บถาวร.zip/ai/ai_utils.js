/* ================================================================
   AI UTILS — ai_utils.js
   Operator Training System — AI Helper Utilities

   ✅ Functions:
     sanitize()        — ลบ markdown fences ออกจาก AI response
     parseJSONSafe()   — parse JSON อย่างปลอดภัย
     hash()            — สร้าง cache key จาก prompt string
     checkDailyLimit() — จำกัดการใช้รายวัน (สายฟรี)
     getCache()        — อ่าน cache ถ้ามี
     setCache()        — บันทึก cache
     clearOldCaches()  — ลบ cache เก่า (> 24 ชั่วโมง)
     formatError()     — แปลง error เป็น message ภาษาไทย
   ================================================================ */
'use strict';

const AIUtils = {

  /* ----------------------------------------------------------
     sanitize — ลบ markdown code fences และ whitespace
     รองรับ: ```json, ```, and leading/trailing spaces
  ---------------------------------------------------------- */
  sanitize(text = '') {
    return text
      .replace(/```json\s*/gi, '')
      .replace(/```\s*/g, '')
      .replace(/^\s+|\s+$/g, '')
      .trim();
  },

  /* ----------------------------------------------------------
     parseJSONSafe — parse JSON โดยไม่ throw
     คืน object ถ้า parse ได้ / null ถ้าพัง
  ---------------------------------------------------------- */
  parseJSONSafe(text) {
    if (!text || typeof text !== 'string') return null;
    try {
      const clean = this.sanitize(text);
      const parsed = JSON.parse(clean);
      // ต้องเป็น object ไม่ใช่ primitive
      if (typeof parsed !== 'object' || parsed === null) return null;
      return parsed;
    } catch {
      return null;
    }
  },

  /* ----------------------------------------------------------
     hash — djb2-style hash สำหรับ cache key
     คืน string เช่น "h1234567890"
  ---------------------------------------------------------- */
  hash(str = '') {
    let h = 0;
    for (let i = 0; i < str.length; i++) {
      h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
    }
    return 'h' + Math.abs(h);
  },

  /* ----------------------------------------------------------
     checkDailyLimit — ตรวจและนับการใช้รายวัน
     @param limit  จำนวนครั้งสูงสุด/วัน (default 5)
     @param type   ประเภทการใช้: 'program' | 'chat' | 'analyze'
     คืน { allowed: bool, remaining: number, total: number }
  ---------------------------------------------------------- */
  checkDailyLimit(limit = 5, type = 'program') {
    const today = new Date().toDateString();
    let data = {};
    try {
      data = JSON.parse(localStorage.getItem('ai_usage') || '{}');
    } catch { data = {}; }

    // รีเซ็ตถ้าเป็นวันใหม่
    if (data.date !== today) {
      data = { date: today, program: 0, chat: 0, analyze: 0 };
    }

    const current = data[type] ?? 0;

    if (current >= limit) {
      return { allowed: false, remaining: 0, total: current };
    }

    data[type] = current + 1;
    try {
      localStorage.setItem('ai_usage', JSON.stringify(data));
    } catch {}

    return { allowed: true, remaining: limit - data[type], total: data[type] };
  },

  /* ----------------------------------------------------------
     getRemainingCalls — ดูว่าเหลือกี่ครั้ง (ไม่นับ)
  ---------------------------------------------------------- */
  getRemainingCalls(limit = 5, type = 'program') {
    const today = new Date().toDateString();
    let data = {};
    try {
      data = JSON.parse(localStorage.getItem('ai_usage') || '{}');
    } catch { data = {}; }

    if (data.date !== today) return limit;
    return Math.max(0, limit - (data[type] ?? 0));
  },

  /* ----------------------------------------------------------
     getCache — อ่าน cache จาก localStorage
     คืน object ถ้ายังไม่หมดอายุ / null ถ้าหมดหรือไม่มี
     @param ttlMs  อายุ cache ใน ms (default 6 ชั่วโมง)
  ---------------------------------------------------------- */
  getCache(key, ttlMs = 6 * 60 * 60 * 1000) {
    try {
      const raw = localStorage.getItem('ai_cache_' + key);
      if (!raw) return null;
      const entry = JSON.parse(raw);
      if (!entry || !entry.ts || !entry.data) return null;
      if (Date.now() - entry.ts > ttlMs) {
        localStorage.removeItem('ai_cache_' + key);
        return null;
      }
      return entry.data;
    } catch {
      return null;
    }
  },

  /* ----------------------------------------------------------
     setCache — บันทึก cache พร้อม timestamp
  ---------------------------------------------------------- */
  setCache(key, data) {
    try {
      localStorage.setItem('ai_cache_' + key, JSON.stringify({
        ts:   Date.now(),
        data: data,
      }));
    } catch {
      // localStorage เต็ม → ลบ cache เก่าก่อน
      this.clearOldCaches();
    }
  },

  /* ----------------------------------------------------------
     clearOldCaches — ลบ cache ที่เก่ากว่า 24 ชั่วโมง
  ---------------------------------------------------------- */
  clearOldCaches() {
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;
    const toDelete = [];
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!k?.startsWith('ai_cache_')) continue;
        const raw = localStorage.getItem(k);
        if (!raw) continue;
        const entry = JSON.parse(raw);
        if (!entry?.ts || entry.ts < cutoff) {
          toDelete.push(k);
        }
      }
      toDelete.forEach(k => localStorage.removeItem(k));
      if (toDelete.length > 0) {
        console.log(`[AIUtils] Cleared ${toDelete.length} old cache(s)`);
      }
    } catch {}
  },

  /* ----------------------------------------------------------
     formatError — แปลง error เป็น message ภาษาไทยที่ user-friendly
  ---------------------------------------------------------- */
  formatError(err) {
    const msg = err?.message || String(err) || '';

    if (err?.name === 'AbortError' || msg.includes('abort')) {
      return '⏱️ AI ตอบช้าเกิน 20 วินาที — ลองใหม่อีกครั้ง';
    }
    if (msg.includes('429') || msg.toLowerCase().includes('quota') || msg.toLowerCase().includes('rate')) {
      return '⚠️ Quota หมด!\n💡 วิธีแก้:\n• รอ 1 นาทีแล้วลองใหม่\n• ลดความถี่การใช้\n• หรือเปลี่ยนไปใช้ OpenAI';
    }
    if (msg.includes('401') || msg.toLowerCase().includes('invalid') || msg.toLowerCase().includes('key')) {
      return '🔑 API Key ไม่ถูกต้อง — ตรวจสอบที่หน้าตั้งค่า';
    }
    if (msg.includes('403')) {
      return '🚫 API Key ไม่มีสิทธิ์ใช้งาน — ตรวจสอบ billing';
    }
    if (msg.includes('500') || msg.includes('503')) {
      return '🔧 Server AI มีปัญหา — ลองใหม่อีกครั้งในไม่ช้า';
    }
    if (msg.toLowerCase().includes('network') || msg.toLowerCase().includes('fetch')) {
      return '📡 ไม่มีอินเทอร์เน็ต — ใช้ Local AI แทน';
    }
    if (msg.toLowerCase().includes('json') || msg.toLowerCase().includes('invalid')) {
      return '📋 AI ตอบผิด Format — ใช้ Local AI แทน';
    }
    return '⚠️ AI ตอบไม่ได้: ' + (msg.slice(0, 60) || 'unknown error');
  },

  /* ----------------------------------------------------------
     validateProgram — ตรวจ program JSON ว่าถูก format หรือเปล่า
     คืน true ถ้า valid
  ---------------------------------------------------------- */
  validateProgram(program) {
    if (!program || typeof program !== 'object') return false;
    const days = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
    const hasAtLeastOneDay = days.some(d =>
      Array.isArray(program[d]) && program[d].length > 0
    );
    return hasAtLeastOneDay;
  },

  /* ----------------------------------------------------------
     validateExercise — ตรวจ exercise object
  ---------------------------------------------------------- */
  validateExercise(ex) {
    if (!ex || typeof ex !== 'object') return false;
    return typeof ex.name === 'string' && ex.name.length > 0;
  },
};

window.AIUtils = AIUtils;

// Auto-clean old caches on load (once per session)
try { AIUtils.clearOldCaches(); } catch {}

console.log('%c[AIUtils] Loaded', 'color:#78cc55');
