/* ================================================================
   AI PROVIDERS — ai_providers.js
   Operator Training System — Production API Callers

   ✅ Features:
     • AbortController + 20s timeout ทุก request
     • Retry ครั้งเดียวอัตโนมัติถ้า network error
     • Error normalize ผ่าน AIUtils.formatError
     • Override window.askGeminiRaw + window.askOpenAIRaw เดิม
       เพื่อ backward-compat กับ app.js ที่ยังเรียกตรง
     • _geminiCalling guard ยังคงอยู่ (ผสานกับของเดิม)
   ================================================================ */
'use strict';

const AI_TIMEOUT_MS = 20_000; // 20 วินาที

/* ============================================================
   INTERNAL: fetchWithTimeout
   wrapper รอบ fetch + AbortController
   @param url      string
   @param options  RequestInit
   @param timeoutMs number
============================================================ */
async function _fetchWithTimeout(url, options, timeoutMs = AI_TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(url, { ...options, signal: controller.signal });
    return res;
  } finally {
    clearTimeout(timer);
  }
}

/* ============================================================
   INTERNAL: retry helper
   retry 1 ครั้ง เฉพาะ network drop (TypeError)
   ❌ ไม่ retry AbortError — นั่นคือ timeout ที่ตั้งใจ
   ❌ ไม่ retry 4xx/5xx — server บอกว่าผิดชัดเจน
============================================================ */
async function _withRetry(fn, retries = 1) {
  try {
    return await fn();
  } catch (err) {
    // retry เฉพาะ TypeError = network drop / DNS fail
    // ห้าม retry AbortError (= timeout ที่ตั้งใจ) หรือ HTTP errors
    if (retries > 0 && err.name === 'TypeError' && !err.message?.includes('abort')) {
      console.warn('[AIProviders] Network drop — retrying in 1.5s:', err.message);
      await new Promise(r => setTimeout(r, 1500));
      return _withRetry(fn, retries - 1);
    }
    throw err;
  }
}

/* ============================================================
   askGeminiRaw — Production Gemini API caller
   Override window.askGeminiRaw ของ app.js เดิม

   @param prompt     string   prompt รวม (system+user สำหรับ Gemini)
   @param apiKey     string
   @param maxTokens  number   (default 450)
   @returns string | null (null = guard blocked)
============================================================ */

// _geminiCalling ถ้ายังไม่ได้ประกาศ (เผื่อ app.js โหลดทีหลัง)
if (typeof window._geminiCalling === 'undefined') {
  window._geminiCalling = false;
}

async function askGeminiRaw(prompt, apiKey, maxTokens = 450) {

  // Guard: ป้องกัน concurrent calls
  if (window._geminiCalling) {
    console.warn('[askGeminiRaw] Blocked — previous call in progress');
    return null;
  }
  window._geminiCalling = true;

  const model = localStorage.getItem('gemini_model') || 'gemini-1.5-flash';
  const url   = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  try {
    const res = await _withRetry(() => _fetchWithTimeout(url, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: {
          maxOutputTokens: maxTokens,
          temperature:     0.7,
        },
      }),
    }));

    if (!res.ok) {
      const hint = {
        400: 'Request ไม่ถูกต้อง',
        401: 'API Key ไม่ถูกต้อง',
        403: 'API Key ไม่มีสิทธิ์',
        429: 'เกิน quota',
        500: 'Gemini server error',
        503: 'Gemini unavailable',
      }[res.status] || `HTTP ${res.status}`;
      throw new Error(`Gemini Error: ${hint}`);
    }

    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!text) {
      const reason = data?.candidates?.[0]?.finishReason;
      if (reason === 'SAFETY') throw new Error('Gemini บล็อก content: safety filter');
      if (reason === 'MAX_TOKENS') throw new Error('Gemini ตอบครึ่งคัน: MAX_TOKENS');
      throw new Error('Gemini ตอบกลับว่างเปล่า');
    }

    return text;

  } catch (err) {
    // re-throw ด้วย formatted message
    throw new Error(
      (typeof AIUtils !== 'undefined')
        ? AIUtils.formatError(err)
        : err.message
    );
  } finally {
    window._geminiCalling = false;
  }
}

/* ============================================================
   askOpenAIRaw — Production OpenAI API caller
   Override window.askOpenAIRaw ของ app.js เดิม

   @param messages   {role, content}[]
   @param apiKey     string
   @param maxTokens  number (default 450)
   @returns string
============================================================ */
async function askOpenAIRaw(messages, apiKey, maxTokens = 450) {

  const model = localStorage.getItem('openai_model') || 'gpt-4o-mini';

  try {
    const res = await _withRetry(() => _fetchWithTimeout(
      'https://api.openai.com/v1/chat/completions',
      {
        method:  'POST',
        headers: {
          'Content-Type':  'application/json',
          'Authorization': 'Bearer ' + apiKey,
        },
        body: JSON.stringify({
          model,
          messages,
          temperature: 0.7,
          max_tokens:  maxTokens,
        }),
      }
    ));

    if (!res.ok) {
      const hint = {
        400: 'Request ไม่ถูกต้อง',
        401: 'API Key ไม่ถูกต้อง',
        403: 'ไม่มีสิทธิ์',
        429: 'Rate limit / quota หมด',
        500: 'OpenAI server error',
        503: 'OpenAI unavailable',
      }[res.status] || `HTTP ${res.status}`;
      throw new Error(`OpenAI Error: ${hint}`);
    }

    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content;

    if (!text) throw new Error('OpenAI ตอบกลับว่างเปล่า');

    return text;

  } catch (err) {
    throw new Error(
      (typeof AIUtils !== 'undefined')
        ? AIUtils.formatError(err)
        : err.message
    );
  }
}

/* ============================================================
   Export — override ของเดิม + expose ใหม่
============================================================ */
window.askGeminiRaw  = askGeminiRaw;
window.askOpenAIRaw  = askOpenAIRaw;

// marker ให้ app.js รู้ว่า providers โหลดแล้ว — ห้าม overwrite
window.askGeminiRaw._fromProviders  = true;
window.askOpenAIRaw._fromProviders  = true;

// expose internals สำหรับ debug
window._AIProviders = { _fetchWithTimeout, _withRetry };

console.log('%c[AIProviders] Loaded — Gemini + OpenAI with timeout & retry', 'color:#78cc55');
