/* ================================================================
   LOCAL AI ENGINE v2 — ai/ai_local_engine.js
   Tactical Adaptive Training OS

   UPGRADE จาก v1 template-based → Full Engine Stack
   ใช้ DecisionEngine + ProgressionEngine + TrendAnalyzer
   ฉลาดโดยไม่ต้อง API เลย

   ✅ Features:
     generate()              — Adaptive 7-day program
     generateWithReason()    — program + Explain Mode
     getLocalCoachAdvice()   — deterministic coach (แทน AI chat)
     _buildDayExercises()    — EXERCISE_DB + Progression-aware
     _enrichWithProgression()— ใส่ nextReps/nextSets จาก ProgressionEngine
   ================================================================ */
'use strict';

const LocalAI = {

  /* ----------------------------------------------------------
     generate — main entry point
  ---------------------------------------------------------- */
  generate(profile = {}, engineData = {}, equipment = []) {
    const OE       = window.OPERATOR_ENGINE;
    const readiness = engineData.readiness ?? OE?.state?.readiness ?? 100;
    const fatigue   = engineData.fatigue   ?? OE?.state?.fatigue   ?? {};
    const phase     = OE?.getCurrentPhase?.() ?? {
      nameTH: 'Base', sets: 3, reps: '12-15', restTime: '60s', intensity: 0.70,
    };
    const eqKeys = this._parseEquipment(equipment);
    const weekPlan = this._planWeekWithDecision(fatigue, readiness);
    const dayNames = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
    const program  = {};

    dayNames.forEach((day, i) => {
      const { type, intensity } = weekPlan[i];
      program[day] = this._buildDayExercises(
        type, intensity, profile.fitness || 'beginner', phase, fatigue, eqKeys,
      );
    });

    return program;
  },

  /* ----------------------------------------------------------
     generateWithReason — program + explain ทุกวัน
  ---------------------------------------------------------- */
  generateWithReason(profile = {}, engineData = {}, equipment = []) {
    const program   = this.generate(profile, engineData, equipment);
    const decision  = typeof DecisionEngine  !== 'undefined' ? DecisionEngine.evaluate()      : null;
    const trendData = typeof TrendAnalyzer   !== 'undefined' ? TrendAnalyzer.analyzeTrend()   : null;
    return {
      program,
      explain: decision?.explainTH ?? null,
      trend:   trendData?.reportTH ?? null,
      source:  'LocalAI v2 — Deterministic Adaptive Engine',
    };
  },

  /* ----------------------------------------------------------
     _planWeekWithDecision — วาง 7-day plan ด้วย DecisionEngine
  ---------------------------------------------------------- */
  _planWeekWithDecision(fatigue, readiness) {
    const DE       = typeof DecisionEngine !== 'undefined' ? DecisionEngine : null;
    const rotation = ['push', 'pull', 'run', 'core', 'push', 'run', 'recovery'];

    return rotation.map((baseType, i) => {
      // วันแรก: ใช้ DecisionEngine เต็ม
      if (i === 0 && DE) {
        const d = DE.evaluate();
        return { type: d.type, intensity: d.intensity };
      }

      // วันอื่น: ตรวจ fatigue แล้วปรับ
      const muscleMap = { push: 'chest', pull: 'back', core: 'core', run: 'legs' };
      const muscle    = muscleMap[baseType];
      const fatigueVal = (DE && muscle) ? (fatigue[muscle] || 0) : 0;
      const limit      = DE?.T?.MUSCLE_FATIGUE_REST ?? 70;

      if (fatigueVal > limit) return { type: 'recovery', intensity: 0.4 };

      const intensity = readiness >= 80 ? 0.85
                      : readiness >= 60 ? 0.75
                      : readiness >= 40 ? 0.60 : 0.40;
      return { type: baseType, intensity };
    });
  },

  /* ----------------------------------------------------------
     _buildDayExercises — เลือกท่า + ใส่ progression data
  ---------------------------------------------------------- */
  _buildDayExercises(type, intensity, fitness, phase, fatigue, eqKeys) {
    if (type === 'recovery') return this._recoveryDay();
    const db = this._fromDB(type, eqKeys, fitness, phase, intensity);
    if (db && db.length) return this._enrichWithProgression(db);
    return this._fallbackDay(type, intensity);
  },

  /* ----------------------------------------------------------
     _enrichWithProgression — ใส่ nextReps/suggestion จาก ProgressionEngine
  ---------------------------------------------------------- */
  _enrichWithProgression(exercises) {
    const PE = typeof ProgressionEngine !== 'undefined' ? ProgressionEngine : null;
    if (!PE) return exercises;

    return exercises.map(ex => {
      const key      = (ex.name || '').toLowerCase().replace(/[^a-zก-๙\s]/g, '').trim();
      const analysis = PE.analyzeExercise(key);
      const hasData  = analysis.status !== 'new' && analysis.status !== 'insufficient_data';
      return {
        ...ex,
        sets:           hasData && analysis.nextSets ? analysis.nextSets : ex.sets,
        reps:           hasData && analysis.nextReps ? analysis.nextReps : ex.reps,
        tips:           hasData && analysis.suggestion
                          ? analysis.suggestion + (ex.tips ? '\n' + ex.tips : '')
                          : ex.tips,
        progressStatus: hasData ? analysis.statusTH : null,
      };
    });
  },

  /* ----------------------------------------------------------
     _fromDB — เลือกท่าจาก EXERCISE_DB
  ---------------------------------------------------------- */
  _fromDB(type, eqKeys, fitness, phase, intensity) {
    const db = window.EXERCISE_DB;
    if (!db || !Array.isArray(db)) return null;

    const muscleMap = {
      push:     ['chest', 'shoulders'],
      pull:     ['back'],
      run:      ['cardio'],
      core:     ['core'],
      fullbody: ['chest', 'back', 'legs', 'core'],
      moderate: ['core', 'arms'],
      legs:     ['legs'],
    };
    const targetMuscles = muscleMap[type] || ['chest'];

    const available = db.filter(ex => {
      const eqOk     = ex.equipment === 'bodyweight' || ex.equipment === 'cardio'
                    || eqKeys.includes(ex.equipment);
      const muscleOk = targetMuscles.includes(ex.muscle);
      const diffOk   = fitness === 'advanced'     ? true
                     : fitness === 'intermediate' ? ex.difficulty !== 'advanced'
                     : ex.difficulty === 'beginner';
      return eqOk && muscleOk && diffOk;
    });

    if (!available.length) return null;

    const count    = type === 'run' ? 3 : 4;
    const picks    = [...available].sort(() => Math.random() - 0.5).slice(0, count);
    const baseSets = Math.max(2, Math.round((phase.sets || 3) * intensity));

    return picks.map(ex => ({
      name:   ex.nameTH || ex.name,
      sets:   baseSets,
      reps:   ex.reps   || phase.reps || '10-12',
      rest:   ex.rest   || phase.restTime || '60s',
      tips:   ex.tips   || '',
      muscle: ex.muscle,
    }));
  },

  /* ----------------------------------------------------------
     _recoveryDay
  ---------------------------------------------------------- */
  _recoveryDay() {
    return [
      { name: 'เดินเบาๆ',       sets: 1, reps: '20-30 นาที', rest: '–',  tips: 'ผ่อนคลาย' },
      { name: 'Stretching',      sets: 1, reps: '10 นาที',    rest: '–',  tips: 'ยืดทุกกลุ่ม' },
      { name: 'Dead Hang',       sets: 2, reps: '20s',         rest: '60s',tips: 'ผ่อนไหล่' },
      { name: 'Deep Breathing',  sets: 1, reps: '5 นาที',      rest: '–',  tips: '4-7-8 breathing' },
    ];
  },

  /* ----------------------------------------------------------
     _fallbackDay — ใช้เมื่อ EXERCISE_DB ไม่มี
  ---------------------------------------------------------- */
  _fallbackDay(type, intensity) {
    const s = n => Math.max(2, Math.round(n * intensity));
    const map = {
      push: [
        { name: 'วิดพื้น',           sets: s(4), reps: '20',   rest: '60s',  tips: 'ลำตัวตรง' },
        { name: 'วิดพื้น Diamond',   sets: s(3), reps: '12',   rest: '60s',  tips: 'เน้น triceps' },
        { name: 'วิดพื้น Wide',      sets: s(3), reps: '15',   rest: '60s',  tips: 'มือกว้าง' },
        { name: 'Plank',             sets: s(3), reps: '45s',  rest: '30s',  tips: 'แกนกลางแน่น' },
      ],
      pull: [
        { name: 'ดึงข้อ',            sets: s(5), reps: 'max',  rest: '120s', tips: 'คางพ้นบาร์' },
        { name: 'Dead Hang',         sets: s(3), reps: '30s',  rest: '60s',  tips: 'ไหล่ผ่อน' },
        { name: 'Australian Pull Up',sets: s(3), reps: '12',   rest: '60s',  tips: 'เริ่มต้นได้ดี' },
        { name: 'Scapula Pull Up',   sets: s(3), reps: '10',   rest: '60s',  tips: 'ดึงสะบักลง' },
      ],
      run: [
        { name: 'Warm Up เดิน',      sets: 1,    reps: '5 นาที', rest: '–', tips: '' },
        { name: 'วิ่ง 1.6km',        sets: 1,    reps: 'timed',  rest: '–',  tips: 'จับเวลา' },
        { name: 'Sprint 100m',       sets: s(5), reps: '100m',   rest: '1m', tips: 'เต็มที่' },
        { name: 'Cool Down เดิน',    sets: 1,    reps: '5 นาที', rest: '–',  tips: '' },
      ],
      core: [
        { name: 'Situps',            sets: s(4), reps: '25',   rest: '45s', tips: 'มือแนบหู' },
        { name: 'Leg Raises',        sets: s(3), reps: '15',   rest: '45s', tips: 'ขาตรง' },
        { name: 'Russian Twist',     sets: s(3), reps: '20',   rest: '45s', tips: 'บิดสุด' },
        { name: 'Plank',             sets: s(3), reps: '60s',  rest: '30s', tips: 'ลำตัวตรง' },
      ],
      moderate: [
        { name: 'วิดพื้นเบาๆ',      sets: s(3), reps: '10',   rest: '90s', tips: 'ช้าๆ' },
        { name: 'Plank',             sets: s(3), reps: '30s',  rest: '60s', tips: '' },
        { name: 'เดิน / ยืด',        sets: 1,    reps: '15 นาที', rest: '–', tips: '' },
      ],
    };
    return map[type] || map.core;
  },

  /* ----------------------------------------------------------
     getLocalCoachAdvice — deterministic coach (แทน AI chat)
  ---------------------------------------------------------- */
  getLocalCoachAdvice(query = '') {
    const q  = query.toLowerCase();
    const DE = typeof DecisionEngine   !== 'undefined' ? DecisionEngine   : null;
    const PE = typeof ProgressionEngine!== 'undefined' ? ProgressionEngine: null;
    const TA = typeof TrendAnalyzer    !== 'undefined' ? TrendAnalyzer    : null;
    const OE = window.OPERATOR_ENGINE;

    if (q.includes('เหนื่อย') || q.includes('ล้า') || q.includes('fatigue')) {
      return DE?.getStateSummary()?.explain ?? 'บันทึก workout ก่อนเพื่อวิเคราะห์';
    }
    if (q.includes('plateau') || q.includes('ไม่ขึ้น') || q.includes('ไม่พัฒนา')) {
      const p = PE?.getOverallProgress();
      if (p?.plateaued > 0) {
        return `⚠️ Plateau ${p.plateaued} ท่า:\n` +
          p.exercises.filter(e => e.plateau).slice(0, 3)
            .map(e => `• ${e.name}: ${e.suggestion}`).join('\n');
      }
      return '✅ ยังไม่พบ Plateau — ฝึกต่อเลย';
    }
    if (q.includes('รายงาน') || q.includes('สัปดาห์') || q.includes('progress')) {
      return TA?.getWeeklyReport()?.reportTH ?? 'เก็บข้อมูล 3+ วันก่อน';
    }
    if (q.includes('บาดเจ็บ') || q.includes('เจ็บ') || q.includes('injury')) {
      const inj = DE?.checkInjuryRisk();
      return inj?.warnings?.length
        ? '⚠️ ความเสี่ยง:\n' + inj.warnings.join('\n')
        : '✅ ไม่พบความเสี่ยงบาดเจ็บ';
    }
    if (q.includes('วันนี้') || q.includes('ฝึกอะไร')) {
      return DE?.evaluate()?.explainTH ?? 'ไม่มีข้อมูล';
    }

    if (!OE) return '💡 เริ่มบันทึก Workout เพื่อให้ Coach วิเคราะห์ได้';
    const r  = Math.round(OE.state.readiness || 100);
    const rl = OE.getReadinessLabel?.() || { label: '–', advice: '' };
    return `📊 Readiness: ${r}% — ${rl.label}\n💡 ${rl.advice}`;
  },

  /* ----------------------------------------------------------
     _parseEquipment
  ---------------------------------------------------------- */
  _parseEquipment(equipment = []) {
    const map = {
      'บาร์โหน': 'pullupbar', 'ดัมเบล': 'dumbbell', 'บาร์เบล': 'barbell',
      'เคเบิ้ลแมชชีน': 'cable', 'ลูกน้ำหนัก Kettlebell': 'kettlebell',
      'ยางยืด Resistance Band': 'band',
      pullupbar: 'pullupbar', dumbbell: 'dumbbell', barbell: 'barbell',
    };
    const keys = ['bodyweight'];
    equipment.forEach(e => { const k = map[e]; if (k && !keys.includes(k)) keys.push(k); });
    return keys;
  },
};

window.LocalAI = LocalAI;
console.log('%c[LocalAI v2] Loaded — DecisionEngine + ProgressionEngine + TrendAnalyzer integrated', 'color:#78cc55');
