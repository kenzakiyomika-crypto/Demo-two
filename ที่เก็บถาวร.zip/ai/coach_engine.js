/* ================================================================
   OPERATOR COACH ENGINE  —  coach_engine.js
   Final Tier: AI Coach Grade

   Implements all remaining gaps + biometric simulation layer:

   ✅ 1. Hypertrophy Simulation (Stimulus Accumulation + Sigmoid Cap)
   ✅ 2. Chronic Fatigue Index  (CFI — 14-day rolling avg)
   ✅ 3. AI Weekly Programming Engine (full decision tree)
   ✅ 4. Elite Certification Gate (MASTER tier — 5 requirements)
   ✅ 5. Biometric Simulation Layer:
          — HRV Integration (manual + estimated)
          — Sleep API Integration (manual log + pattern analysis)
          — Movement Velocity Tracking (RPE-based bar velocity est.)
          — Force Estimation Model (estimated from e1RM + bodyweight)
          — Wearable Sync Interface (bridge for future real sensor data)

   Load order: last (after elite_engine.js)
   Safe: additive only, never mutates existing state
   ================================================================ */
'use strict';

/* ============================================================
   CONSTANTS
   ============================================================ */
const COACH = {
  CFI_WINDOW:       14,    // Chronic Fatigue Index rolling days
  HYPERTROPHY_CAP:  100,   // sigmoid-capped max
  HRV_BASELINE_DEFAULT: 65, // ms — population average
  VELOCITY_LOSS_THRESHOLD: 0.20,  // 20% velocity loss = effective set endpoint
  MASTER_CERT_MAV_WEEKS: 3,
  MASTER_CERT_ACWR_STABLE_WEEKS: 4,
};

/* ============================================================
   1. HYPERTROPHY SIMULATION ENGINE
      Stimulus Accumulation Model
      Growth ∝ (EffectiveVolume × SFR × RecoveryScore)
      Capped with sigmoid function — reflects biological ceiling
   ============================================================ */
const HypertrophyEngine = {

  /* Sigmoid cap: maps any x > 0 to (0,1) smoothly             */
  _sigmoid(x) {
    return 1 / (1 + Math.exp(-x));
  },

  /* Sigmoid-based growth cap: 0→0, 50→~70, 100→1.0, ∞→1.0    */
  _sigcap(raw, maxVal = COACH.HYPERTROPHY_CAP) {
    // Shift so midpoint is at 50% of max
    const normalized = (raw / maxVal) * 10 - 5;
    return this._sigmoid(normalized) * maxVal;
  },

  /* Add hypertrophy stimulus from a workout session            */
  stimulate(muscle, effectiveVolume, sfr, recoveryScore) {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return 0;

    // Ensure state exists
    if (!OE.state._hypertrophy) OE.state._hypertrophy = {};
    if (!OE.state._hypertrophy[muscle]) {
      OE.state._hypertrophy[muscle] = {
        rawAccumulation: 0,
        cappedValue:     0,
        sessions:        0,
        history:         [],
      };
    }

    const h = OE.state._hypertrophy[muscle];

    // Growth formula: tiny per-session accumulation
    const recovery  = Math.max(0, Math.min(100, recoveryScore || 70));
    const gain      = effectiveVolume * sfr * (recovery / 100) * 0.001;

    h.rawAccumulation += gain;
    h.cappedValue      = this._sigcap(h.rawAccumulation);
    h.sessions        += 1;

    // Rolling history (90 sessions max)
    const today = new Date().toISOString().split('T')[0];
    h.history.push({ date: today, raw: +h.rawAccumulation.toFixed(4), capped: +h.cappedValue.toFixed(2) });
    if (h.history.length > 90) h.history = h.history.slice(-90);

    return gain;
  },

  /* Current hypertrophy status per muscle                      */
  getStatus(muscle) {
    const OE = window.OPERATOR_ENGINE;
    const h  = OE?.state?._hypertrophy?.[muscle];
    if (!h) return { capped: 0, tier: 'untrained', progress: 0 };

    const v = h.cappedValue;
    const tier = v >= 80 ? 'elite'
               : v >= 60 ? 'advanced'
               : v >= 40 ? 'intermediate'
               : v >= 20 ? 'novice'
               : 'untrained';

    return {
      capped:   +v.toFixed(1),
      raw:      +h.rawAccumulation.toFixed(3),
      sessions: h.sessions,
      tier,
      progress: +v.toFixed(1),    // 0-100
      history:  h.history.slice(-10),
    };
  },

  /* Check if plateau has been hit (growth < 0.5 in last 14 sessions) */
  isPlateau(muscle) {
    const h = window.OPERATOR_ENGINE?.state?._hypertrophy?.[muscle];
    if (!h || h.history.length < 14) return false;

    const recent = h.history.slice(-14);
    const first  = recent[0].capped;
    const last   = recent[recent.length - 1].capped;
    return (last - first) < 0.5;  // < 0.5 units growth in 14 sessions
  },

  /* Stimulate all muscles after a logged workout               */
  onWorkoutLogged(exercises) {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return;

    exercises.forEach(ex => {
      const muscle = ex.muscle || 'core';
      const sets   = Number(ex.sets)   || 3;
      const reps   = Number(ex.reps)   || 10;
      const weight = Number(ex.weight) > 0 ? Number(ex.weight) : 1;
      const effVol = sets * reps * weight;

      // SFR from AscensionEngine if available, else default
      let sfr = 1.0;
      if (typeof AscensionEngine !== 'undefined') {
        const profile = AscensionEngine._getExerciseProfile((ex.name || '').toLowerCase());
        sfr = profile.stimulus / profile.fatigueCost;
      }

      const recovery = OE.state.readiness || 70;
      this.stimulate(muscle, effVol, sfr, recovery);
    });

    this._persist(OE.state);
  },

  _persist(s) {
    try {
      // FIX [High]: use profile-aware storage key
      const pid = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
               || localStorage.getItem('operator_active_profile');
      const storeKey = pid ? `operator_production_${pid}` : 'operator_production_v1';
      const raw  = localStorage.getItem(storeKey);
      const data = raw ? JSON.parse(raw) : s;
      data._hypertrophy = s._hypertrophy;
      localStorage.setItem(storeKey, JSON.stringify(data));
    } catch(e) {
      if (typeof Logger !== 'undefined') Logger.saveFail('HypertrophyEngine', e);
    }
  },
};

/* ============================================================
   2. CHRONIC FATIGUE INDEX  (CFI)
      14-day rolling average of daily fatigue load
      High CFI → readiness cap is reduced
      Integrates with: readiness calculation, injury risk
   ============================================================ */
const CFIEngine = {

  /* Log today's fatigue snapshot                               */
  logDailyFatigue() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return;

    if (!OE.state._cfi) OE.state._cfi = { log: [] };

    const avgFatigue = Object.values(OE.state.fatigue || {})
      .reduce((a, b) => a + b, 0) / 6;  // 6 muscle groups

    const today = new Date().toISOString().split('T')[0];
    const existing = OE.state._cfi.log.find(e => e.date === today);

    if (existing) {
      existing.fatigue = avgFatigue;
    } else {
      OE.state._cfi.log.push({ date: today, fatigue: +avgFatigue.toFixed(2) });
    }

    if (OE.state._cfi.log.length > COACH.CFI_WINDOW + 7)
      OE.state._cfi.log = OE.state._cfi.log.slice(-(COACH.CFI_WINDOW + 7));

    this._persist(OE.state);
  },

  /* Compute current 14-day rolling CFI (0–100)                */
  calculate() {
    const OE = window.OPERATOR_ENGINE;
    const log = OE?.state?._cfi?.log || [];

    if (log.length < 3) {
      // Fallback: use current avg fatigue
      const avg = Object.values(OE?.state?.fatigue || {})
        .reduce((a, b) => a + b, 0) / 6;
      return { cfi: +avg.toFixed(1), dataPoints: log.length, confidence: 'low', trend: 'unknown' };
    }

    const window14 = log.slice(-COACH.CFI_WINDOW);
    const cfi = window14.reduce((s, e) => s + e.fatigue, 0) / window14.length;

    // Trend: compare first half vs second half
    const mid    = Math.floor(window14.length / 2);
    const first  = window14.slice(0, mid).reduce((s, e) => s + e.fatigue, 0) / mid;
    const second = window14.slice(mid).reduce((s, e) => s + e.fatigue, 0) / (window14.length - mid);
    const trend  = second > first + 5 ? 'rising' : second < first - 5 ? 'falling' : 'stable';

    return {
      cfi:        +cfi.toFixed(1),
      dataPoints: window14.length,
      confidence: window14.length >= 7 ? 'high' : 'medium',
      trend,
      // Readiness cap: high CFI reduces max attainable readiness
      readinessCap: Math.max(40, Math.round(100 - cfi * 0.4)),
    };
  },

  /* Apply CFI readiness cap to engine's readiness score        */
  applyCap() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return;

    const { cfi, readinessCap } = this.calculate();
    if (cfi > 40 && OE.state.readiness > readinessCap) {
      OE.state.readiness = readinessCap;
    }
  },

  _persist(s) {
    try {
      // FIX [High]: use profile-aware storage key
      const pid = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
               || localStorage.getItem('operator_active_profile');
      const storeKey = pid ? `operator_production_${pid}` : 'operator_production_v1';
      const raw  = localStorage.getItem(storeKey);
      const data = raw ? JSON.parse(raw) : s;
      data._cfi = s._cfi;
      localStorage.setItem(storeKey, JSON.stringify(data));
    } catch(e) {
      if (typeof Logger !== 'undefined') Logger.saveFail('ChronicFatigueEngine', e);
    }
  },
};

/* ============================================================
   3. AI WEEKLY PROGRAMMING ENGINE
      Analyzes 6 signals → generates optimal next-week block
      Decision tree: DELOAD > INTENSITY > VOLUME > BALANCED
   ============================================================ */
const WeeklyPlanner = {

  /* Compute global injury risk level across all muscles        */
  _globalInjuryRisk() {
    if (typeof InjuryRiskModel !== 'undefined') {
      const r = InjuryRiskModel.assess();
      return r.level;  // 'high' | 'moderate' | 'low' | 'minimal'
    }
    if (typeof ACWREngine !== 'undefined') {
      const { ratio } = ACWREngine.calculate();
      if (ratio > 1.5) return 'high';
      if (ratio > 1.3) return 'moderate';
      return 'low';
    }
    return 'low';
  },

  /* Global strength trend slope (avg across all exercises)     */
  _globalStrengthSlope() {
    if (typeof StrengthCurve !== 'undefined') {
      const models = StrengthCurve.modelAll();
      if (!models.length) return 0;
      return models.reduce((s, m) => s + m.slope, 0) / models.length;
    }
    return 0;
  },

  /* True if hypertrophy is plateauing on 2+ primary muscles    */
  _hypertrophyPlateau() {
    const primaries = ['chest', 'back', 'legs'];
    const plateaued = primaries.filter(m => HypertrophyEngine.isPlateau(m));
    return plateaued.length >= 2;
  },

  /* Consistency: % planned days trained in last 4 weeks        */
  _consistencyScore() {
    const OE = window.OPERATOR_ENGINE;
    if (typeof AscensionEngine !== 'undefined' && AscensionEngine._a) {
      const dates = AscensionEngine._a.certification?.workoutDates || [];
      const cutoff = new Date(Date.now() - 28 * 86_400_000).toISOString().split('T')[0];
      const recent = dates.filter(d => d >= cutoff);
      return Math.min(1, new Set(recent).size / 16);  // 4 days/week × 4 weeks = 16
    }
    const workouts = OE?.state?.workoutsCompleted || 0;
    return Math.min(1, workouts / 16);
  },

  /* Main planner: returns block recommendation + full rationale */
  plan() {
    const OE = window.OPERATOR_ENGINE;

    const injuryRisk     = this._globalInjuryRisk();
    const strengthSlope  = this._globalStrengthSlope();
    const hPlateau       = this._hypertrophyPlateau();
    const consistency    = this._consistencyScore();
    const cfi            = CFIEngine.calculate();
    const readiness      = OE?.state?.readiness || 80;

    // ── Decision Tree ──────────────────────────────────────────
    let block, rationale;

    if (injuryRisk === 'high' || cfi.cfi > 65 || readiness < 35) {
      block = 'DELOAD';
      rationale = [
        injuryRisk === 'high'  ? `⚠️ Injury risk สูง (${injuryRisk})` : null,
        cfi.cfi > 65            ? `⚠️ CFI สูง (${cfi.cfi}) — ล้าสะสม 14 วัน` : null,
        readiness < 35          ? `⚠️ Readiness ต่ำมาก (${Math.round(readiness)}%)` : null,
      ].filter(Boolean);

    } else if (strengthSlope <= 0 && consistency > 0.5) {
      block = 'INTENSITY_BLOCK';
      rationale = [
        `📉 Strength trend หยุดนิ่ง/ลดลง (slope: ${strengthSlope.toFixed(2)})`,
        'เพิ่ม Intensity ลด Volume → กระตุ้น neural adaptation ใหม่',
      ];

    } else if (hPlateau && readiness > 60) {
      block = 'VOLUME_BLOCK';
      rationale = [
        `📊 Hypertrophy plateau ≥ 2 muscle groups`,
        'เพิ่ม Volume → ผ่าน MEV ขึ้น MAV zone ใหม่',
      ];

    } else if (consistency < 0.5) {
      block = 'CONSISTENCY_FOCUS';
      rationale = [
        `📅 Consistency ต่ำ (${Math.round(consistency * 100)}% / 4 สัปดาห์)`,
        'ลด complexity — 3 วัน fullbody เน้นความสม่ำเสมอ',
      ];

    } else {
      block = 'BALANCED';
      rationale = [
        '✅ ทุก signal อยู่ใน green zone',
        `Readiness ${Math.round(readiness)}% · Strength slope ${strengthSlope.toFixed(2)} · CFI ${cfi.cfi}`,
        'ฝึกตาม periodization phase ปกติ',
      ];
    }

    const blockConfig = this._blockConfig(block);

    return {
      block,
      rationale,
      ...blockConfig,
      signals: {
        injuryRisk,
        strengthSlope: +strengthSlope.toFixed(3),
        hypertrophyPlateau: hPlateau,
        consistency: Math.round(consistency * 100),
        cfi: cfi.cfi,
        readiness: Math.round(readiness),
      },
      generatedAt: new Date().toISOString(),
    };
  },

  _blockConfig(block) {
    const configs = {
      DELOAD: {
        nameTH:      '🔄 Deload Week',
        volumeMod:   0.55,
        intensityMod: 0.65,
        rpeTarget:   '6–7',
        daysPerWeek: 3,
        focus:       'active recovery, mobility, low CNS stress',
        color:       '#e74c3c',
      },
      INTENSITY_BLOCK: {
        nameTH:      '⚡ Intensity Block',
        volumeMod:   0.80,
        intensityMod: 0.92,
        rpeTarget:   '8–9',
        daysPerWeek: 4,
        focus:       'heavy compound, low rep (3-5), long rest',
        color:       '#e67e22',
      },
      VOLUME_BLOCK: {
        nameTH:      '📈 Volume Block',
        volumeMod:   1.15,
        intensityMod: 0.75,
        rpeTarget:   '7–8',
        daysPerWeek: 5,
        focus:       'moderate weight, 8-15 reps, controlled rest',
        color:       '#2ecc71',
      },
      CONSISTENCY_FOCUS: {
        nameTH:      '🎯 Consistency Block',
        volumeMod:   0.85,
        intensityMod: 0.78,
        rpeTarget:   '6–8',
        daysPerWeek: 3,
        focus:       'fullbody 3×/week, same time each day',
        color:       '#3498db',
      },
      BALANCED: {
        nameTH:      '⚖️ Balanced Block',
        volumeMod:   1.00,
        intensityMod: 0.82,
        rpeTarget:   '7–8',
        daysPerWeek: 4,
        focus:       'standard periodization, push/pull/legs rotation',
        color:       '#78cc55',
      },
    };
    return configs[block] || configs.BALANCED;
  },
};

/* ============================================================
   4. ELITE CERTIFICATION GATE — MASTER TIER
      5 requirements (stricter than base certification):
        1. Strength Index ≥ 70 (positive slope 4+ weeks)
        2. ACWR stable in 0.8–1.3 for 4 consecutive weeks
        3. No injury flag (compositeScore < 35)
        4. Positive strength slope (regression > 0.2 kg/session)
        5. Volume in MAV zone ≥ 3 weeks
   ============================================================ */
const MasterCertification = {

  check() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE || !window.AscensionEngine?._a) {
      return { eligible: false, tier: 'N/A', requirements: [] };
    }

    const OR         = typeof AscensionEngine !== 'undefined'
      ? AscensionEngine.calcOperatorRating()
      : { OR: 0, breakdown: { strengthIndex: 0 } };

    const acwr       = typeof ACWREngine !== 'undefined'
      ? ACWREngine.calculate()
      : { ratio: 1.0, zone: 'unknown' };

    const injury     = typeof InjuryRiskModel !== 'undefined'
      ? InjuryRiskModel.assess()
      : { compositeScore: 0 };

    const strCurves  = typeof StrengthCurve !== 'undefined'
      ? StrengthCurve.modelAll()
      : [];

    const avgSlope   = strCurves.length
      ? strCurves.reduce((s, m) => s + m.slope, 0) / strCurves.length
      : 0;

    const mavWeeks   = AscensionEngine._a?.certification?.volumeWeeks || 0;
    const acwrStable = this._checkACWRStableWeeks();

    const reqs = [
      {
        id:     'strength_index',
        label:  '💪 Strength Index ≥ 70',
        met:    OR.breakdown?.strengthIndex >= 70,
        value:  OR.breakdown?.strengthIndex || 0,
        target: 70,
      },
      {
        id:     'acwr_stable',
        label:  '📊 ACWR Stable 4 สัปดาห์ (0.8–1.3)',
        met:    acwrStable >= COACH.MASTER_CERT_ACWR_STABLE_WEEKS,
        value:  acwrStable + ' wk',
        target: COACH.MASTER_CERT_ACWR_STABLE_WEEKS + ' wk',
      },
      {
        id:     'no_injury',
        label:  '🛡️ ไม่มี Injury Flag (Risk < 35)',
        met:    injury.compositeScore < 35,
        value:  injury.compositeScore,
        target: '< 35',
      },
      {
        id:     'positive_slope',
        label:  '📈 Strength Slope > 0.2 kg/session',
        met:    avgSlope > 0.2,
        value:  +avgSlope.toFixed(3) + ' kg',
        target: '> 0.2 kg',
      },
      {
        id:     'mav_zone',
        label:  `📦 MAV Zone ≥ ${COACH.MASTER_CERT_MAV_WEEKS} สัปดาห์`,
        met:    mavWeeks >= COACH.MASTER_CERT_MAV_WEEKS,
        value:  mavWeeks + ' wk',
        target: COACH.MASTER_CERT_MAV_WEEKS + ' wk',
      },
    ];

    const metCount  = reqs.filter(r => r.met).length;
    const eligible  = metCount === reqs.length;
    const progress  = Math.round((metCount / reqs.length) * 100);

    const tier = eligible ? 'MASTER'
               : metCount >= 4 ? 'ELITE_CANDIDATE'
               : metCount >= 3 ? 'ADVANCED'
               : 'IN_PROGRESS';

    return { eligible, tier, progress, metCount, total: reqs.length, requirements: reqs, OR: OR.OR };
  },

  _checkACWRStableWeeks() {
    // Count consecutive weeks where ACWR was in 0.8–1.3
    const OE  = window.OPERATOR_ENGINE;
    const log = OE?.state?._acwr?.log || [];
    if (log.length < 7) return 0;

    // Group by week
    const weeks = {};
    log.forEach(({ date, load }) => {
      const weekKey = date.slice(0, 7);  // YYYY-MM
      if (!weeks[weekKey]) weeks[weekKey] = 0;
      weeks[weekKey] += load;
    });

    const weekLoads = Object.values(weeks);
    if (weekLoads.length < 2) return 0;

    const chronic = weekLoads.slice(0, -1).reduce((a, b) => a + b, 0) / (weekLoads.length - 1) || 1;

    let stable = 0;
    for (let i = weekLoads.length - 1; i >= 0; i--) {
      const ratio = weekLoads[i] / chronic;
      if (ratio >= 0.8 && ratio <= 1.3) stable++;
      else break;
    }
    return stable;
  },
};

/* ============================================================
   5. BIOMETRIC SIMULATION LAYER
      Interface for real sensor data + simulation fallback
      Ready to accept: HRV, Sleep API, Wearable, Velocity
   ============================================================ */
const BiometricLayer = {

  /* ── HRV Integration ──────────────────────────────────────── */
  HRV: {
    baseline: COACH.HRV_BASELINE_DEFAULT,

    /* Log HRV reading (manual or from connected device)         */
    log(hrv, source = 'manual') {
      const OE = window.OPERATOR_ENGINE;
      if (!OE) return;

      if (!OE.state._biometrics) OE.state._biometrics = {};
      if (!OE.state._biometrics.hrv) OE.state._biometrics.hrv = [];

      const today = new Date().toISOString().split('T')[0];
      OE.state._biometrics.hrv.push({
        date: today, value: hrv, source,
        rmssd: hrv,  // assume HRV input is RMSSD in ms
      });

      if (OE.state._biometrics.hrv.length > 30)
        OE.state._biometrics.hrv = OE.state._biometrics.hrv.slice(-30);

      // Update baseline (rolling 7-day avg)
      const recent = OE.state._biometrics.hrv.slice(-7);
      this.baseline = Math.round(recent.reduce((s, e) => s + e.value, 0) / recent.length);

      BiometricLayer._persist(OE.state);
    },

    /* Get HRV-adjusted readiness modifier (0.7 – 1.15)          */
    readinessModifier() {
      const OE  = window.OPERATOR_ENGINE;
      const log = OE?.state?._biometrics?.hrv || [];
      if (!log.length) return 1.0;

      const last = log[log.length - 1].value;
      const ratio = last / this.baseline;

      // > baseline → higher readiness; < baseline → suppressed
      if (ratio >= 1.20) return 1.15;
      if (ratio >= 1.05) return 1.05;
      if (ratio >= 0.95) return 1.00;
      if (ratio >= 0.85) return 0.90;
      return 0.75;  // severely suppressed HRV
    },

    /* Estimate HRV from training data (no sensor fallback)       */
    estimate() {
      const OE = window.OPERATOR_ENGINE;
      const readiness = OE?.state?.readiness || 80;
      const streak    = OE?.state?.streak    || 1;

      // Rough model: high readiness + low streak = higher HRV
      const base = COACH.HRV_BASELINE_DEFAULT;
      const est  = base * (readiness / 100) * Math.max(0.7, 1 - streak * 0.02);
      return Math.round(est);
    },

    getStatus() {
      const OE   = window.OPERATOR_ENGINE;
      const log  = OE?.state?._biometrics?.hrv || [];
      const last = log.length ? log[log.length - 1] : null;
      const est  = this.estimate();

      return {
        lastReading:  last?.value || null,
        estimated:    est,
        baseline:     this.baseline,
        source:       last?.source || 'estimated',
        modifier:     this.readinessModifier(),
        status:       last?.value
          ? (last.value >= this.baseline ? '✅ HRV ดี' : '⚠️ HRV ต่ำกว่า baseline')
          : `📡 ประมาณ ~${est}ms (ไม่มี sensor)`,
        date:         last?.date || null,
      };
    },
  },

  /* ── Sleep API Integration ────────────────────────────────── */
  Sleep: {
    /* Log sleep data (from manual input or Sleep API)           */
    log(hours, quality, deepPct = 0.20, remPct = 0.20, source = 'manual') {
      const OE = window.OPERATOR_ENGINE;
      if (!OE) return;

      if (!OE.state._biometrics) OE.state._biometrics = {};
      if (!OE.state._biometrics.sleep) OE.state._biometrics.sleep = [];

      const today = new Date().toISOString().split('T')[0];
      const score = this._calcSleepScore(hours, quality, deepPct, remPct);

      OE.state._biometrics.sleep.push({
        date: today, hours, quality, deepPct, remPct, score, source,
      });

      if (OE.state._biometrics.sleep.length > 30)
        OE.state._biometrics.sleep = OE.state._biometrics.sleep.slice(-30);

      // Also sync to AscensionEngine.logSleep if available
      if (typeof AscensionEngine !== 'undefined') {
        AscensionEngine.logSleep(hours, quality);
      }

      BiometricLayer._persist(OE.state);
      return score;
    },

    /* Sleep score 0–100 (based on Fitbit/Oura methodology)      */
    _calcSleepScore(hours, quality, deepPct, remPct) {
      const durationScore = Math.min(100, (hours / 8) * 60 + (hours >= 7 ? 20 : 0));
      const qualityScore  = (quality / 10) * 30;
      const stageScore    = (deepPct >= 0.15 ? 5 : 0) + (remPct >= 0.20 ? 5 : 0);
      return Math.min(100, Math.round(durationScore + qualityScore + stageScore));
    },

    /* 7-day trend analysis                                       */
    analyzePattern() {
      const OE   = window.OPERATOR_ENGINE;
      const log  = OE?.state?._biometrics?.sleep?.slice(-7) || [];
      if (!log.length) return { avgHours: 7, avgScore: 70, trend: 'no_data', debtHours: 0 };

      const avgHours = log.reduce((s, e) => s + e.hours, 0) / log.length;
      const avgScore = log.reduce((s, e) => s + e.score, 0) / log.length;
      const debtHours = Math.max(0, 8 * log.length - log.reduce((s, e) => s + e.hours, 0));

      const recent3 = log.slice(-3).reduce((s, e) => s + e.score, 0) / 3;
      const prev    = log.slice(0, -3).reduce((s, e) => s + e.score, 0) / Math.max(1, log.length - 3);
      const trend   = recent3 > prev + 5 ? 'improving' : recent3 < prev - 5 ? 'declining' : 'stable';

      return {
        avgHours:  +avgHours.toFixed(1),
        avgScore:  +avgScore.toFixed(0),
        debtHours: +debtHours.toFixed(1),
        trend,
        readinessMod: avgScore >= 80 ? 1.10
                    : avgScore >= 65 ? 1.00
                    : avgScore >= 50 ? 0.90
                    : 0.75,
      };
    },
  },

  /* ── Movement Velocity Tracking ──────────────────────────── */
  Velocity: {
    /* Log bar velocity (from sensor or RPE-estimated)           */
    log(exerciseName, sets) {
      // sets = [{reps, weight, velocity?, rpe}]
      const OE = window.OPERATOR_ENGINE;
      if (!OE) return;

      if (!OE.state._biometrics) OE.state._biometrics = {};
      if (!OE.state._biometrics.velocity) OE.state._biometrics.velocity = {};

      const key = (exerciseName || '').toLowerCase().trim();
      if (!OE.state._biometrics.velocity[key]) OE.state._biometrics.velocity[key] = [];

      sets.forEach(s => {
        const vel = s.velocity || this._estimateVelocity(s.rpe, s.weight);
        OE.state._biometrics.velocity[key].push({
          date:     new Date().toISOString().split('T')[0],
          reps:     s.reps,
          weight:   s.weight,
          velocity: +vel.toFixed(3),
          source:   s.velocity ? 'sensor' : 'estimated',
        });
      });

      if (OE.state._biometrics.velocity[key].length > 50)
        OE.state._biometrics.velocity[key] = OE.state._biometrics.velocity[key].slice(-50);

      BiometricLayer._persist(OE.state);
    },

    /* RPE → estimated bar velocity (m/s) — based on Gonzalez-Badillo model */
    _estimateVelocity(rpe, weight) {
      // Approximate: RPE 10 (1RM) ≈ 0.15 m/s, RPE 6 ≈ 0.80 m/s
      // Linear interpolation: velocity = 1.25 - (rpe - 5) * 0.11
      const rpm = Math.min(10, Math.max(5, Number(rpe) || 7));
      return Math.max(0.10, 1.25 - (rpm - 5) * 0.11);
    },

    /* Minimum Velocity Threshold (MVT) — indicates proximity to failure */
    getMVT(exerciseName) {
      const OE  = window.OPERATOR_ENGINE;
      const key = (exerciseName || '').toLowerCase().trim();
      const log = OE?.state?._biometrics?.velocity?.[key] || [];

      if (log.length < 3) return { mvt: 0.15, estimated: true };

      // MVT ≈ lowest velocity recorded at RPE 9-10
      const heavy = log.filter(l => l.velocity <= 0.25);
      if (!heavy.length) return { mvt: 0.15, estimated: true };

      const mvt = heavy.reduce((s, l) => s + l.velocity, 0) / heavy.length;
      return { mvt: +mvt.toFixed(3), estimated: false };
    },

    /* Velocity-based fatigue: % velocity loss in set            */
    velocityLoss(exerciseName, currentVelocity) {
      const OE  = window.OPERATOR_ENGINE;
      const key = (exerciseName || '').toLowerCase().trim();
      const log = OE?.state?._biometrics?.velocity?.[key] || [];

      if (!log.length) return 0;

      // First rep velocity of this exercise (max effort reference)
      const maxVel = Math.max(...log.map(l => l.velocity));
      const loss   = (maxVel - currentVelocity) / maxVel;

      return +loss.toFixed(3);
    },

    /* Should stop set? Based on COACH.VELOCITY_LOSS_THRESHOLD    */
    shouldStopSet(exerciseName, currentVelocity) {
      const loss = this.velocityLoss(exerciseName, currentVelocity);
      return loss >= COACH.VELOCITY_LOSS_THRESHOLD;
    },
  },

  /* ── Force Estimation Model ──────────────────────────────── */
  Force: {
    /* Estimate peak force (N) from e1RM + bodyweight + exercise  */
    estimate(exerciseName, weight, reps, bodyweightKg = 75) {
      const e1rm = weight * (1 + reps / 30);  // Epley

      // Force ≈ load × 9.81 (gravity) × rate of force development mod
      // Push movements: approximate based on e1RM relative to bodyweight
      const isVertical  = /squat|deadlift|press/i.test(exerciseName);
      const isBW        = /push.?up|pull.?up|dip/i.test(exerciseName);

      let estimatedLoad = e1rm;
      if (isBW) estimatedLoad = bodyweightKg * (e1rm / 100);  // bodyweight fraction

      const peakForce = estimatedLoad * 9.81 * (isVertical ? 1.8 : 1.4);  // RFD modifier

      const relativeStrength = e1rm / bodyweightKg;

      return {
        peakForce:        +peakForce.toFixed(0),        // Newtons
        e1RM:             +e1rm.toFixed(1),              // kg
        relativeStrength: +relativeStrength.toFixed(2),  // kg/kg
        unit:             'N',
        grade: relativeStrength >= 2.0 ? 'Elite'
             : relativeStrength >= 1.5 ? 'Advanced'
             : relativeStrength >= 1.0 ? 'Intermediate'
             : 'Novice',
      };
    },
  },

  /* ── Wearable Sync Interface ─────────────────────────────── */
  Wearable: {
    connected:  false,
    deviceType: null,

    /* Register a wearable device (future-ready bridge)          */
    connect(deviceType, callback) {
      this.deviceType = deviceType;
      this.connected  = true;
      console.log(`[Wearable] Registered: ${deviceType}`);

      // Stub: in production, replace with actual BLE/API bridge
      this._bridge = callback || null;

      return {
        status:     'connected_stub',
        deviceType,
        message:    `${deviceType} interface ready — real data pipeline not yet connected`,
        supported:  ['HRV', 'HR', 'Sleep', 'Steps', 'SpO2'],
        howToSync:  'Call BiometricLayer.Wearable.push(data) with standardized payload',
      };
    },

    /* Receive data push from wearable (standardized payload)    */
    push(data) {
      /*  Expected payload:
          {
            hrv?:       number,          // RMSSD ms
            heartRate?: number,          // bpm
            sleep?: { hours, quality, deepPct, remPct },
            steps?:     number,
            velocity?:  { exercise, sets: [{reps, weight, velocity}] },
          }
      */
      if (!data) return;

      if (data.hrv)   BiometricLayer.HRV.log(data.hrv, this.deviceType || 'wearable');
      if (data.sleep) BiometricLayer.Sleep.log(
        data.sleep.hours, data.sleep.quality,
        data.sleep.deepPct, data.sleep.remPct,
        this.deviceType || 'wearable'
      );
      if (data.velocity?.exercise) BiometricLayer.Velocity.log(data.velocity.exercise, data.velocity.sets);

      console.log('[Wearable] Data received & processed:', Object.keys(data).join(', '));
    },

    disconnect() {
      this.connected  = false;
      this.deviceType = null;
      this._bridge    = null;
    },
  },

  /* ── Unified Biometric Readiness ─────────────────────────── */
  compositeReadiness() {
    const hrv   = this.HRV.readinessModifier();
    const sleep = this.Sleep.analyzePattern().readinessMod;
    const OE    = window.OPERATOR_ENGINE;
    const base  = OE?.state?.readiness || 80;

    // Weighted composite: 50% engine readiness, 30% HRV, 20% sleep
    const composite = base * 0.50 + (base * hrv) * 0.30 + (base * sleep) * 0.20;
    return Math.max(0, Math.min(100, Math.round(composite)));
  },

  _persist(s) {
    try {
      // FIX [High]: use profile-aware storage key
      const pid = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
               || localStorage.getItem('operator_active_profile');
      const storeKey = pid ? `operator_production_${pid}` : 'operator_production_v1';
      const raw  = localStorage.getItem(storeKey);
      const data = raw ? JSON.parse(raw) : s;
      data._biometrics = s._biometrics;
      localStorage.setItem(storeKey, JSON.stringify(data));
    } catch(e) {
      if (typeof Logger !== 'undefined') Logger.saveFail('BiometricLayer', e);
    }
  },
};

/* ============================================================
   COACH ENGINE  —  Unified Interface
   ============================================================ */
const CoachEngine = {

  init() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) { setTimeout(() => this.init(), 800); return; }

    // Restore persisted biometric/hypertrophy/CFI state
    try {
      // FIX [High]: use profile-aware storage key in CoachEngine.init
      const _pid = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
               || localStorage.getItem('operator_active_profile');
      const _initKey = _pid ? `operator_production_${_pid}` : 'operator_production_v1';
      const raw = localStorage.getItem(_initKey);
      if (raw) {
        const data = JSON.parse(raw);
        if (data._hypertrophy) OE.state._hypertrophy = data._hypertrophy;
        if (data._cfi)         OE.state._cfi         = data._cfi;
        if (data._biometrics)  OE.state._biometrics  = data._biometrics;
        if (data._rpeLog)      OE.state._rpeLog       = data._rpeLog;
        if (data._acwr)        OE.state._acwr         = data._acwr;
      }
    } catch {}

    // Patch logWorkout to trigger all coach-layer hooks
    if (!OE._coachPatched) {
      const prev = OE.logWorkout.bind(OE);
      OE.logWorkout = (exercises, grade) => {
        const result = prev(exercises, grade);
        HypertrophyEngine.onWorkoutLogged(exercises);
        CFIEngine.logDailyFatigue();
        CFIEngine.applyCap();
        return result;
      };
      OE._coachPatched = true;
    }

    // Expose all engines on OPERATOR_ENGINE
    OE.hypertrophy     = HypertrophyEngine;
    OE.cfi             = CFIEngine;
    OE.weeklyPlanner   = WeeklyPlanner;
    OE.masterCert      = MasterCertification;
    OE.biometrics      = BiometricLayer;

    // Convenience shortcuts
    OE.weeklyPlan      = ()           => WeeklyPlanner.plan();
    OE.masterStatus    = ()           => MasterCertification.check();
    OE.logHRV          = (v, src)     => BiometricLayer.HRV.log(v, src);
    OE.logSleepFull    = (h, q, d, r, s) => BiometricLayer.Sleep.log(h, q, d, r, s);
    OE.logVelocity     = (ex, sets)   => BiometricLayer.Velocity.log(ex, sets);
    OE.forceEstimate   = (ex, w, r, bw) => BiometricLayer.Force.estimate(ex, w, r, bw);
    OE.wearable        = BiometricLayer.Wearable;
    OE.bioReadiness    = ()           => BiometricLayer.compositeReadiness();

    // Unified full assessment (extends EliteEngine.fullAssessment)
    const prevFull = OE.fullAssessment?.bind(OE);
    OE.fullAssessment = () => ({
      ...(prevFull ? prevFull() : {}),
      weeklyPlan:     WeeklyPlanner.plan(),
      masterCert:     MasterCertification.check(),
      cfi:            CFIEngine.calculate(),
      biometrics: {
        hrv:          BiometricLayer.HRV.getStatus(),
        sleep:        BiometricLayer.Sleep.analyzePattern(),
        wearable:     { connected: BiometricLayer.Wearable.connected, device: BiometricLayer.Wearable.deviceType },
      },
      hypertrophy:    ['chest','back','legs','shoulders','arms','core']
        .reduce((acc, m) => ({ ...acc, [m]: HypertrophyEngine.getStatus(m) }), {}),
      compositeReadiness: BiometricLayer.compositeReadiness(),
    });

    // Initial CFI log
    CFIEngine.logDailyFatigue();

    console.log(
      '%c[CoachEngine 🏆 AI Coach Grade] Loaded',
      'color:#ffd700;font-weight:bold;font-size:13px',
      '\n  Weekly Block:', WeeklyPlanner.plan().block,
      '\n  Master Cert:', MasterCertification.check().tier,
      '\n  Bio Readiness:', BiometricLayer.compositeReadiness() + '%',
      '\n  HRV (est):', BiometricLayer.HRV.estimate() + 'ms',
    );
  },
};

/* ============================================================
   EXPORTS
   ============================================================ */
window.HypertrophyEngine    = HypertrophyEngine;
window.CFIEngine            = CFIEngine;
window.WeeklyPlanner        = WeeklyPlanner;
window.MasterCertification  = MasterCertification;
window.BiometricLayer       = BiometricLayer;
window.CoachEngine          = CoachEngine;

/* ============================================================
   AUTO-INIT
   ============================================================ */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => CoachEngine.init());
} else {
  setTimeout(() => CoachEngine.init(), 300);
}
