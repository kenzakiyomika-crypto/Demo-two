// ============================================================
// EXERCISE DATABASE — Combined Production File
// schema: { id, name, nameTH, muscle, equipment, difficulty,
//           sets, reps, rest, muscles_secondary[], tips }
// equipment keys: bodyweight | pullupbar | dumbbell | barbell |
//                 cable | kettlebell | machine | band | cardio
// ============================================================
// 🔴 FIX: Replaced all smart quotes (\u2018 \u2019) with regular (')
// ============================================================

const EXERCISE_DB = [
// ─── CHEST (bodyweight) ──────────────────────────────────
{id:'c001',name:'Push Up',nameTH:'วิดพื้น',muscle:'chest',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'10-15',rest:'60s',muscles_secondary:['triceps','shoulders'],tips:'ลำตัวตรง ไม่แอ่น'},
{id:'c002',name:'Wide Push Up',nameTH:'วิดพื้น Wide',muscle:'chest',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'10-12',rest:'60s',muscles_secondary:['chest','shoulders'],tips:'มือกว้างกว่าไหล่ เน้น chest'},
{id:'c003',name:'Diamond Push Up',nameTH:'วิดพื้น Diamond',muscle:'chest',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'8-12',rest:'60s',muscles_secondary:['triceps'],tips:'นิ้วชี้และนิ้วหัวแม่มือชนกัน'},
{id:'c004',name:'Decline Push Up',nameTH:'วิดพื้น Decline',muscle:'chest',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'10',rest:'60s',muscles_secondary:['upper chest'],tips:'เท้าอยู่บนเก้าอี้หรือม้านั่ง'},
{id:'c005',name:'Incline Push Up',nameTH:'วิดพื้น Incline',muscle:'chest',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'15',rest:'45s',muscles_secondary:['lower chest'],tips:'มือบนขอบโต๊ะหรือกำแพง'},
{id:'c006',name:'Archer Push Up',nameTH:'วิดพื้น Archer',muscle:'chest',equipment:'bodyweight',difficulty:'advanced',sets:3,reps:'6',rest:'90s',muscles_secondary:['shoulders','triceps'],tips:'ถ่ายน้ำหนักลงข้างเดียว'},
{id:'c007',name:'Pseudo Planche Push Up',nameTH:'Planche Push Up',muscle:'chest',equipment:'bodyweight',difficulty:'advanced',sets:3,reps:'8',rest:'90s',muscles_secondary:['shoulders','core'],tips:'เอียงตัวมาข้างหน้า มือชี้ไปด้านหลัง'},
{id:'c008',name:'Hindu Push Up',nameTH:'วิดพื้น Hindu',muscle:'chest',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'10',rest:'60s',muscles_secondary:['shoulders','back'],tips:'เคลื่อนที่เป็นส่วนโค้ง'},
{id:'c009',name:'Clap Push Up',nameTH:'วิดพื้นปรบมือ',muscle:'chest',equipment:'bodyweight',difficulty:'advanced',sets:3,reps:'5-8',rest:'90s',muscles_secondary:['explosive power'],tips:'ดันตัวขึ้นแรงๆ ปรบมือก่อนลง'},
{id:'c010',name:'One Arm Push Up',nameTH:'วิดพื้นแขนเดียว',muscle:'chest',equipment:'bodyweight',difficulty:'advanced',sets:3,reps:'3-5',rest:'120s',muscles_secondary:['core','triceps'],tips:'เปิดขากว้างเพื่อทรงตัว'},
// ─── CHEST (dumbbell) ───────────────────────────────────
{id:'c011',name:'Dumbbell Bench Press',nameTH:'เบนช์เพรสดัมเบล',muscle:'chest',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'10-12',rest:'90s',muscles_secondary:['triceps','shoulders'],tips:'หย่อนดัมเบลลงถึงหน้าอก'},
{id:'c012',name:'Dumbbell Flyes',nameTH:'ดัมเบล Flyes',muscle:'chest',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'12-15',rest:'60s',muscles_secondary:['shoulders'],tips:'งอข้อศอกเล็กน้อยตลอดท่า'},
{id:'c013',name:'Dumbbell Incline Press',nameTH:'Incline เพรสดัมเบล',muscle:'chest',equipment:'dumbbell',difficulty:'intermediate',sets:3,reps:'10',rest:'90s',muscles_secondary:['upper chest','shoulders'],tips:'ม้านั่ง 30-45 องศา'},
{id:'c014',name:'Dumbbell Pullover',nameTH:'ดัมเบล Pullover',muscle:'chest',equipment:'dumbbell',difficulty:'intermediate',sets:3,reps:'12',rest:'60s',muscles_secondary:['back','triceps'],tips:'ยืดกล้ามเนื้อหน้าอก'},
// ─── CHEST (barbell) ────────────────────────────────────
{id:'c015',name:'Barbell Bench Press',nameTH:'เบนช์เพรสบาร์เบล',muscle:'chest',equipment:'barbell',difficulty:'intermediate',sets:4,reps:'6-10',rest:'120s',muscles_secondary:['triceps','shoulders'],tips:'จับแท่งกว้างกว่าไหล่เล็กน้อย'},
{id:'c016',name:'Barbell Incline Press',nameTH:'Incline เพรสบาร์เบล',muscle:'chest',equipment:'barbell',difficulty:'intermediate',sets:4,reps:'8',rest:'120s',muscles_secondary:['upper chest'],tips:'ม้านั่ง 30-45 องศา'},
{id:'c017',name:'Close Grip Bench Press',nameTH:'เบนช์เพรสจับแคบ',muscle:'chest',equipment:'barbell',difficulty:'intermediate',sets:3,reps:'8-10',rest:'90s',muscles_secondary:['triceps'],tips:'เน้น triceps มากกว่า chest'},
// ─── CHEST (extras) ─────────────────────────────────────
{id:'c018',name:'Cable Crossover',nameTH:'Cable Crossover',muscle:'chest',equipment:'cable',difficulty:'intermediate',sets:3,reps:'12-15',rest:'60s',muscles_secondary:['chest'],tips:'ดึงเข้ากลาง บีบหน้าอก'},
{id:'c019',name:'Svend Press',nameTH:'Svend Press',muscle:'chest',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'15',rest:'45s',muscles_secondary:['chest'],tips:'กดฝ่ามือเข้าหากัน ดันออก'},
{id:'c020',name:'Pec Deck',nameTH:'Pec Deck',muscle:'chest',equipment:'machine',difficulty:'beginner',sets:3,reps:'12',rest:'60s',muscles_secondary:['chest'],tips:'บีบสุด ค้าง 1 วินาที'},
// ─── BACK (pullupbar) ───────────────────────────────────
{id:'b001',name:'Pull Up',nameTH:'ดึงข้อ',muscle:'back',equipment:'pullupbar',difficulty:'intermediate',sets:5,reps:'max',rest:'120s',muscles_secondary:['biceps','core'],tips:'ดึงขึ้นจนคางพ้นบาร์'},
{id:'b002',name:'Chin Up',nameTH:'ดึงข้อ Chin Up',muscle:'back',equipment:'pullupbar',difficulty:'intermediate',sets:4,reps:'8-10',rest:'90s',muscles_secondary:['biceps'],tips:'มือหันเข้าหาตัว'},
{id:'b003',name:'Wide Pull Up',nameTH:'ดึงข้อมือกว้าง',muscle:'back',equipment:'pullupbar',difficulty:'advanced',sets:4,reps:'6-8',rest:'120s',muscles_secondary:['lats'],tips:'มือกว้างกว่าไหล่มาก เน้น lats'},
{id:'b004',name:'Commando Pull Up',nameTH:'Commando Pull Up',muscle:'back',equipment:'pullupbar',difficulty:'advanced',sets:3,reps:'6',rest:'120s',muscles_secondary:['biceps','core'],tips:'สลับซ้าย-ขวา ทุก rep'},
{id:'b005',name:'Negative Pull Up',nameTH:'Negative ดึงข้อ',muscle:'back',equipment:'pullupbar',difficulty:'beginner',sets:3,reps:'5',rest:'90s',muscles_secondary:['biceps'],tips:'ลงช้า 3-5 วินาที'},
{id:'b006',name:'Dead Hang',nameTH:'Dead Hang',muscle:'back',equipment:'pullupbar',difficulty:'beginner',sets:3,reps:'20-30s',rest:'60s',muscles_secondary:['forearms','core'],tips:'ห้อยตัวนิ่ง ไหล่ผ่อน'},
{id:'b007',name:'Scapula Pull Up',nameTH:'Scapula Pull Up',muscle:'back',equipment:'pullupbar',difficulty:'beginner',sets:3,reps:'10',rest:'60s',muscles_secondary:['upper back'],tips:'ดึงสะบักลงโดยไม่งอแขน'},
{id:'b008',name:'L-Sit Pull Up',nameTH:'L-Sit Pull Up',muscle:'back',equipment:'pullupbar',difficulty:'advanced',sets:3,reps:'5',rest:'120s',muscles_secondary:['core','hip flexors'],tips:'ยกขาตรงขนานพื้น'},
{id:'b009',name:'Australian Pull Up',nameTH:'Australian Pull Up',muscle:'back',equipment:'pullupbar',difficulty:'beginner',sets:3,reps:'10-15',rest:'60s',muscles_secondary:['biceps'],tips:'บาร์ต่ำ ลำตัวทำมุม 45 องศา'},
{id:'b010',name:'Typewriter Pull Up',nameTH:'Typewriter Pull Up',muscle:'back',equipment:'pullupbar',difficulty:'advanced',sets:3,reps:'4',rest:'120s',muscles_secondary:['biceps','lats'],tips:'เลื่อนตัวซ้าย-ขวาตอนอยู่บนสุด'},
// ─── BACK (dumbbell) ────────────────────────────────────
{id:'b011',name:'Dumbbell Row',nameTH:'ดัมเบล Row',muscle:'back',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'10-12',rest:'60s',muscles_secondary:['biceps','rear delts'],tips:'ดึงดัมเบลขึ้นถึงสะโพก'},
{id:'b012',name:'Dumbbell Deadlift',nameTH:'ดัมเบล Deadlift',muscle:'back',equipment:'dumbbell',difficulty:'intermediate',sets:3,reps:'10',rest:'90s',muscles_secondary:['glutes','hamstrings'],tips:'หลังตรง เข่างอเล็กน้อย'},
{id:'b013',name:'Renegade Row',nameTH:'Renegade Row',muscle:'back',equipment:'dumbbell',difficulty:'intermediate',sets:3,reps:'8ea',rest:'90s',muscles_secondary:['core','biceps'],tips:'อยู่ท่า push up แล้วดึงสลับ'},
{id:'b014',name:'Dumbbell Shrugs',nameTH:'ดัมเบล Shrugs',muscle:'back',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'15',rest:'45s',muscles_secondary:['traps'],tips:'ยักไหล่ขึ้นสูงสุด ค้าง 1 วินาที'},
// ─── BACK (barbell) ─────────────────────────────────────
{id:'b015',name:'Barbell Deadlift',nameTH:'บาร์เบล Deadlift',muscle:'back',equipment:'barbell',difficulty:'intermediate',sets:4,reps:'5',rest:'180s',muscles_secondary:['glutes','hamstrings','core'],tips:'ท่าสำคัญที่สุด หลังตรงเสมอ'},
{id:'b016',name:'Barbell Row',nameTH:'บาร์เบล Row',muscle:'back',equipment:'barbell',difficulty:'intermediate',sets:4,reps:'8',rest:'90s',muscles_secondary:['biceps','rear delts'],tips:'โน้มตัวไปข้างหน้า 45 องศา'},
{id:'b017',name:'Good Morning',nameTH:'Good Morning',muscle:'back',equipment:'barbell',difficulty:'intermediate',sets:3,reps:'10',rest:'90s',muscles_secondary:['hamstrings','glutes'],tips:'น้ำหนักเบา ยืดสะโพก'},
// ─── BACK (extras) ──────────────────────────────────────
{id:'b018',name:'Lat Pulldown',nameTH:'Lat Pulldown',muscle:'back',equipment:'cable',difficulty:'beginner',sets:4,reps:'10-12',rest:'60s',muscles_secondary:['biceps','lats'],tips:'ดึงลงถึงหน้าอก'},
{id:'b019',name:'Seated Cable Row',nameTH:'Seated Cable Row',muscle:'back',equipment:'cable',difficulty:'beginner',sets:3,reps:'10-12',rest:'60s',muscles_secondary:['biceps','rear delts'],tips:'ดึงกลับ บีบสะบัก'},
{id:'b020',name:'T-Bar Row',nameTH:'T-Bar Row',muscle:'back',equipment:'barbell',difficulty:'intermediate',sets:4,reps:'8',rest:'90s',muscles_secondary:['biceps'],tips:'โน้มตัว 45 องศา'},
{id:'b021',name:'Back Extension',nameTH:'Back Extension',muscle:'back',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'15',rest:'45s',muscles_secondary:['lower back','glutes'],tips:'ยกลำตัวขึ้นช้าๆ'},
{id:'b022',name:'Superman',nameTH:'Superman',muscle:'back',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'15',rest:'45s',muscles_secondary:['lower back','glutes'],tips:'นอนคว่ำ ยกแขนขาพร้อมกัน'},
{id:'b023',name:'Inverted Row',nameTH:'Inverted Row',muscle:'back',equipment:'pullupbar',difficulty:'beginner',sets:3,reps:'12-15',rest:'60s',muscles_secondary:['biceps'],tips:'นอนใต้บาร์ ดึงตัวขึ้น'},
// ─── SHOULDERS (bodyweight) ─────────────────────────────
{id:'s001',name:'Pike Push Up',nameTH:'Pike Push Up',muscle:'shoulders',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'10',rest:'60s',muscles_secondary:['triceps'],tips:'ก้นชี้ขึ้น ดันลงจนหัวเกือบแตะพื้น'},
{id:'s002',name:'Wall Handstand Push Up',nameTH:'Handstand Push Up',muscle:'shoulders',equipment:'bodyweight',difficulty:'advanced',sets:3,reps:'5-8',rest:'120s',muscles_secondary:['triceps','core'],tips:'เท้าพิงกำแพง'},
// ─── SHOULDERS (dumbbell) ───────────────────────────────
{id:'s003',name:'Dumbbell Shoulder Press',nameTH:'ดัมเบล Shoulder Press',muscle:'shoulders',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'10-12',rest:'60s',muscles_secondary:['triceps'],tips:'ดันขึ้นตรงๆ อย่าล็อกข้อศอก'},
{id:'s004',name:'Dumbbell Lateral Raise',nameTH:'ดัมเบล Side Raise',muscle:'shoulders',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'12-15',rest:'45s',muscles_secondary:['side delts'],tips:'ยกแขนขึ้นข้างๆ ไม่เกิน 90 องศา'},
{id:'s005',name:'Dumbbell Front Raise',nameTH:'ดัมเบล Front Raise',muscle:'shoulders',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'12',rest:'45s',muscles_secondary:['front delts'],tips:'ยกไปข้างหน้า ไม่เกิน 90 องศา'},
{id:'s006',name:'Dumbbell Arnold Press',nameTH:'Arnold Press',muscle:'shoulders',equipment:'dumbbell',difficulty:'intermediate',sets:3,reps:'10',rest:'60s',muscles_secondary:['all delts'],tips:'หมุนฝ่ามือขณะดันขึ้น'},
// ─── SHOULDERS (cable / barbell / band) ─────────────────
{id:'s007',name:'Face Pull',nameTH:'Face Pull',muscle:'shoulders',equipment:'cable',difficulty:'beginner',sets:3,reps:'15',rest:'45s',muscles_secondary:['rear delts','rotator cuff'],tips:'ดึงระดับหน้า แยกข้อศอก'},
{id:'s008',name:'Barbell Overhead Press',nameTH:'บาร์เบล Overhead Press',muscle:'shoulders',equipment:'barbell',difficulty:'intermediate',sets:4,reps:'8',rest:'90s',muscles_secondary:['triceps','core'],tips:'ดันขึ้นเหนือหัว หัวโผล่ออกมา'},
{id:'s009',name:'Upright Row',nameTH:'Upright Row',muscle:'shoulders',equipment:'barbell',difficulty:'intermediate',sets:3,reps:'10',rest:'60s',muscles_secondary:['traps','biceps'],tips:'ดึงขึ้นถึงระดับคาง'},
{id:'s010',name:'Band Pull Apart',nameTH:'Band Pull Apart',muscle:'shoulders',equipment:'band',difficulty:'beginner',sets:3,reps:'15-20',rest:'30s',muscles_secondary:['rear delts'],tips:'ดึงให้กว้างสุด ค้าง 1 วินาที'},
// ─── LEGS (bodyweight) ──────────────────────────────────
{id:'l001',name:'Squat',nameTH:'Squat',muscle:'legs',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'15-20',rest:'60s',muscles_secondary:['glutes','core'],tips:'หัวเข่าตามนิ้วเท้า ก้นลงถึง 90 องศา'},
{id:'l002',name:'Jump Squat',nameTH:'กระโดด Squat',muscle:'legs',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'10-15',rest:'60s',muscles_secondary:['glutes','calves'],tips:'กระโดดขึ้นแรงๆ'},
{id:'l003',name:'Pistol Squat',nameTH:'Pistol Squat',muscle:'legs',equipment:'bodyweight',difficulty:'advanced',sets:3,reps:'5ea',rest:'90s',muscles_secondary:['balance','core'],tips:'ยื่นขาตรงไปข้างหน้า นั่งขาเดียว'},
{id:'l004',name:'Bulgarian Split Squat',nameTH:'Bulgarian Split Squat',muscle:'legs',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'10ea',rest:'60s',muscles_secondary:['glutes','balance'],tips:'เท้าหลังวางบนม้านั่ง'},
{id:'l005',name:'Lunge',nameTH:'Lunge',muscle:'legs',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'12ea',rest:'60s',muscles_secondary:['glutes','core'],tips:'เข่าหน้าไม่เกินปลายเท้า'},
{id:'l006',name:'Reverse Lunge',nameTH:'Reverse Lunge',muscle:'legs',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'12ea',rest:'60s',muscles_secondary:['glutes'],tips:'ก้าวถอยหลัง'},
{id:'l007',name:'Step Up',nameTH:'Step Up',muscle:'legs',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'15ea',rest:'60s',muscles_secondary:['glutes'],tips:'ก้าวขึ้นขั้นบันได/กล่อง'},
{id:'l008',name:'Wall Sit',nameTH:'Wall Sit',muscle:'legs',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'30-60s',rest:'60s',muscles_secondary:['core'],tips:'หลังพิงกำแพง เข่า 90 องศา'},
{id:'l009',name:'Calf Raise',nameTH:'Calf Raise',muscle:'legs',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'20-30',rest:'45s',muscles_secondary:['calves'],tips:'ยืนหัวเท้า ยกขึ้นช้าๆ'},
{id:'l010',name:'Glute Bridge',nameTH:'Glute Bridge',muscle:'legs',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'15',rest:'45s',muscles_secondary:['glutes','hamstrings'],tips:'ยกสะโพกขึ้นสูงสุด บีบก้น'},
{id:'l011',name:'Single Leg Glute Bridge',nameTH:'Glute Bridge ขาเดียว',muscle:'legs',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'12ea',rest:'60s',muscles_secondary:['glutes'],tips:'ยกขาหนึ่งขึ้น'},
{id:'l012',name:'Nordic Hamstring Curl',nameTH:'Nordic Curl',muscle:'legs',equipment:'bodyweight',difficulty:'advanced',sets:3,reps:'5-8',rest:'120s',muscles_secondary:['hamstrings'],tips:'ให้คนจับเท้าไว้ ลำตัวค่อยๆ ล้มลง'},
{id:'l013',name:'Box Jump',nameTH:'กระโดด Box',muscle:'legs',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'8',rest:'90s',muscles_secondary:['calves','explosive'],tips:'กระโดดขึ้นกล่อง ลงนุ่มๆ'},
{id:'l021',name:'Sumo Squat',nameTH:'Sumo Squat',muscle:'legs',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'15',rest:'45s',muscles_secondary:['inner thigh','glutes'],tips:'เท้ากว้าง ชี้ออกนอก'},
{id:'l022',name:'Sissy Squat',nameTH:'Sissy Squat',muscle:'legs',equipment:'bodyweight',difficulty:'advanced',sets:3,reps:'10',rest:'60s',muscles_secondary:['quads'],tips:'เข่าไปข้างหน้า ตัวเอนหลัง'},
{id:'l023',name:'Hip Thrust',nameTH:'Hip Thrust',muscle:'legs',equipment:'bodyweight',difficulty:'intermediate',sets:4,reps:'15',rest:'60s',muscles_secondary:['glutes'],tips:'หลังพิงม้านั่ง ยกสะโพก'},
// ─── LEGS (dumbbell) ────────────────────────────────────
{id:'l014',name:'Dumbbell Squat',nameTH:'Squat ดัมเบล',muscle:'legs',equipment:'dumbbell',difficulty:'beginner',sets:4,reps:'10-12',rest:'90s',muscles_secondary:['glutes','core'],tips:'ถือดัมเบลสองข้าง'},
{id:'l015',name:'Dumbbell Lunges',nameTH:'Lunge ดัมเบล',muscle:'legs',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'12ea',rest:'60s',muscles_secondary:['glutes'],tips:'ถือดัมเบลสองข้าง เดินก้าวยาว'},
{id:'l016',name:'Dumbbell Romanian Deadlift',nameTH:'RDL ดัมเบล',muscle:'legs',equipment:'dumbbell',difficulty:'intermediate',sets:3,reps:'10',rest:'90s',muscles_secondary:['hamstrings','glutes'],tips:'หลังตรง โน้มตัวลง'},
{id:'l024',name:'Dumbbell Hip Thrust',nameTH:'Hip Thrust ดัมเบล',muscle:'legs',equipment:'dumbbell',difficulty:'intermediate',sets:4,reps:'12',rest:'60s',muscles_secondary:['glutes'],tips:'วางดัมเบลบนสะโพก'},
// ─── LEGS (barbell) ─────────────────────────────────────
{id:'l017',name:'Barbell Back Squat',nameTH:'Back Squat',muscle:'legs',equipment:'barbell',difficulty:'intermediate',sets:4,reps:'5-8',rest:'180s',muscles_secondary:['glutes','core'],tips:'บาร์บนสะบัก นั่งลึก'},
{id:'l018',name:'Barbell Front Squat',nameTH:'Front Squat',muscle:'legs',equipment:'barbell',difficulty:'advanced',sets:4,reps:'6',rest:'180s',muscles_secondary:['core','upper back'],tips:'บาร์ด้านหน้าไหล่'},
{id:'l026',name:'Romanian Deadlift',nameTH:'Romanian Deadlift',muscle:'legs',equipment:'barbell',difficulty:'intermediate',sets:4,reps:'8',rest:'90s',muscles_secondary:['hamstrings','lower back'],tips:'หลังตรง ก้มตัวลงช้าๆ'},
// ─── LEGS (machine / kettlebell) ────────────────────────
{id:'l019',name:'Leg Press',nameTH:'Leg Press',muscle:'legs',equipment:'machine',difficulty:'beginner',sets:4,reps:'12',rest:'90s',muscles_secondary:['glutes'],tips:'วางเท้ากว้างพอดี'},
{id:'l020',name:'Leg Curl',nameTH:'Leg Curl',muscle:'legs',equipment:'machine',difficulty:'beginner',sets:3,reps:'12',rest:'60s',muscles_secondary:['hamstrings'],tips:'งอเข่าช้าๆ'},
{id:'l025',name:'Hack Squat',nameTH:'Hack Squat',muscle:'legs',equipment:'machine',difficulty:'intermediate',sets:4,reps:'10',rest:'90s',muscles_secondary:['quads'],tips:'เท้าข้างหน้า นั่งลึก'},
{id:'l027',name:'Goblet Squat',nameTH:'Goblet Squat',muscle:'legs',equipment:'kettlebell',difficulty:'beginner',sets:3,reps:'12',rest:'60s',muscles_secondary:['core','glutes'],tips:'ถือ KB หน้าอก นั่งลึก'},
// ─── CORE (bodyweight) ──────────────────────────────────
{id:'co001',name:'Plank',nameTH:'Plank',muscle:'core',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'30-60s',rest:'45s',muscles_secondary:['shoulders','glutes'],tips:'ลำตัวตรง ไม่ยกก้น'},
{id:'co002',name:'Sit Up',nameTH:'ซิทอัพ',muscle:'core',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'20-30',rest:'45s',muscles_secondary:['hip flexors'],tips:'งอเข่า มือประสานหลังศีรษะ'},
{id:'co003',name:'Crunch',nameTH:'Crunch',muscle:'core',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'20-25',rest:'30s',muscles_secondary:['upper abs'],tips:'ยกแค่ไหล่ ไม่ดึงคอ'},
{id:'co004',name:'Leg Raise',nameTH:'Leg Raise',muscle:'core',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'12-15',rest:'45s',muscles_secondary:['lower abs','hip flexors'],tips:'หลังแนบพื้น ขาตรง'},
{id:'co006',name:'Russian Twist',nameTH:'Russian Twist',muscle:'core',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'20',rest:'45s',muscles_secondary:['obliques'],tips:'ยกเท้าขึ้น หมุนลำตัว'},
{id:'co007',name:'Mountain Climber',nameTH:'Mountain Climber',muscle:'core',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'30s',rest:'30s',muscles_secondary:['cardio','shoulders'],tips:'สลับเข่าเร็วๆ'},
{id:'co008',name:'Bicycle Crunch',nameTH:'Bicycle Crunch',muscle:'core',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'20',rest:'30s',muscles_secondary:['obliques'],tips:'สลับศอก-เข่า ช้าๆ'},
{id:'co009',name:'Side Plank',nameTH:'Side Plank',muscle:'core',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'30s ea',rest:'30s',muscles_secondary:['obliques','glutes'],tips:'ลำตัวตรง ไม่โค้ง'},
{id:'co010',name:'Hollow Body Hold',nameTH:'Hollow Body',muscle:'core',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'30-45s',rest:'60s',muscles_secondary:['hip flexors'],tips:'กดหลังลงพื้น แขนขาขึ้น'},
{id:'co011',name:'Dragon Flag',nameTH:'Dragon Flag',muscle:'core',equipment:'bodyweight',difficulty:'advanced',sets:3,reps:'5-8',rest:'120s',muscles_secondary:['lower abs'],tips:'ท่า Bruce Lee กดไหล่ยกตัวขึ้น'},
{id:'co012',name:'L-Sit',nameTH:'L-Sit',muscle:'core',equipment:'bodyweight',difficulty:'advanced',sets:3,reps:'10-20s',rest:'90s',muscles_secondary:['hip flexors','triceps'],tips:'ยกตัวขึ้น ขาตรงขนานพื้น'},
{id:'co013',name:'Ab Wheel Rollout',nameTH:'Ab Wheel',muscle:'core',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'8-10',rest:'60s',muscles_secondary:['shoulders','back'],tips:'คุกเข่า ดันล้อออกช้าๆ'},
{id:'co016',name:'V-Up',nameTH:'V-Up',muscle:'core',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'15',rest:'45s',muscles_secondary:['hip flexors'],tips:'ยกแขนและขาพร้อมกัน'},
{id:'co017',name:'Flutter Kick',nameTH:'Flutter Kick',muscle:'core',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'30s',rest:'30s',muscles_secondary:['lower abs'],tips:'ขาตรง สลับขึ้นลงเร็ว'},
{id:'co018',name:'Dead Bug',nameTH:'Dead Bug',muscle:'core',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'10ea',rest:'45s',muscles_secondary:['core'],tips:'หลังแนบพื้นตลอด'},
{id:'co020',name:'Plank Reach',nameTH:'Plank Reach',muscle:'core',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'10ea',rest:'45s',muscles_secondary:['shoulders'],tips:'อยู่ท่า Plank ยื่นแขนออก'},
// ─── CORE (pullupbar) ───────────────────────────────────
{id:'co005',name:'Hanging Leg Raise',nameTH:'Hanging Leg Raise',muscle:'core',equipment:'pullupbar',difficulty:'intermediate',sets:3,reps:'10-12',rest:'60s',muscles_secondary:['lower abs','grip'],tips:'ห้อยบาร์ ยกขาตรงขึ้น'},
{id:'co014',name:'Windshield Wiper',nameTH:'Windshield Wiper',muscle:'core',equipment:'pullupbar',difficulty:'advanced',sets:3,reps:'8',rest:'90s',muscles_secondary:['obliques'],tips:'ห้อยบาร์ แกว่งขาซ้าย-ขวา'},
{id:'co015',name:'Toes to Bar',nameTH:'Toes to Bar',muscle:'core',equipment:'pullupbar',difficulty:'advanced',sets:3,reps:'8-10',rest:'60s',muscles_secondary:['hip flexors'],tips:'ห้อยบาร์ ยกปลายเท้าแตะบาร์'},
// ─── CORE (cable) ───────────────────────────────────────
{id:'co019',name:'Pallof Press',nameTH:'Pallof Press',muscle:'core',equipment:'cable',difficulty:'intermediate',sets:3,reps:'12',rest:'45s',muscles_secondary:['obliques'],tips:'ยืนข้างเคเบิ้ล ดันออก-เข้า'},
// ─── ARMS (bodyweight) ──────────────────────────────────
{id:'a001',name:'Dips',nameTH:'Dips',muscle:'arms',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'10-15',rest:'60s',muscles_secondary:['chest','triceps'],tips:'ลงจนแขนงอ 90 องศา'},
{id:'a002',name:'Diamond Push Up (Arms)',nameTH:'Diamond Push Up เน้นแขน',muscle:'arms',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'10',rest:'60s',muscles_secondary:['triceps','chest'],tips:'มือชิด รูปข้าวหลามตัด เน้น triceps'},
{id:'a003',name:'Tricep Push Up',nameTH:'Tricep Push Up',muscle:'arms',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'12',rest:'60s',muscles_secondary:['triceps'],tips:'ข้อศอกชิดลำตัว'},
{id:'a015',name:'Wrist Roller',nameTH:'Wrist Roller',muscle:'arms',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'3 รอบ',rest:'60s',muscles_secondary:['forearms'],tips:'ม้วนเส้นลวดขึ้น-ลง'},
// ─── ARMS (pullupbar) ───────────────────────────────────
{id:'a012',name:'Close Grip Chin Up',nameTH:'Close Grip Chin Up',muscle:'arms',equipment:'pullupbar',difficulty:'intermediate',sets:3,reps:'8-10',rest:'90s',muscles_secondary:['biceps'],tips:'มือชิด หันเข้าหาตัว'},
// ─── ARMS (dumbbell) ────────────────────────────────────
{id:'a004',name:'Dumbbell Curl',nameTH:'ดัมเบล Curl',muscle:'arms',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'10-12',rest:'45s',muscles_secondary:['biceps'],tips:'ข้อศอกอยู่กับที่ หมุนข้อมือ'},
{id:'a005',name:'Hammer Curl',nameTH:'Hammer Curl',muscle:'arms',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'10-12',rest:'45s',muscles_secondary:['biceps','brachialis'],tips:'นิ้วหัวแม่มือชี้ขึ้น'},
{id:'a006',name:'Concentration Curl',nameTH:'Concentration Curl',muscle:'arms',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'12',rest:'45s',muscles_secondary:['biceps'],tips:'ข้อศอกพิงต้นขา'},
{id:'a007',name:'Tricep Overhead Extension',nameTH:'Tricep Extension',muscle:'arms',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'12',rest:'45s',muscles_secondary:['triceps'],tips:'ดัมเบลเหนือหัว งอข้อศอกลง'},
// ─── ARMS (barbell) ─────────────────────────────────────
{id:'a008',name:'Skull Crusher',nameTH:'Skull Crusher',muscle:'arms',equipment:'barbell',difficulty:'intermediate',sets:3,reps:'10',rest:'60s',muscles_secondary:['triceps'],tips:'นอนราบ งอข้อศอกลงหน้าผาก'},
{id:'a009',name:'Barbell Curl',nameTH:'บาร์เบล Curl',muscle:'arms',equipment:'barbell',difficulty:'beginner',sets:3,reps:'10',rest:'60s',muscles_secondary:['biceps'],tips:'ข้อศอกอยู่กับที่'},
// ─── ARMS (cable) ───────────────────────────────────────
{id:'a010',name:'Tricep Pushdown',nameTH:'Tricep Pushdown',muscle:'arms',equipment:'cable',difficulty:'beginner',sets:3,reps:'12-15',rest:'45s',muscles_secondary:['triceps'],tips:'ข้อศอกชิดลำตัว ดันลงตรงๆ'},
{id:'a011',name:'Cable Curl',nameTH:'Cable Curl',muscle:'arms',equipment:'cable',difficulty:'beginner',sets:3,reps:'12',rest:'45s',muscles_secondary:['biceps'],tips:'ยืน tension สม่ำเสมอ'},
// ─── ARMS (band) ────────────────────────────────────────
{id:'a013',name:'Band Curl',nameTH:'Band Curl',muscle:'arms',equipment:'band',difficulty:'beginner',sets:3,reps:'15',rest:'30s',muscles_secondary:['biceps'],tips:'เหยียบยางยืด'},
{id:'a014',name:'Band Tricep Extension',nameTH:'Band Tricep Extension',muscle:'arms',equipment:'band',difficulty:'beginner',sets:3,reps:'15',rest:'30s',muscles_secondary:['triceps'],tips:'จับยางยืดเหนือหัว'},
// ─── CARDIO (cardio equipment) ──────────────────────────
{id:'ca001',name:'Running',nameTH:'วิ่ง',muscle:'cardio',equipment:'cardio',difficulty:'beginner',sets:1,reps:'20-30 นาที',rest:'–',muscles_secondary:['legs','core'],tips:'วิ่งได้คุยได้ = pace ดี'},
{id:'ca002',name:'Sprints',nameTH:'Sprint',muscle:'cardio',equipment:'cardio',difficulty:'intermediate',sets:8,reps:'100m',rest:'90s',muscles_secondary:['legs','explosive'],tips:'วิ่งเต็มที่ พักเท่ากัน'},
{id:'ca003',name:'HIIT Run',nameTH:'HIIT วิ่ง',muscle:'cardio',equipment:'cardio',difficulty:'intermediate',sets:8,reps:'30s sprint/30s เดิน',rest:'–',muscles_secondary:['legs','cardio'],tips:'20 นาที เผาไขมันดีมาก'},
{id:'ca004',name:'Jump Rope',nameTH:'กระโดดเชือก',muscle:'cardio',equipment:'cardio',difficulty:'beginner',sets:5,reps:'60s',rest:'30s',muscles_secondary:['calves','shoulders'],tips:'กระโดดเท้าชิด'},
{id:'ca007',name:'Walking',nameTH:'เดิน',muscle:'cardio',equipment:'cardio',difficulty:'beginner',sets:1,reps:'30-60 นาที',rest:'–',muscles_secondary:['legs'],tips:'เดินเร็ว 6-7 กม./ชม.'},
{id:'ca008',name:'Cycling',nameTH:'ปั่นจักรยาน',muscle:'cardio',equipment:'cardio',difficulty:'beginner',sets:1,reps:'30-45 นาที',rest:'–',muscles_secondary:['legs','cardio'],tips:'resistance ปานกลาง'},
{id:'ca011',name:'Battle Ropes',nameTH:'Battle Ropes',muscle:'cardio',equipment:'cardio',difficulty:'intermediate',sets:5,reps:'30s',rest:'30s',muscles_secondary:['shoulders','core'],tips:'สลับแขนเร็วๆ'},
{id:'ca012',name:'Sled Push',nameTH:'Sled Push',muscle:'cardio',equipment:'cardio',difficulty:'intermediate',sets:4,reps:'20m',rest:'60s',muscles_secondary:['legs','core'],tips:'โน้มตัวดัน'},
{id:'ca013',name:'Tire Flip',nameTH:'Tire Flip',muscle:'cardio',equipment:'cardio',difficulty:'advanced',sets:5,reps:'5',rest:'90s',muscles_secondary:['full body'],tips:'ยกพลิกยางรถ'},
// ─── CARDIO (bodyweight) ────────────────────────────────
{id:'ca005',name:'Burpee',nameTH:'Burpee',muscle:'cardio',equipment:'bodyweight',difficulty:'intermediate',sets:4,reps:'10-15',rest:'60s',muscles_secondary:['full body'],tips:'Full body movement ดีมาก'},
{id:'ca006',name:'Bear Crawl',nameTH:'Bear Crawl',muscle:'cardio',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'20m',rest:'45s',muscles_secondary:['core','shoulders'],tips:'คุกเข่าอย่าแตะพื้น'},
{id:'ca009',name:'Jump Jack',nameTH:'Jumping Jacks',muscle:'cardio',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'30-50',rest:'30s',muscles_secondary:['shoulders','legs'],tips:'Warmup ที่ดี'},
{id:'ca010',name:'High Knees',nameTH:'High Knees',muscle:'cardio',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'30s',rest:'30s',muscles_secondary:['core','legs'],tips:'ยกเข่าสูงสุด'},
{id:'ca015',name:'Box Step Up',nameTH:'Box Step Up',muscle:'cardio',equipment:'bodyweight',difficulty:'beginner',sets:3,reps:'15ea',rest:'45s',muscles_secondary:['legs','cardio'],tips:'สลับขา เร็วๆ'},
// ─── CARDIO (dumbbell) ──────────────────────────────────
{id:'ca014',name:'Farmer Walk',nameTH:'Farmer Walk',muscle:'cardio',equipment:'dumbbell',difficulty:'beginner',sets:3,reps:'40m',rest:'60s',muscles_secondary:['grip','core','legs'],tips:'ถือดัมเบลหนัก เดินตัวตรง'},
// ─── FULL BODY COMPOUND ─────────────────────────────────
{id:'f001',name:'Burpee Pull Up',nameTH:'Burpee Pull Up',muscle:'chest',equipment:'pullupbar',difficulty:'advanced',sets:3,reps:'8',rest:'120s',muscles_secondary:['full body'],tips:'Burpee แล้วกระโดดขึ้นดึงบาร์'},
{id:'f002',name:'Man Maker',nameTH:'Man Maker',muscle:'chest',equipment:'dumbbell',difficulty:'advanced',sets:3,reps:'6',rest:'120s',muscles_secondary:['full body'],tips:'Push up + Row + Squat + Press'},
{id:'f003',name:'Turkish Get Up',nameTH:'Turkish Get Up',muscle:'core',equipment:'kettlebell',difficulty:'advanced',sets:3,reps:'5ea',rest:'90s',muscles_secondary:['full body'],tips:'เคลื่อนที่ช้าๆ ควบคุม'},
{id:'f004',name:'Kettlebell Swing',nameTH:'Kettlebell Swing',muscle:'legs',equipment:'kettlebell',difficulty:'intermediate',sets:4,reps:'15-20',rest:'60s',muscles_secondary:['glutes','core','cardio'],tips:'ดึงด้วยสะโพก ไม่ใช่แขน'},
{id:'f005',name:'Kettlebell Clean',nameTH:'Kettlebell Clean',muscle:'legs',equipment:'kettlebell',difficulty:'intermediate',sets:3,reps:'8ea',rest:'90s',muscles_secondary:['shoulders','core'],tips:'ดึงขึ้นติดลำตัว'},
{id:'f006',name:'Thrusters',nameTH:'Thrusters',muscle:'legs',equipment:'barbell',difficulty:'advanced',sets:4,reps:'8',rest:'120s',muscles_secondary:['shoulders','core'],tips:'Squat + Overhead Press ต่อเนื่อง'},
{id:'f007',name:'Clean and Jerk',nameTH:'Clean and Jerk',muscle:'legs',equipment:'barbell',difficulty:'advanced',sets:5,reps:'3',rest:'180s',muscles_secondary:['full body'],tips:'Olympic lift ต้องฝึกกับผู้เชี่ยวชาญ'},
{id:'f008',name:'Sandbag Carry',nameTH:'แบกทราย',muscle:'core',equipment:'bodyweight',difficulty:'intermediate',sets:3,reps:'50m',rest:'60s',muscles_secondary:['full body'],tips:'ฝึกความทนทาน'},
];

// ───────────────────────────────────────────────────────────
// INDEXING
// ───────────────────────────────────────────────────────────

const MUSCLE_GROUPS  = ['chest','back','legs','shoulders','core','arms','cardio'];
const EQUIPMENT_LIST = ['bodyweight','pullupbar','dumbbell','barbell','cable','kettlebell','machine','band','cardio'];

function getExercisesFor(equipment=[]) {
  if (!equipment.length) return EXERCISE_DB;
  return EXERCISE_DB.filter(ex =>
    ex.equipment === 'bodyweight' || equipment.includes(ex.equipment)
  );
}

function filterDB({ muscle='', equipment='', difficulty='' }={}) {
  return EXERCISE_DB.filter(ex =>
    (!muscle     || ex.muscle     === muscle)     &&
    (!equipment  || ex.equipment  === equipment)  &&
    (!difficulty || ex.difficulty === difficulty)
  );
}

function getByMuscle(muscle, equipment=[]) {
  const avail = getExercisesFor(equipment);
  return avail.filter(ex => ex.muscle === muscle);
}

function countByMuscle() {
  const counts = {};
  MUSCLE_GROUPS.forEach(m => counts[m] = EXERCISE_DB.filter(e => e.muscle === m).length);
  return counts;
}

// ───────────────────────────────────────────────────────────
// DEV VALIDATION
// ───────────────────────────────────────────────────────────

(function validateDB() {
  const ids = EXERCISE_DB.map(e => e.id);
  const dup = ids.filter((id, i) => ids.indexOf(id) !== i);
  if (dup.length) {
    console.warn('⚠️  Duplicate IDs detected:', dup);
  } else {
    console.log(`✅ No duplicate IDs found (${ids.length} unique)`);
  }
})();

// ───────────────────────────────────────────────────────────
// EXPOSE TO WINDOW (Fix for strict/defer scope)
// ───────────────────────────────────────────────────────────

window.EXERCISE_DB    = EXERCISE_DB;
window.ExerciseDB     = EXERCISE_DB;
window.exerciseDB     = EXERCISE_DB;

window.MUSCLE_GROUPS  = MUSCLE_GROUPS;
window.EQUIPMENT_LIST = EQUIPMENT_LIST;

window.getExercisesFor = getExercisesFor;
window.filterDB        = filterDB;
window.getByMuscle     = getByMuscle;
window.countByMuscle   = countByMuscle;

console.log('🏋️  Exercise DB Ready:', EXERCISE_DB.length, 'exercises');
