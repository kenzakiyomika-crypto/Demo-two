/* ================================================================
   PROFILE MANAGER — profile/profileManager.js
   Operator Military RPG v2

   จัดการ Multi-Profile:
   - สร้าง / แก้ไข / ลบ โปรไฟล์
   - สลับโปรไฟล์ active
   - Sync กับ AttributeEngine + RankSystem + GoalEngine
   - โปรไฟล์แต่ละคนมี state แยกกันสมบูรณ์
   ================================================================ */
'use strict';

const ProfileManager = (() => {

  /* ----------------------------------------------------------
     DEFAULT PROFILE TEMPLATE
  ---------------------------------------------------------- */
  function _defaultProfile(name, id) {
    return {
      id,
      name,
      createdAt: Date.now(),
      updatedAt: Date.now(),

      bodyProfile: {
        age: 0,
        weight: 0,
        height: 0,
        fitnessLevel: 'beginner',
      },

      goalConfig: {
        primaryGoal:   'hybrid',
        secondaryGoal: null,
        bodyFocus:     { upper: 2, lower: 2, core: 1, cardio: 1 },
        baseline:      {},
        daysPerWeek:   4,
      },

      // RPG Attributes — sync กับ attributeEngine per profile
      attributes: {
        STR:  { pts: 0, level: 1 },
        END:  { pts: 0, level: 1 },
        SPD:  { pts: 0, level: 1 },
        POW:  { pts: 0, level: 1 },
        DISC: { pts: 0, level: 1 },
        PRC:  { pts: 0, level: 1 },
        STA:  { pts: 0, level: 1 },
      },

      // Rank
      rank: {
        currentRankId: 0,
        unlockedMissions: [],
        sfAchieved: [],
        physicalTests: {},
        rankHistory: [],
        totalSessions: 0,
      },

      // Medals
      medals: [],

      // Cycle state
      cycle: {
        currentWeek: 1,
        totalWeeks:  4,
        startDate:   null,
        cycleHistory: [],
      },

      // Streak + DISC
      streak: 0,
      lastWorkoutDate: null,
      fatigueScore: 0,

      // Stats
      stats: {
        totalSessions: 0,
        totalVolume:   0,
        totalReps:     0,
        longestStreak: 0,
      },
    };
  }

  /* ----------------------------------------------------------
     CREATE PROFILE
  ---------------------------------------------------------- */
  function createProfile(name, bodyData = {}, goalConfig = {}) {
    if (!name?.trim()) return { success: false, error: 'กรุณากรอกชื่อ' };

    const id = _generateId();
    const profile = _defaultProfile(name.trim(), id);

    // Merge body data
    if (bodyData.age)    profile.bodyProfile.age    = +bodyData.age;
    if (bodyData.weight) profile.bodyProfile.weight = +bodyData.weight;
    if (bodyData.height) profile.bodyProfile.height = +bodyData.height;
    if (bodyData.fitnessLevel) profile.bodyProfile.fitnessLevel = bodyData.fitnessLevel;

    // Merge goal config
    if (goalConfig.primaryGoal)   profile.goalConfig.primaryGoal   = goalConfig.primaryGoal;
    if (goalConfig.secondaryGoal) profile.goalConfig.secondaryGoal = goalConfig.secondaryGoal;
    if (goalConfig.bodyFocus)     profile.goalConfig.bodyFocus      = goalConfig.bodyFocus;
    if (goalConfig.baseline)      profile.goalConfig.baseline       = goalConfig.baseline;
    if (goalConfig.daysPerWeek)   profile.goalConfig.daysPerWeek    = +goalConfig.daysPerWeek;

    // Set cycle start date
    profile.cycle.startDate = new Date().toISOString().split('T')[0];

    StorageEngine.saveProfile(profile);
    return { success: true, id, profile };
  }

  /* ----------------------------------------------------------
     GET / SET ACTIVE PROFILE
  ---------------------------------------------------------- */
  function setActive(id) {
    const profile = StorageEngine.getProfile(id);
    if (!profile) return false;

    StorageEngine.setActiveProfileId(id);
    _syncEngines(profile);
    return true;
  }

  function getActive() {
    const id = StorageEngine.getActiveProfileId();
    if (!id) return null;
    return StorageEngine.getProfile(id);
  }

  function getActiveId() {
    return StorageEngine.getActiveProfileId();
  }

  function getAllProfiles() {
    return StorageEngine.loadAllProfiles();
  }

  function hasAnyProfile() {
    return Object.keys(StorageEngine.loadAllProfiles()).length > 0;
  }

  function hasActiveProfile() {
    const id = StorageEngine.getActiveProfileId();
    if (!id) return false;
    return !!StorageEngine.getProfile(id);
  }

  /* ----------------------------------------------------------
     UPDATE PROFILE
  ---------------------------------------------------------- */
  function updateProfile(id, changes) {
    const profile = StorageEngine.getProfile(id);
    if (!profile) return false;

    const updated = _deepMerge(profile, changes);
    updated.updatedAt = Date.now();
    StorageEngine.saveProfile(updated);

    if (id === StorageEngine.getActiveProfileId()) {
      _syncEngines(updated);
    }
    return true;
  }

  function deleteProfile(id) {
    return StorageEngine.deleteProfile(id);
  }

  /* ----------------------------------------------------------
     SYNC ENGINES — โหลด state ของโปรไฟล์เข้า Engines
     เรียกทุกครั้งที่ switch profile
     ใช้ per-profile keys ให้ตรงกับที่ engines ใช้
  ---------------------------------------------------------- */
  function _syncEngines(profile) {
    const pid = profile.id;

    // Sync AttributeEngine — ใช้ key เดียวกับที่ attributeEngine._storageKey() ผลิต
    localStorage.setItem(
      `operator_attributes_${pid}`,
      JSON.stringify(profile.attributes)
    );

    // Sync RankSystem — ใช้ key เดียวกับที่ rankSystem._key() ผลิต
    localStorage.setItem(
      `operator_rank_${pid}`,
      JSON.stringify({
        currentRankId:    profile.rank.currentRankId,
        unlockedMissions: profile.rank.unlockedMissions,
        sfAchieved:       profile.rank.sfAchieved,
        physicalTests:    profile.rank.physicalTests,
        history:          profile.rank.rankHistory,
        totalSessions:    profile.rank.totalSessions,
      })
    );

    // Sync MedalSystem career key
    // (only if medal data exists in profile)
    if (profile.medals && profile.medals.length) {
      const existing = localStorage.getItem(`operator_career_${pid}`);
      if (!existing) {
        localStorage.setItem(`operator_career_${pid}`, JSON.stringify({
          totalSessions: profile.stats?.totalSessions || 0,
          earnedMedals:  profile.medals,
          sfAchieved:    profile.rank?.sfAchieved || [],
        }));
      }
    }

    // Sync GoalEngine — per-profile key (matches goalEngine._storageKey())
    const goalPayload = JSON.stringify({ ...profile.goalConfig, savedAt: Date.now() });
    localStorage.setItem(`operator_goal_${pid}`, goalPayload);
    // Compat key for legacy app.js reads
    localStorage.setItem('operator_goal_config_v1', goalPayload);

    // Sync compat keys for app.js (reads 'profile' and 'profile_v1')
    const profileCompat = {
      name:        profile.name,
      age:         profile.bodyProfile.age,
      weight:      profile.bodyProfile.weight,
      height:      profile.bodyProfile.height,
      fitness:     profile.bodyProfile.fitnessLevel,
      fitnessLevel:profile.bodyProfile.fitnessLevel,
      goal:        profile.goalConfig?.primaryGoal || 'hybrid',
    };
    localStorage.setItem('profile',    JSON.stringify(profileCompat));
    localStorage.setItem('profile_v1', JSON.stringify(profileCompat));

    // Set active profile id
    localStorage.setItem('operator_active_profile', pid);

    console.log(`%c[ProfileManager] Switched to: ${profile.name} (${pid})`, 'color:#78cc55');
  }

  /* ----------------------------------------------------------
     SAVE STATE BACK TO PROFILE
     เรียกหลัง workout session เพื่อ sync engines → profile
  ---------------------------------------------------------- */
  function saveStateToProfile() {
    const id      = StorageEngine.getActiveProfileId();
    const profile = StorageEngine.getProfile(id);
    if (!id || !profile) return false;

    // Pull from AttributeEngine — per-profile key
    try {
      const attrRaw = localStorage.getItem(`operator_attributes_${id}`);
      if (attrRaw) profile.attributes = JSON.parse(attrRaw);
    } catch {}

    // Pull GoalEngine config — per-profile key
    try {
      const goalRaw = localStorage.getItem(`operator_goal_${id}`);
      if (goalRaw) {
        const g = JSON.parse(goalRaw);
        profile.goalConfig = { ...profile.goalConfig, ...g };
        delete profile.goalConfig.savedAt;
      }
    } catch {}

    // Pull from RankSystem — per-profile key
    try {
      const rankRaw = localStorage.getItem(`operator_rank_${id}`);
      if (rankRaw) {
        const r = JSON.parse(rankRaw);
        profile.rank.currentRankId    = r.currentRankId || 0;
        profile.rank.unlockedMissions = r.unlockedMissions || [];
        profile.rank.sfAchieved       = r.sfAchieved || [];
        profile.rank.physicalTests    = r.physicalTests || {};
        profile.rank.rankHistory      = r.history || [];
        profile.rank.totalSessions    = r.totalSessions || 0;
      }
    } catch {}

    // Pull engine state (streak, fatigue etc.) — profile-aware key
    try {
      const engKey = id ? `operator_production_${id}` : 'operator_production_v1';
      const engRaw = localStorage.getItem(engKey);
      if (engRaw) {
        const eng = JSON.parse(engRaw);
        profile.streak          = eng.streak || 0;
        profile.lastWorkoutDate = eng.lastWorkoutDate || null;
        profile.fatigueScore    = eng.fatigueScore || 0;
        profile.stats.totalSessions = eng.totalSessions || profile.stats.totalSessions;
      }
    } catch {}

    profile.updatedAt = Date.now();
    StorageEngine.saveProfile(profile);
    return true;
  }

  /* ----------------------------------------------------------
     STREAK UPDATE — เรียกทุกวันหรือหลัง workout
  ---------------------------------------------------------- */
  function updateStreak(profileId) {
    const profile = StorageEngine.getProfile(profileId);
    if (!profile) return;

    const today    = new Date().toISOString().split('T')[0];
    const lastDate = profile.lastWorkoutDate;

    if (!lastDate) {
      profile.streak = 1;
    } else {
      const d1 = new Date(today);
      const d2 = new Date(lastDate);
      const diffDays = (isNaN(d1) || isNaN(d2))
        ? 1  // malformed date → treat as new day
        : Math.floor((d1 - d2) / 86400000);

      if (diffDays === 0) {
        // Same day — no change
      } else if (diffDays === 1) {
        profile.streak += 1;
      } else {
        profile.streak = 1; // reset streak
      }
    }

    profile.lastWorkoutDate = today;
    if (profile.streak > (profile.stats.longestStreak || 0)) {
      profile.stats.longestStreak = profile.streak;
    }

    StorageEngine.saveProfile(profile);
    return profile.streak;
  }

  /* ----------------------------------------------------------
     CYCLE MANAGEMENT — 4-week cycle
  ---------------------------------------------------------- */
  function advanceCycleWeek(profileId) {
    const profile = StorageEngine.getProfile(profileId);
    if (!profile) return;

    const cycle = profile.cycle;
    if (cycle.currentWeek >= cycle.totalWeeks) {
      // Complete cycle — save to history and reset
      cycle.cycleHistory.push({
        completedAt: new Date().toISOString(),
        weeks: cycle.totalWeeks,
        goalConfig: { ...profile.goalConfig },
      });
      cycle.currentWeek = 1;
      cycle.startDate   = new Date().toISOString().split('T')[0];
    } else {
      cycle.currentWeek += 1;
    }

    StorageEngine.saveProfile(profile);
    return cycle.currentWeek;
  }

  function getCycleInfo(profileId) {
    const profile = StorageEngine.getProfile(profileId || StorageEngine.getActiveProfileId());
    if (!profile) return { currentWeek: 1, totalWeeks: 4, isDeloadWeek: false };

    const { currentWeek, totalWeeks } = profile.cycle;
    return {
      currentWeek,
      totalWeeks,
      isDeloadWeek: currentWeek === totalWeeks,
      progressPct:  Math.round((currentWeek / totalWeeks) * 100),
      label: currentWeek === totalWeeks ? '💤 Deload Week'
           : currentWeek === 3         ? '🔥 Peak Week'
           : currentWeek === 2         ? '⚡ Build Week'
           :                             '🔧 Foundation Week',
    };
  }

  /* ----------------------------------------------------------
     HELPERS
  ---------------------------------------------------------- */
  function _generateId() {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      return crypto.randomUUID();
    }
    return 'p_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function _deepMerge(target, source) {
    const result = { ...target };
    for (const key of Object.keys(source)) {
      if (
        source[key] !== null &&
        typeof source[key] === 'object' &&
        !Array.isArray(source[key]) &&
        typeof result[key] === 'object' &&
        result[key] !== null
      ) {
        result[key] = _deepMerge(result[key], source[key]);
      } else {
        result[key] = source[key];
      }
    }
    return result;
  }

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    createProfile,
    setActive,
    getActive,
    getActiveId,
    getAllProfiles,
    hasAnyProfile,
    hasActiveProfile,
    updateProfile,
    deleteProfile,
    saveStateToProfile,
    updateStreak,
    advanceCycleWeek,
    getCycleInfo,
    // Re-export storage helpers
    exportAll:     () => StorageEngine.exportAll(),
    exportProfile: (id) => StorageEngine.exportProfile(id),
    importData:    (json, mode) => StorageEngine.importData(json, mode),
    getStorageInfo: () => StorageEngine.getStorageInfo(),
  };

})();

if (typeof module !== 'undefined') module.exports = ProfileManager;
