/* ================================================================
   STORAGE ENGINE — profile/storageEngine.js
   Operator Military RPG v2

   Multi-Profile Local Storage Layer
   - เก็บหลายโปรไฟล์ใน localStorage key เดียว
   - IndexedDB สำหรับ workout history ของแต่ละโปรไฟล์
   - Export / Import JSON รองรับ backup ข้ามเครื่อง
   ================================================================ */
'use strict';

const StorageEngine = (() => {

  const PROFILES_KEY   = 'operator_profiles_v1';
  const ACTIVE_ID_KEY  = 'operator_active_profile';
  const VERSION        = 1;

  /* ----------------------------------------------------------
     PROFILES CRUD
  ---------------------------------------------------------- */
  function loadAllProfiles() {
    try {
      const raw = localStorage.getItem(PROFILES_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch { return {}; }
  }

  function saveAllProfiles(profiles) {
    try {
      localStorage.setItem(PROFILES_KEY, JSON.stringify(profiles));
      return true;
    } catch (e) {
      if (typeof Logger !== 'undefined') Logger.saveFail('StorageEngine', e);
      else console.warn('[StorageEngine] Save profiles failed:', e);
      return false;
    }
  }

  function getProfile(id) {
    const all = loadAllProfiles();
    return all[id] || null;
  }

  function saveProfile(profile) {
    const all = loadAllProfiles();
    all[profile.id] = { ...profile, updatedAt: Date.now() };
    return saveAllProfiles(all);
  }

  function deleteProfile(id) {
    const all = loadAllProfiles();
    if (!all[id]) return false;
    delete all[id];
    saveAllProfiles(all);
    // Clear active if deleted
    if (getActiveProfileId() === id) clearActiveProfile();
    // Clear IDB workouts for this profile
    _clearProfileIDB(id);
    return true;
  }

  /* ----------------------------------------------------------
     ACTIVE PROFILE
  ---------------------------------------------------------- */
  function getActiveProfileId() {
    return localStorage.getItem(ACTIVE_ID_KEY) || null;
  }

  function setActiveProfileId(id) {
    localStorage.setItem(ACTIVE_ID_KEY, id);
  }

  function clearActiveProfile() {
    localStorage.removeItem(ACTIVE_ID_KEY);
  }

  /* ----------------------------------------------------------
     WORKOUT HISTORY — per-profile key in localStorage
     (IDB handled by TrainingDB, here is the lightweight layer)
  ---------------------------------------------------------- */
  function getWorkoutKey(profileId) {
    return `operator_workouts_${profileId}`;
  }

  function loadWorkouts(profileId) {
    try {
      return JSON.parse(localStorage.getItem(getWorkoutKey(profileId)) || '[]');
    } catch { return []; }
  }

  function saveWorkouts(profileId, workouts) {
    try {
      // Keep last 200 sessions per profile
      const trimmed = workouts.slice(-200);
      localStorage.setItem(getWorkoutKey(profileId), JSON.stringify(trimmed));
      return true;
    } catch { return false; }
  }

  function appendWorkout(profileId, session) {
    const workouts = loadWorkouts(profileId);
    workouts.push({ ...session, ts: Date.now() });
    return saveWorkouts(profileId, workouts);
  }

  function _clearProfileIDB(profileId) {
    try { localStorage.removeItem(getWorkoutKey(profileId)); } catch {}
  }

  /* ----------------------------------------------------------
     EXPORT — สร้าง JSON backup รวมทุกโปรไฟล์หรือโปรไฟล์เดียว
  ---------------------------------------------------------- */
  function exportAll() {
    const profiles = loadAllProfiles();
    const workouts = {};
    Object.keys(profiles).forEach(id => {
      workouts[id] = loadWorkouts(id);
    });

    const payload = {
      version: VERSION,
      exportedAt: new Date().toISOString(),
      profiles,
      workouts,
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `operator_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    return true;
  }

  function exportProfile(profileId) {
    const profile  = getProfile(profileId);
    if (!profile) return false;
    const workouts = loadWorkouts(profileId);

    const payload = {
      version: VERSION,
      exportedAt: new Date().toISOString(),
      profiles: { [profileId]: profile },
      workouts: { [profileId]: workouts },
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `operator_${profile.name}_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    return true;
  }

  /* ----------------------------------------------------------
     IMPORT — merge หรือ overwrite
  ---------------------------------------------------------- */
  function importData(jsonString, mode = 'merge') {
    try {
      const payload = JSON.parse(jsonString);
      if (!payload.profiles) return { success: false, error: 'Invalid format' };

      const existing = loadAllProfiles();
      const imported = payload.profiles;
      let count = 0;

      Object.entries(imported).forEach(([id, profile]) => {
        if (mode === 'merge' && existing[id]) {
          // merge: เอาข้อมูลใหม่ถ้า updatedAt มากกว่า
          if ((profile.updatedAt || 0) > (existing[id].updatedAt || 0)) {
            existing[id] = profile;
            count++;
          }
        } else {
          existing[id] = profile;
          count++;
        }

        // Import workouts
        if (payload.workouts?.[id]) {
          saveWorkouts(id, payload.workouts[id]);
        }
      });

      saveAllProfiles(existing);
      return { success: true, imported: count };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  /* ----------------------------------------------------------
     STORAGE USAGE — แสดง % ที่ใช้ไป
  ---------------------------------------------------------- */
  function getStorageInfo() {
    let total = 0;
    try {
      for (const key of Object.keys(localStorage)) {
        total += (localStorage.getItem(key) || '').length * 2; // bytes (UTF-16)
      }
    } catch {}
    const usedKB  = Math.round(total / 1024);
    const limitKB = 5120; // ~5MB typical
    return { usedKB, limitKB, percent: Math.round((usedKB / limitKB) * 100) };
  }

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    loadAllProfiles,
    saveAllProfiles,
    getProfile,
    saveProfile,
    deleteProfile,
    getActiveProfileId,
    setActiveProfileId,
    clearActiveProfile,
    loadWorkouts,
    saveWorkouts,
    appendWorkout,
    exportAll,
    exportProfile,
    importData,
    getStorageInfo,
  };

})();

if (typeof module !== 'undefined') module.exports = StorageEngine;
