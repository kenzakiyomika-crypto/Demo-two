# 🪖 Operator Training System

**Military Fitness RPG — แอปออกกำลังกายที่แปลงการฝึกจริงเป็น RPG Stats**

[![PWA Ready](https://img.shields.io/badge/PWA-Ready-brightgreen)](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps)
[![Offline First](https://img.shields.io/badge/Offline-First-blue)](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps)
[![No Build Required](https://img.shields.io/badge/Build-None%20Required-orange)](.)

---

## 🎯 คืออะไร

Operator Training System เป็น Progressive Web App (PWA) ที่แปลงการออกกำลังกายจริงให้กลายเป็น RPG Stats — ไม่มี build step, ไม่มี framework, เปิด `index.html` แล้วใช้ได้เลย

**Workout ใน real life → STR / END / SPD / POW / DISC / PRC / STA ใน game**

---

## ⚔️ Features

- **7 Attributes** — STR, END, SPD, POW, DISC, PRC, STA คำนวณจาก workout จริง
- **Combat Power (CP)** — `STR×2 + END×1.5 + POW×1.5 + SPD×1 + DISC×3 + PRC×0.5 + STA×0.5`
- **12 Ranks** — พลเรือน → พันเอกพิเศษ (Thai Military theme)
- **SF Badge System** — Infantry / Ranger / Airborne / Heavy / Recon / Special Ops / Tier 1
- **Fatigue Engine** — 5-level fatigue พร้อม Deload Advisory
- **4-Week Periodization** — W1 Foundation → W2 Build → W3 Peak → W4 Deload
- **AI Coach** — รองรับ OpenAI + Gemini + Local AI fallback
- **Multi-Profile** — หลาย user บน device เดียวกัน
- **Progression Engine** — ตรวจ Plateau + แนะนำ Variation
- **Offline First** — ทำงานได้แม้ไม่มีอินเทอร์เน็ต (Service Worker)

---

## 🚀 วิธีใช้งาน

### Option 1: เปิดตรง (ง่ายสุด)
```
เปิดไฟล์ index.html ใน browser
```

### Option 2: GitHub Pages (แนะนำ)
1. Fork / clone repo นี้
2. ไปที่ `Settings → Pages → Deploy from branch → main`
3. เข้าใช้งานที่ `https://username.github.io/operator-training/`

### Option 3: Local Server
```bash
# Python
python3 -m http.server 8080

# Node.js
npx serve .

# VS Code: Live Server extension
```

> **หมายเหตุ:** Service Worker และ PWA install ต้องการ HTTPS หรือ localhost — ไม่ทำงานบน `file://`

---

## 📁 โครงสร้างโปรเจกต์

```
operator-training/
├── index.html              # Entry point — โหลดไฟล์ทั้งหมด
├── style.css               # UI styles
├── manifest.json           # PWA manifest
├── service-worker.js       # Offline cache
│
├── core/                   # RPG Engine (ไม่มี UI, pure logic)
│   ├── safeNumber.js       # NaN/Infinity protection
│   ├── attributeEngine.js  # STR/END/SPD/POW/DISC/PRC/STA
│   ├── conversionEngine.js # Workout → Stat deltas
│   ├── rankSystem.js       # 12 Ranks + SF Badges
│   ├── goalEngine.js       # Goal config + training templates
│   ├── fatigueEngine.js    # Fatigue + Deload advisory
│   ├── medalSystem.js      # Achievement medals
│   ├── stateValidator.js   # Schema validation + backup/restore
│   ├── templateEngine.js   # UI template helpers
│   └── errorLogger.js      # Centralized error logging
│
├── app/                    # Application logic
│   ├── engine.js           # ProductionEngine — core state machine
│   ├── app.js              # Main UI controller
│   ├── db.js               # IndexedDB + localStorage layer
│   ├── state_manager.js    # Reactive state
│   ├── progression_engine.js # Plateau detection + overload suggest
│   ├── trend_analyzer.js   # Weekly trend analysis
│   ├── decision_engine.js  # Day planning AI (deterministic)
│   ├── ascension_engine.js # Sports science layer (SFR, e1RM, HRV)
│   ├── elite_engine.js     # ACWR + Autoregulation + Strength Curve
│   ├── conversion_layer.js # Workout → Game outcome (damage, XP, combo)
│   ├── meta_system.js      # Skill tree + passive unlocks
│   ├── game_loop.js        # Main game loop
│   └── rpgController.js    # RPG UI controller
│
├── ai/                     # AI Layer
│   ├── ai_providers.js     # OpenAI + Gemini API callers
│   ├── ai_utils.js         # Rate limiting, caching, error handling
│   ├── ai_prompt_templates.js # Prompt builder + injection sanitizer
│   ├── ai_hybrid_engine.js # Cloud → Local fallback chain
│   ├── ai_local_engine.js  # Local AI (no API key needed)
│   └── coach_engine.js     # Hypertrophy + CFI + Biometric layer
│
├── profile/                # Multi-profile system
│   ├── storageEngine.js    # Per-profile storage
│   └── profileManager.js   # Create/switch/sync profiles
│
├── data/
│   └── exerciseDB.js       # Exercise database
│
└── assets/
    ├── icon-192.png
    └── icon-512.png
```

---

## 🔑 AI Setup (Optional)

แอปทำงานได้เต็มที่แม้ **ไม่มี API key** — AI เป็น optional enhancement

หากต้องการ AI Coach:
1. เปิด Settings ในแอป
2. เลือก Provider: **OpenAI** หรือ **Gemini**
3. ใส่ API Key

> ⚠️ API Key เก็บอยู่ใน localStorage ของ browser เท่านั้น — **ไม่ถูกส่งไปที่ server ใด** นอกจาก OpenAI/Gemini โดยตรง

---

## 🛡️ Anti-Cheat System

- **Weight validation** — ไม่รับค่าเกินขีดจำกัดสมเหตุสมผล (Deadlift > 500kg = penalty)
- **Pace validation** — วิ่งเร็วกว่า world record ไม่ได้
- **Prompt injection protection** — sanitize user input ก่อนส่ง AI

---

## 📱 PWA Install

เปิดเว็บผ่าน HTTPS แล้วกด "Install App" ใน browser เพื่อใช้งานแบบ standalone บน mobile และ desktop

---

## 🤝 Contributing

Pull requests ยินดีต้อนรับ โดยเฉพาะ:
- เพิ่ม exercise ใน `data/exerciseDB.js`
- เพิ่ม rank / SF tier ใน `core/rankSystem.js`  
- UI improvements ใน `style.css` / `index.html`

---

## 📄 License

MIT License — ใช้ได้ฟรี ดัดแปลงได้ แต่ให้ credit ด้วย
