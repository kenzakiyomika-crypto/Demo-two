/* ================================================================
   STATE VALIDATOR — core/stateValidator.js
   Operator Military RPG v2

   ─── แก้ปัญหา Critical 1.1 ───────────────────────────────────
   - Schema validation ก่อน load state ทุกครั้ง
   - Versioned save structure
   - Auto-backup ก่อน overwrite (key _backup)
   - Migration pipeline
   - Corruption detection + recovery

   ใช้งาน:
     StateValidator.load(key, schema)   → { data, corrupted, repaired }
     StateValidator.save(key, data)     → true/false (with auto-backup)
     StateValidator.validate(data, schema) → { valid, errors }
   ================================================================ */
'use strict';

const StateValidator = (() => {

  const CURRENT_SCHEMA_VERSION = 2;
  const BACKUP_SUFFIX          = '_backup_v2';
  const MAX_BACKUP_AGE_MS      = 7 * 24 * 60 * 60 * 1000; // 7 วัน

  /* ----------------------------------------------------------
     SCHEMAS — defines required structure of each state type
  ---------------------------------------------------------- */
  const SCHEMAS = {

    engineState: {
      required: ['xp','level','totalVolume','fatigue','readiness','streak',
                 'workoutsCompleted','lastWorkoutDate','lastUpdate'],
      types: {
        xp:                'number',
        level:             'number',
        totalVolume:       'number',
        readiness:         'number',
        streak:            'number',
        workoutsCompleted: 'number',
        fatigue:           'object',
        weeklyVolume:      'object',
      },
      defaults: {
        xp: 0, level: 1, totalVolume: 0, readiness: 100,
        streak: 0, workoutsCompleted: 0,
        lastWorkoutDate: null, lastUpdate: 0,
        fatigue: { chest:0, back:0, legs:0, shoulders:0, arms:0, core:0 },
        weeklyVolume: { chest:0, back:0, legs:0, shoulders:0, arms:0, core:0 },
        weekNumber: 1, phaseIndex: 0, exerciseHistory: {},
      },
    },

    profile: {
      required: ['id','name','createdAt','attributes','rank'],
      types: {
        id:         'string',
        name:       'string',
        createdAt:  'number',
        attributes: 'object',
        rank:       'object',
      },
      defaults: {
        bodyProfile: { age:25, weight:70, height:175, fitnessLevel:'beginner' },
        goalConfig:  { primaryGoal:'hybrid', daysPerWeek:4, bodyFocus:{}, baseline:{} },
        attributes:  { STR:{pts:0,level:1}, END:{pts:0,level:1}, SPD:{pts:0,level:1},
                       POW:{pts:0,level:1}, DISC:{pts:0,level:1}, PRC:{pts:0,level:1}, STA:{pts:0,level:1} },
        rank:        { currentRankId:0, unlockedMissions:[], sfAchieved:[], physicalTests:{}, rankHistory:[] },
        medals:      [],
        streak:      0,
        fatigueScore:0,
        stats:       { totalSessions:0, totalVolume:0, totalReps:0, longestStreak:0 },
      },
    },

    rankData: {
      required: ['currentRankId'],
      types: {
        currentRankId:   'number',
        unlockedMissions:'object',
        sfAchieved:      'object',
        physicalTests:   'object',
      },
      defaults: {
        currentRankId:0, unlockedMissions:[], sfAchieved:[],
        physicalTests:{}, history:[], totalSessions:0, totalStreak:0,
      },
    },

    attributes: {
      required: [],
      types:    {},
      defaults: {
        STR:{pts:0,level:1}, END:{pts:0,level:1}, SPD:{pts:0,level:1},
        POW:{pts:0,level:1}, DISC:{pts:0,level:1}, PRC:{pts:0,level:1}, STA:{pts:0,level:1},
      },
    },

  };

  /* ----------------------------------------------------------
     VALIDATE — check data against schema
  ---------------------------------------------------------- */
  function validate(data, schemaName) {
    const schema = SCHEMAS[schemaName];
    if (!schema) return { valid: true, errors: [] }; // unknown schema → pass through

    const errors = [];

    if (!data || typeof data !== 'object') {
      return { valid: false, errors: ['data is null/not-object'] };
    }

    // Check required fields
    schema.required.forEach(field => {
      if (data[field] === undefined || data[field] === null) {
        errors.push(`missing required field: ${field}`);
      }
    });

    // Check types
    Object.entries(schema.types || {}).forEach(([field, expectedType]) => {
      if (data[field] !== undefined && data[field] !== null) {
        const actualType = Array.isArray(data[field]) ? 'object' : typeof data[field];
        if (actualType !== expectedType) {
          errors.push(`type mismatch: ${field} expected ${expectedType}, got ${actualType}`);
        }
      }
    });

    // Check for NaN / Infinity in numeric fields
    Object.entries(data).forEach(([key, val]) => {
      if (typeof val === 'number' && (!isFinite(val) || isNaN(val))) {
        errors.push(`invalid number: ${key} = ${val}`);
      }
    });

    return { valid: errors.length === 0, errors };
  }

  /* ----------------------------------------------------------
     REPAIR — fill missing fields with schema defaults
  ---------------------------------------------------------- */
  function repair(data, schemaName) {
    const schema = SCHEMAS[schemaName];
    if (!schema || !schema.defaults) return data;

    const result   = {};
    const defaults = schema.defaults;

    // Start with defaults, overlay actual data
    Object.keys(defaults).forEach(k => {
      if (data[k] === undefined || data[k] === null) {
        result[k] = typeof defaults[k] === 'object'
          ? JSON.parse(JSON.stringify(defaults[k]))
          : defaults[k];
      } else {
        result[k] = data[k];
      }
    });

    // Copy any extra fields not in schema
    Object.keys(data).forEach(k => {
      if (result[k] === undefined) result[k] = data[k];
    });

    // Apply SafeNumber repairs if available
    if (typeof SafeNumber !== 'undefined' && schemaName === 'engineState') {
      const { state } = SafeNumber.sanitizeEngineState(result);
      if (state) return state;
    }

    return result;
  }

  /* ----------------------------------------------------------
     VERSIONED WRAPPER — adds _v / _savedAt metadata
  ---------------------------------------------------------- */
  function _wrap(data) {
    return {
      _v:       CURRENT_SCHEMA_VERSION,
      _savedAt: Date.now(),
      data,
    };
  }

  function _unwrap(raw) {
    if (!raw) return null;
    // New format: { _v, _savedAt, data }
    if (raw._v !== undefined && raw.data !== undefined) return raw.data;
    // Legacy format: the data itself (no wrapper)
    return raw;
  }

  /* ----------------------------------------------------------
     LOAD — with validation, backup restore, and repair
  ---------------------------------------------------------- */
  function load(storageKey, schemaName = null) {
    let raw = null;
    let corrupted = false;
    let repaired  = [];

    try {
      const str = localStorage.getItem(storageKey);
      if (!str) return { data: null, corrupted: false, repaired: [] };
      raw = JSON.parse(str);
    } catch (e) {
      corrupted = true;
      _log('warn', `[StateValidator] JSON parse failed for ${storageKey}:`, e.message);

      // Attempt backup restore
      const backup = _loadBackup(storageKey);
      if (backup) {
        _log('warn', `[StateValidator] Restored from backup: ${storageKey}`);
        raw = backup;
        repaired.push('restored_from_backup');
      } else {
        return { data: null, corrupted: true, repaired: ['parse_failed_no_backup'] };
      }
    }

    const data = _unwrap(raw);
    if (!data) return { data: null, corrupted: false, repaired: [] };

    // Schema validation
    if (schemaName) {
      const { valid, errors } = validate(data, schemaName);
      if (!valid) {
        _log('warn', `[StateValidator] Schema issues in ${storageKey}:`, errors);
        const fixed = repair(data, schemaName);
        repaired = [...repaired, ...errors];
        return { data: fixed, corrupted: !valid, repaired };
      }
    }

    return { data, corrupted: false, repaired };
  }

  /* ----------------------------------------------------------
     SAVE — with auto-backup before overwrite
  ---------------------------------------------------------- */
  function save(storageKey, data, options = {}) {
    const { skipBackup = false, schemaName = null } = options;

    // Validate before save if schema provided
    if (schemaName) {
      const { valid, errors } = validate(data, schemaName);
      if (!valid && errors.length > 2) {
        // Refuse to save deeply invalid state
        _log('error', `[StateValidator] Refusing to save invalid state for ${storageKey}:`, errors);
        return false;
      }
    }

    // Auto-backup existing data before overwrite
    if (!skipBackup) {
      _saveBackup(storageKey);
    }

    try {
      const wrapped = _wrap(data);
      localStorage.setItem(storageKey, JSON.stringify(wrapped));
      return true;
    } catch (e) {
      _log('error', `[StateValidator] Save failed for ${storageKey}:`, e.message);
      return false;
    }
  }

  /* ----------------------------------------------------------
     BACKUP HELPERS
  ---------------------------------------------------------- */
  function _saveBackup(storageKey) {
    try {
      const existing = localStorage.getItem(storageKey);
      if (!existing) return;
      const backupKey = storageKey + BACKUP_SUFFIX;
      // Only backup if there's no recent backup (avoid thrashing)
      const existingBackup = localStorage.getItem(backupKey);
      if (existingBackup) {
        try {
          const parsed = JSON.parse(existingBackup);
          const backupAge = Date.now() - (parsed._savedAt || 0);
          if (backupAge < 5 * 60 * 1000) return; // backup is < 5 min old
        } catch {}
      }
      localStorage.setItem(backupKey, existing);
    } catch {}
  }

  function _loadBackup(storageKey) {
    try {
      const backupKey = storageKey + BACKUP_SUFFIX;
      const str = localStorage.getItem(backupKey);
      if (!str) return null;
      const parsed = JSON.parse(str);
      // Check backup isn't too old
      const age = Date.now() - (parsed._savedAt || 0);
      if (age > MAX_BACKUP_AGE_MS) return null;
      return _unwrap(parsed) || parsed;
    } catch { return null; }
  }

  function hasBackup(storageKey) {
    return !!localStorage.getItem(storageKey + BACKUP_SUFFIX);
  }

  /* ----------------------------------------------------------
     CLEAN OLD BACKUPS — call periodically
  ---------------------------------------------------------- */
  function cleanOldBackups() {
    try {
      const keys = Object.keys(localStorage).filter(k => k.endsWith(BACKUP_SUFFIX));
      let cleaned = 0;
      keys.forEach(k => {
        try {
          const parsed = JSON.parse(localStorage.getItem(k));
          const age = Date.now() - (parsed._savedAt || 0);
          if (age > MAX_BACKUP_AGE_MS) {
            localStorage.removeItem(k);
            cleaned++;
          }
        } catch {
          localStorage.removeItem(k);
          cleaned++;
        }
      });
      if (cleaned > 0) _log('info', `[StateValidator] Cleaned ${cleaned} old backups`);
    } catch {}
  }

  /* ----------------------------------------------------------
     DEV LOGGER — silent in prod, verbose in dev
  ---------------------------------------------------------- */
  function _isDevMode() {
    return typeof window !== 'undefined' &&
      (window.location?.hostname === 'localhost' ||
       window.location?.hostname === '127.0.0.1' ||
       window.__OPERATOR_DEV__ === true);
  }

  function _log(level, ...args) {
    if (!_isDevMode() && level !== 'error') return;
    if (level === 'error')  console.error(...args);
    else if (level === 'warn')  console.warn(...args);
    else                        console.log(...args);
  }

  /* ----------------------------------------------------------
     EXERCISE DB VALIDATION — Item 4.1
  ---------------------------------------------------------- */
  function validateExerciseDB(db) {
    if (!db || typeof db !== 'object') return { valid: false, errors: ['db not object'] };
    const errors  = [];
    const seenIds = new Set();

    Object.entries(db).forEach(([category, exercises]) => {
      if (!Array.isArray(exercises)) {
        errors.push(`${category}: not an array`);
        return;
      }
      exercises.forEach((ex, i) => {
        if (!ex.id)   errors.push(`${category}[${i}]: missing id`);
        if (!ex.name) errors.push(`${category}[${i}]: missing name`);
        if (ex.id && seenIds.has(ex.id)) errors.push(`duplicate id: ${ex.id}`);
        if (ex.id) seenIds.add(ex.id);
      });
    });

    return { valid: errors.length === 0, errors };
  }

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    SCHEMAS,
    validate,
    repair,
    load,
    save,
    hasBackup,
    cleanOldBackups,
    validateExerciseDB,
  };

})();

if (typeof module !== 'undefined') module.exports = StateValidator;
