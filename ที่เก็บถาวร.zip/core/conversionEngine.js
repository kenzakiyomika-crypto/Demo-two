/* ================================================================
   CONVERSION ENGINE — conversionEngine.js
   Operator Military RPG — Physical → RPG Stat Layer

   Two-layer architecture (ห้ามผสม):
   ชั้น 1: Raw Physical Data (reps, weight, time, distance)
   ชั้น 2: Derived RPG Stats (STR, END, SPD, POW, DISC, PRC, STA)

   Formula design: Manual Input + Validation Logic (Anti-cheat)
   ================================================================ */
'use strict';

const ConversionEngine = (() => {

  /* ----------------------------------------------------------
     STAT DEFINITIONS
  ---------------------------------------------------------- */
  const STAT_KEYS = ['STR', 'END', 'SPD', 'POW', 'DISC', 'PRC', 'STA'];

  const STAT_META = {
    STR:  { label: 'Strength',   icon: '💪', color: '#ef4444', desc: 'กำลังและการยกน้ำหนัก' },
    END:  { label: 'Endurance',  icon: '🫁', color: '#3b82f6', desc: 'ความทนทานระยะยาว' },
    SPD:  { label: 'Speed',      icon: '🏃', color: '#f59e0b', desc: 'ความเร็วและ Agility' },
    POW:  { label: 'Power',      icon: '⚡', color: '#a855f7', desc: 'Explosive movement' },
    DISC: { label: 'Discipline', icon: '🧠', color: '#10b981', desc: 'ความสม่ำเสมอและวินัย' },
    PRC:  { label: 'Precision',  icon: '🎯', color: '#06b6d4', desc: 'ฟอร์มและเทคนิค' },
    STA:  { label: 'Stamina',    icon: '💨', color: '#f97316', desc: 'ความเร็วในการฟื้นตัว' },
  };

  /* ----------------------------------------------------------
     EXERCISE CATEGORY MAP
     maps exercise names → stat categories
  ---------------------------------------------------------- */
  const EXERCISE_MAP = {
    // Strength / Power
    'deadlift':      { STR: 0.015, POW: 0.008 },
    'squat':         { STR: 0.012, POW: 0.007 },
    'bench press':   { STR: 0.012, POW: 0.006 },
    'overhead press':{ STR: 0.010, POW: 0.005 },
    'barbell row':   { STR: 0.010, POW: 0.005 },
    'hip thrust':    { STR: 0.010, POW: 0.005 },

    // Bodyweight Strength
    'pull-up':       { STR: 0.18,  END: 0.08 },
    'push-up':       { STR: 0.10,  END: 0.10 },
    'dip':           { STR: 0.12,  POW: 0.05 },
    'chin-up':       { STR: 0.18,  END: 0.07 },
    'muscle-up':     { STR: 0.25,  POW: 0.15 },
    'handstand':     { STR: 0.20,  PRC: 0.15 },

    // Toughness / Isometric
    'plank':         { STA: 0.25,  PRC: 0.15 },
    'hollow hold':   { STA: 0.20,  PRC: 0.12 },
    'wall sit':      { STA: 0.20,  END: 0.10 },
    'farmer carry':  { STR: 0.08,  STA: 0.10 },

    // Speed / Power
    'sprint':        { SPD: 0.30,  POW: 0.15 },
    'burpee':        { SPD: 0.12,  END: 0.12, POW: 0.08 },
    'box jump':      { POW: 0.20,  SPD: 0.10 },
    'jump rope':     { SPD: 0.15,  END: 0.12 },
    'mountain climber':{ SPD: 0.10, END: 0.10 },

    // Endurance / Cardio
    'run':           { END: 0.18,  SPD: 0.08 },
    'running':       { END: 0.18,  SPD: 0.08 },
    'cycling':       { END: 0.15,  SPD: 0.05 },
    'rowing':        { END: 0.14,  STR: 0.06 },
    'swimming':      { END: 0.16,  STR: 0.05 },
    'walk':          { END: 0.05,  STA: 0.05 },
  };

  // Default fallback mapping by workout type
  const TYPE_FALLBACK = {
    strength:     { STR: 0.010, POW: 0.005 },
    bodyweight:   { STR: 0.08,  END: 0.08 },
    cardio:       { END: 0.15,  SPD: 0.05 },
    hiit:         { SPD: 0.12,  END: 0.10, POW: 0.08 },
    flexibility:  { STA: 0.12,  PRC: 0.10 },
    fullbody:     { STR: 0.06,  END: 0.06, SPD: 0.04 },
  };

  /* ----------------------------------------------------------
     VALIDATION — Anti-cheat (ตรวจความสมเหตุสมผล)
  ---------------------------------------------------------- */
  const LIMITS = {
    maxWeight: 500,        // กก. ไม่มีใคร deadlift 500+ ใน 1 session (natural)
    maxReps: 1000,         // reps ต่อ exercise
    maxSets: 20,
    maxDurationMin: 240,   // 4 ชั่วโมง max
    maxDistanceKm: 100,    // ultra-marathon ก็แค่ 100km
    maxSprintKm: 10,       // sprint ไม่ควรเกิน 10km
    minSpeedPace: 2.5,     // min/km — เร็วกว่า world record ไม่ได้
  };

  function validateExercise(ex) {
    const issues = [];
    if (ex.weight > LIMITS.maxWeight) issues.push('weight_unrealistic');
    if (ex.reps   > LIMITS.maxReps)   issues.push('reps_unrealistic');
    if (ex.sets   > LIMITS.maxSets)   issues.push('sets_unrealistic');
    if (ex.distance > LIMITS.maxDistanceKm) issues.push('distance_unrealistic');
    if (ex.duration > LIMITS.maxDurationMin) issues.push('duration_unrealistic');

    // Pace check for running
    if (ex.distance > 0 && ex.duration > 0) {
      const pacePerKm = ex.duration / ex.distance;
      if (pacePerKm < LIMITS.minSpeedPace) issues.push('pace_superhuman');
    }

    return { valid: issues.length === 0, issues };
  }

  /* ----------------------------------------------------------
     CORE CONVERSION — exercise → stat deltas
  ---------------------------------------------------------- */
  function exerciseToStats(ex, workoutType = 'fullbody') {
    // Fix 5.2: sanitize all inputs from undefined/NaN
    const safeEx = {
      name:     String(ex?.name || ''),
      sets:     Math.max(0, Math.min(30,    isFinite(+ex?.sets)     ? +ex.sets     : 1)),
      reps:     Math.max(0, Math.min(1000,  isFinite(+ex?.reps)     ? +ex.reps     : 1)),
      weight:   Math.max(0, Math.min(1000,  isFinite(+ex?.weight)   ? +ex.weight   : 0)),
      duration: Math.max(0, Math.min(600,   isFinite(+ex?.duration) ? +ex.duration : 0)),
      distance: Math.max(0, Math.min(500,   isFinite(+ex?.distance) ? +ex.distance : 0)),
    };

    const { valid, issues } = validateExercise(safeEx);
    const penalty = valid ? 1.0 : 0.5;

    const name = safeEx.name.toLowerCase().trim();
    let mapping = null;

    for (const [key, m] of Object.entries(EXERCISE_MAP)) {
      if (name.includes(key)) { mapping = m; break; }
    }
    if (!mapping) mapping = TYPE_FALLBACK[workoutType] || TYPE_FALLBACK.fullbody;

    const deltas = {};
    STAT_KEYS.forEach(k => { deltas[k] = 0; });

    const volume    = safeEx.sets * safeEx.reps * Math.max(safeEx.weight, 1);
    const bodyVol   = safeEx.sets * safeEx.reps;
    const cardioMin = safeEx.duration;
    const distKm    = safeEx.distance;

    for (const [stat, factor] of Object.entries(mapping)) {
      let raw = 0;
      if (safeEx.weight > 0) {
        raw = volume * factor * penalty;
      } else if (distKm > 0 || cardioMin > 0) {
        const unit = distKm > 0 ? distKm * 10 : cardioMin;
        raw = unit * factor * penalty;
      } else {
        raw = bodyVol * factor * penalty;
      }
      // Fix 5.2: clamp final delta — NaN check
      deltas[stat] = isFinite(raw) && !isNaN(raw) ? Math.min(raw, 9999) : 0;
    }

    return { deltas, valid, issues, penalty };
  }

  /* ----------------------------------------------------------
     SESSION CONVERSION — full session → stat gains
  ---------------------------------------------------------- */
  function sessionToStats(exercises = [], workoutType = 'fullbody', formScore = null) {
    const totalDeltas = {};
    STAT_KEYS.forEach(k => { totalDeltas[k] = 0; });

    if (!Array.isArray(exercises)) exercises = [];

    const report = [];
    let flagged = 0;

    exercises.forEach(ex => {
      if (!ex || typeof ex !== 'object') return;
      const { deltas, valid, issues } = exerciseToStats(ex, workoutType);
      if (!valid) flagged++;
      STAT_KEYS.forEach(k => {
        const d = deltas[k];
        totalDeltas[k] += (isFinite(d) && !isNaN(d)) ? d : 0;
      });
      report.push({ exercise: ex.name, deltas, valid, issues });
    });

    // Precision bonus
    if (formScore !== null && formScore >= 0 && formScore <= 10) {
      totalDeltas.PRC += formScore * 2;
    }

    // Round + clamp all deltas
    STAT_KEYS.forEach(k => {
      const v = totalDeltas[k];
      totalDeltas[k] = isFinite(v) && !isNaN(v)
        ? Math.min(Math.round(v * 10) / 10, 9999)
        : 0;
    });

    return { deltas: totalDeltas, report, flagged };
  }

  /* ----------------------------------------------------------
     STREAK → DISCIPLINE
  ---------------------------------------------------------- */
  function streakToDisc(streakDays) {
    // Non-linear: early streaks easy, long streaks hard to maintain
    // 7 days = 50 pts, 30 days = 300 pts, 100 days = 1500 pts
    if (streakDays <= 0) return 0;
    return Math.round(Math.pow(streakDays, 1.4) * 3);
  }

  /* ----------------------------------------------------------
     RECOVERY → STAMINA (from existing engine state)
  ---------------------------------------------------------- */
  function recoveryToSta(readiness, fatigue) {
    // High readiness + low fatigue = good stamina
    const recoveryScore = (readiness / 100) * 50 - (fatigue / 100) * 10;
    return Math.max(0, Math.round(recoveryScore));
  }

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    STAT_KEYS,
    STAT_META,
    validateExercise,
    exerciseToStats,
    sessionToStats,
    streakToDisc,
    recoveryToSta,
  };

})();

if (typeof module !== 'undefined') module.exports = ConversionEngine;
