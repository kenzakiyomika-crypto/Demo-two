/* ================================================================
   MEDAL SYSTEM — medalSystem.js
   Operator Military RPG — Achievements + Badges

   3 Categories:
   1. Medal of Strength  — strength-based milestones
   2. Medal of Endurance — cardio + consistency
   3. Special Forces     — SF benchmark qualifications

   Also: Career badges (session count, volume milestones)
   ================================================================ */
'use strict';

const MedalSystem = (() => {

  /* ----------------------------------------------------------
     MEDAL DEFINITIONS
  ---------------------------------------------------------- */
  const MEDALS = [

    // ── Medal of Strength ──────────────────────────────────
    {
      id: 'iron_grip',
      category: 'strength',
      label: 'Iron Grip',
      labelThai: 'กำมือเหล็ก',
      icon: '🏅',
      desc: 'Pull-up สะสม 500 ครั้ง',
      color: '#ef4444',
      check: (c) => (c.totalPullups || 0) >= 500,
    },
    {
      id: 'steel_fist',
      category: 'strength',
      label: 'Steel Fist',
      labelThai: 'กำปั้นเหล็กกล้า',
      icon: '🥊',
      desc: 'Push-up สะสม 2,000 ครั้ง',
      color: '#ef4444',
      check: (c) => (c.totalPushups || 0) >= 2000,
    },
    {
      id: 'bar_king',
      category: 'strength',
      label: 'Bar King',
      labelThai: 'เจ้าบาร์',
      icon: '🏋️',
      desc: 'Pull-up สะสม 2,000 ครั้ง',
      color: '#dc2626',
      check: (c) => (c.totalPullups || 0) >= 2000,
    },
    {
      id: 'beast_mode',
      category: 'strength',
      label: 'Beast Mode',
      labelThai: 'โหมดสัตว์ป่า',
      icon: '🦁',
      desc: 'Volume รวมในวันเดียว ≥ 50,000 กก.',
      color: '#b91c1c',
      check: (c) => (c.maxSingleDayVolume || 0) >= 50000,
    },

    // ── Medal of Endurance ─────────────────────────────────
    {
      id: 'iron_boot',
      category: 'endurance',
      label: 'Iron Boot',
      labelThai: 'รองเท้าเหล็ก',
      icon: '👟',
      desc: 'วิ่งสะสม 100 กม.',
      color: '#3b82f6',
      check: (c) => (c.totalRunKm || 0) >= 100,
    },
    {
      id: 'marathon_heart',
      category: 'endurance',
      label: 'Marathon Heart',
      labelThai: 'หัวใจมาราธอน',
      icon: '🫀',
      desc: 'วิ่งสะสม 500 กม.',
      color: '#2563eb',
      check: (c) => (c.totalRunKm || 0) >= 500,
    },
    {
      id: 'unbreakable',
      category: 'endurance',
      label: 'Unbreakable',
      labelThai: 'ไม่พัง',
      icon: '🔥',
      desc: 'ฝึกติดต่อกัน 30 วัน',
      color: '#f97316',
      check: (c) => (c.maxStreak || 0) >= 30,
    },
    {
      id: 'iron_will',
      category: 'endurance',
      label: 'Iron Will',
      labelThai: 'เจตจำนงเหล็ก',
      icon: '💪',
      desc: 'ฝึกติดต่อกัน 100 วัน',
      color: '#ea580c',
      check: (c) => (c.maxStreak || 0) >= 100,
    },
    {
      id: 'legend_streak',
      category: 'endurance',
      label: 'Legendary',
      labelThai: 'ตำนาน',
      icon: '⚡',
      desc: 'ฝึกติดต่อกัน 365 วัน',
      color: '#f59e0b',
      check: (c) => (c.maxStreak || 0) >= 365,
    },

    // ── Career Badges ──────────────────────────────────────
    {
      id: 'first_blood',
      category: 'career',
      label: 'First Blood',
      labelThai: 'เริ่มต้นภารกิจ',
      icon: '🎖️',
      desc: 'บันทึก session แรก',
      color: '#10b981',
      check: (c) => (c.totalSessions || 0) >= 1,
    },
    {
      id: 'warrior_path',
      category: 'career',
      label: "Warrior's Path",
      labelThai: 'เส้นทางนักรบ',
      icon: '⚔️',
      desc: 'บันทึกครบ 100 sessions',
      color: '#059669',
    check: (c) => (c.totalSessions || 0) >= 100,
    },
    {
      id: 'centurion',
      category: 'career',
      label: 'Centurion',
      labelThai: 'ร้อยผู้กล้า',
      icon: '🛡️',
      desc: 'บันทึกครบ 365 sessions',
      color: '#047857',
      check: (c) => (c.totalSessions || 0) >= 365,
    },
    {
      id: 'operator',
      category: 'career',
      label: 'Operator',
      labelThai: 'ปฏิบัติการ',
      icon: '🔱',
      desc: 'Combat Power ≥ 10,000',
      color: '#a855f7',
      check: (c) => (c.combatPower || 0) >= 10000,
    },

    // ── Special Forces Qualification ─────────────────────
    {
      id: 'sf_infantry',
      category: 'special_forces',
      label: 'Infantry Qualified',
      labelThai: 'ผ่านมาตรฐานทหารราบ',
      icon: '🪖',
      desc: 'ผ่าน Infantry Standard Benchmark',
      color: '#78716c',
      check: (c) => (c.sfAchieved || []).includes('infantry'),
    },
    {
      id: 'sf_ranger',
      category: 'special_forces',
      label: 'Ranger Qualified',
      labelThai: 'ผ่านมาตรฐาน Ranger',
      icon: '⚔️',
      desc: 'ผ่าน Ranger Level Benchmark',
      color: '#4ade80',
      check: (c) => (c.sfAchieved || []).includes('ranger'),
    },
    {
      id: 'sf_airborne',
      category: 'special_forces',
      label: 'Airborne Qualified',
      labelThai: 'ผ่านมาตรฐาน Airborne / นเรศวร',
      icon: '🪂',
      desc: 'ผ่าน Airborne Level Benchmark',
      color: '#60a5fa',
      check: (c) => (c.sfAchieved || []).includes('airborne'),
    },
    {
      id: 'sf_specops',
      category: 'special_forces',
      label: 'Special Ops Qualified',
      labelThai: 'ผ่านมาตรฐานหน่วยรบพิเศษ',
      icon: '🔱',
      desc: 'ผ่าน Special Operations Benchmark',
      color: '#f59e0b',
      check: (c) => (c.sfAchieved || []).includes('special_ops'),
    },
    {
      id: 'sf_tier1',
      category: 'special_forces',
      label: 'Tier 1 Operator',
      labelThai: 'Tier 1 — Delta / SAS Level',
      icon: '💀',
      desc: 'ผ่านมาตรฐาน Tier 1 — ระดับสูงสุด',
      color: '#ef4444',
      check: (c) => (c.sfAchieved || []).includes('tier1'),
    },
  ];

  /* ----------------------------------------------------------
     CAREER DATA STORAGE — multi-profile aware
  ---------------------------------------------------------- */
  function _storageKey() {
    const id = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
             || localStorage.getItem('operator_active_profile');
    return id ? `operator_career_${id}` : 'operator_career_v1';
  }

  function loadCareer() {
    try {
      const raw = localStorage.getItem(_storageKey());
      return raw ? JSON.parse(raw) : {
        totalSessions: 0,
        totalPullups: 0,
        totalPushups: 0,
        totalRunKm: 0,
        maxStreak: 0,
        maxSingleDayVolume: 0,
        combatPower: 0,
        sfAchieved: [],
        earnedMedals: [],
        medalHistory: [],
      };
    } catch {
      return {
        totalSessions: 0, totalPullups: 0, totalPushups: 0,
        totalRunKm: 0, maxStreak: 0, maxSingleDayVolume: 0,
        combatPower: 0, sfAchieved: [], earnedMedals: [], medalHistory: [],
      };
    }
  }

  function saveCareer(data) {
    try { localStorage.setItem(_storageKey(), JSON.stringify(data)); }
    catch (e) { console.warn('[MedalSystem] Save failed:', e); }
  }

  /* ----------------------------------------------------------
     UPDATE CAREER STATS — call after each session
  ---------------------------------------------------------- */
  function updateCareer({ exercises = [], streak = 0, combatPower = 0, sfAchieved = [] }) {
    const career = loadCareer();

    // Aggregate from session exercises
    let sessionPullups = 0, sessionPushups = 0, sessionRunKm = 0, sessionVolume = 0;
    exercises.forEach(ex => {
      const name = (ex.name || '').toLowerCase();
      const reps = (ex.sets || 1) * (ex.reps || 0);
      const vol  = (ex.sets || 1) * (ex.reps || 1) * (ex.weight || 0);

      if (name.includes('pull-up') || name.includes('pullup') || name.includes('chin-up')) sessionPullups += reps;
      if (name.includes('push-up') || name.includes('pushup')) sessionPushups += reps;
      if (name.includes('run') || name.includes('sprint')) sessionRunKm += (ex.distance || 0);
      sessionVolume += vol;
    });

    career.totalSessions = (career.totalSessions || 0) + 1;
    career.totalPullups  = (career.totalPullups  || 0) + sessionPullups;
    career.totalPushups  = (career.totalPushups  || 0) + sessionPushups;
    career.totalRunKm    = (career.totalRunKm    || 0) + sessionRunKm;
    career.maxStreak     = Math.max(career.maxStreak || 0, streak);
    career.maxSingleDayVolume = Math.max(career.maxSingleDayVolume || 0, sessionVolume);
    career.combatPower   = Math.max(career.combatPower || 0, combatPower);
    career.sfAchieved    = [...new Set([...(career.sfAchieved || []), ...sfAchieved])];

    const newMedals = evaluateMedals(career);
    saveCareer(career);

    return { career, newMedals };
  }

  /* ----------------------------------------------------------
     MEDAL EVALUATION
  ---------------------------------------------------------- */
  function evaluateMedals(career) {
    const newlyEarned = [];

    MEDALS.forEach(medal => {
      if (!(career.earnedMedals || []).includes(medal.id) && medal.check(career)) {
        if (!career.earnedMedals) career.earnedMedals = [];
        career.earnedMedals.push(medal.id);
        career.medalHistory.push({ id: medal.id, date: new Date().toISOString() });
        newlyEarned.push(medal);
      }
    });

    return newlyEarned;
  }

  /* ----------------------------------------------------------
     GET DISPLAY DATA
  ---------------------------------------------------------- */
  function getMedalDisplay() {
    const career = loadCareer();
    return MEDALS.map(m => ({
      ...m,
      earned: (career.earnedMedals || []).includes(m.id),
      earnedDate: (career.medalHistory || []).find(h => h.id === m.id)?.date || null,
    }));
  }

  function getCareer() { return loadCareer(); }

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    MEDALS,
    updateCareer,
    getMedalDisplay,
    getCareer,
  };

})();

if (typeof module !== 'undefined') module.exports = MedalSystem;
