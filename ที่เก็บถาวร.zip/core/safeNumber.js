/* ================================================================
   SAFE NUMBER — core/safeNumber.js
   Operator Military RPG v2

   Wrapper ป้องกัน NaN / Infinity / null เข้าระบบ
   ─────────────────────────────────────────────────────────────
   ใช้งาน:
     SafeNumber.num(value)           → clamp to safe finite number
     SafeNumber.clamp(v, min, max)   → bounded value
     SafeNumber.pct(v)               → 0–100 percent
     SafeNumber.stat(v)              → valid stat points (≥ 0)
     SafeNumber.volume(v)            → valid workout volume (≥ 0)
     SafeNumber.fromInput(el, def)   → parse HTML input safely
     SafeNumber.sanitizeState(state) → validate + repair engine state
   ================================================================ */
'use strict';

const SafeNumber = (() => {

  const DEV = typeof console !== 'undefined';

  /* ----------------------------------------------------------
     CORE — num()
     แปลง anything → safe finite number, fallback 0
  ---------------------------------------------------------- */
  function num(value, fallback = 0) {
    if (value === null || value === undefined) return fallback;
    const n = Number(value);
    if (!isFinite(n) || isNaN(n)) {
      if (DEV) console.warn('[SafeNumber] Non-finite value:', value, '→ fallback:', fallback);
      return fallback;
    }
    return n;
  }

  /* ----------------------------------------------------------
     CLAMP
  ---------------------------------------------------------- */
  function clamp(value, min = 0, max = Infinity) {
    return Math.min(Math.max(num(value, min), min), max);
  }

  /* ----------------------------------------------------------
     PERCENT — 0 to 100
  ---------------------------------------------------------- */
  function pct(value) {
    return clamp(value, 0, 100);
  }

  /* ----------------------------------------------------------
     STAT POINTS — ≥ 0, max cap 9999
  ---------------------------------------------------------- */
  function stat(value) {
    return clamp(value, 0, 9999);
  }

  /* ----------------------------------------------------------
     STAT LEVEL — 1 to 100
  ---------------------------------------------------------- */
  function level(value) {
    return clamp(Math.round(num(value, 1)), 1, 100);
  }

  /* ----------------------------------------------------------
     VOLUME — workout volume, ≥ 0, max 10M
  ---------------------------------------------------------- */
  function volume(value) {
    return clamp(value, 0, 10_000_000);
  }

  /* ----------------------------------------------------------
     REPS / SETS — realistic human limits
  ---------------------------------------------------------- */
  function reps(value) {
    return clamp(Math.round(num(value, 0)), 0, 1000);
  }

  function sets(value) {
    return clamp(Math.round(num(value, 0)), 0, 30);
  }

  function weight(value) {
    return clamp(num(value, 0), 0, 1000); // kg
  }

  /* ----------------------------------------------------------
     XP — ≥ 0, max reasonable
  ---------------------------------------------------------- */
  function xp(value) {
    return clamp(value, 0, 99_999_999);
  }

  /* ----------------------------------------------------------
     ENGINE LEVEL — 1 to 1000
  ---------------------------------------------------------- */
  function engineLevel(value) {
    return clamp(Math.round(num(value, 1)), 1, 1000);
  }

  /* ----------------------------------------------------------
     STREAK — ≥ 0, max 3650 days (10 years)
  ---------------------------------------------------------- */
  function streak(value) {
    return clamp(Math.round(num(value, 0)), 0, 3650);
  }

  /* ----------------------------------------------------------
     TIMESTAMP — clamp between year 2020 and 2050
  ---------------------------------------------------------- */
  const TS_MIN = new Date('2020-01-01').getTime();
  const TS_MAX = new Date('2050-01-01').getTime();

  function timestamp(value) {
    const n = num(value, Date.now());
    if (n < TS_MIN || n > TS_MAX) return Date.now();
    return n;
  }

  /* ----------------------------------------------------------
     FROM HTML INPUT
  ---------------------------------------------------------- */
  function fromInput(elementOrValue, fallback = 0, min = 0, max = Infinity) {
    const raw = (typeof elementOrValue === 'object' && elementOrValue?.value !== undefined)
      ? elementOrValue.value
      : elementOrValue;
    return clamp(num(raw, fallback), min, max);
  }

  /* ----------------------------------------------------------
     SANITIZE ATTRIBUTES OBJECT — prevent NaN in RPG stats
  ---------------------------------------------------------- */
  function sanitizeAttributes(attrs) {
    if (!attrs || typeof attrs !== 'object') return null;
    const result = {};
    ['STR','END','SPD','POW','DISC','PRC','STA'].forEach(k => {
      const a = attrs[k] || {};
      result[k] = {
        pts:   stat(a.pts),
        level: level(a.level),
      };
    });
    return result;
  }

  /* ----------------------------------------------------------
     SANITIZE ENGINE STATE — repair corrupted state object
     Returns { state, repaired: string[] }
  ---------------------------------------------------------- */
  function sanitizeEngineState(raw) {
    if (!raw || typeof raw !== 'object') {
      return { state: null, repaired: ['entire state null/invalid'] };
    }

    const repaired = [];
    const s = { ...raw };

    // XP / Level
    if (!isFinite(s.xp)    || isNaN(s.xp))    { s.xp    = 0;    repaired.push('xp'); }
    if (!isFinite(s.level) || isNaN(s.level) || s.level < 1) {
      s.level = 1; repaired.push('level');
    }
    s.xp    = xp(s.xp);
    s.level = engineLevel(s.level);

    // Volume / Streak
    if (!isFinite(s.totalVolume))       { s.totalVolume = 0;  repaired.push('totalVolume'); }
    if (!isFinite(s.streak))            { s.streak = 0;       repaired.push('streak'); }
    if (!isFinite(s.workoutsCompleted)) { s.workoutsCompleted = 0; repaired.push('workoutsCompleted'); }

    s.totalVolume       = volume(s.totalVolume);
    s.streak            = streak(s.streak);
    s.workoutsCompleted = clamp(s.workoutsCompleted, 0, 99999);

    // Readiness
    if (!isFinite(s.readiness)) { s.readiness = 100; repaired.push('readiness'); }
    s.readiness = pct(s.readiness);

    // Timestamp
    if (!isFinite(s.lastUpdate) || s.lastUpdate < TS_MIN || s.lastUpdate > TS_MAX) {
      s.lastUpdate = Date.now();
      repaired.push('lastUpdate');
    }

    // Fatigue object
    if (!s.fatigue || typeof s.fatigue !== 'object') {
      s.fatigue = {};
      repaired.push('fatigue');
    }
    const muscles = ['chest','back','legs','shoulders','arms','core'];
    muscles.forEach(m => {
      if (!isFinite(s.fatigue[m]) || isNaN(s.fatigue[m])) {
        s.fatigue[m] = 0;
        repaired.push(`fatigue.${m}`);
      }
      s.fatigue[m] = pct(s.fatigue[m]);
    });

    // weeklyVolume
    if (!s.weeklyVolume || typeof s.weeklyVolume !== 'object') {
      s.weeklyVolume = {};
      repaired.push('weeklyVolume');
    }
    muscles.forEach(m => {
      if (!isFinite(s.weeklyVolume[m])) { s.weeklyVolume[m] = 0; }
      s.weeklyVolume[m] = volume(s.weeklyVolume[m]);
    });

    return { state: s, repaired };
  }

  /* ----------------------------------------------------------
     SANITIZE PROFILE OBJECT
  ---------------------------------------------------------- */
  function sanitizeProfile(p) {
    if (!p || typeof p !== 'object') return null;
    const s = { ...p };

    // Body profile
    if (s.bodyProfile) {
      s.bodyProfile.age    = clamp(num(s.bodyProfile.age,    25), 10, 100);
      s.bodyProfile.weight = clamp(num(s.bodyProfile.weight, 70), 20, 300);
      s.bodyProfile.height = clamp(num(s.bodyProfile.height,170), 100, 250);
    }

    // Attributes
    if (s.attributes) {
      s.attributes = sanitizeAttributes(s.attributes);
    }

    // Streak / fatigue
    s.streak       = streak(s.streak);
    s.fatigueScore = pct(s.fatigueScore);

    // Stats
    if (s.stats) {
      s.stats.totalSessions  = clamp(num(s.stats.totalSessions,  0), 0, 99999);
      s.stats.totalVolume    = volume(s.stats.totalVolume);
      s.stats.longestStreak  = streak(s.stats.longestStreak);
    }

    return s;
  }

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    num, clamp, pct, stat, level, volume, reps, sets, weight,
    xp, engineLevel, streak, timestamp,
    fromInput,
    sanitizeAttributes,
    sanitizeEngineState,
    sanitizeProfile,
  };

})();

if (typeof module !== 'undefined') module.exports = SafeNumber;
