/* ================================================================
   ATTRIBUTE ENGINE — attributeEngine.js
   Operator Military RPG — Stat Storage + Level System

   Display format: Strength Lv.12 · 847 pts
   Soft cap + scaling: effort required ↑ 20% per milestone

   SEPARATE from Physical layer — only reads deltas from ConversionEngine
   ================================================================ */
'use strict';

const AttributeEngine = (() => {

  /* ----------------------------------------------------------
     DEFAULT STATS STATE
  ---------------------------------------------------------- */
  const DEFAULT_STATS = {
    STR: { pts: 0, level: 1 },
    END: { pts: 0, level: 1 },
    SPD: { pts: 0, level: 1 },
    POW: { pts: 0, level: 1 },
    DISC:{ pts: 0, level: 1 },
    PRC: { pts: 0, level: 1 },
    STA: { pts: 0, level: 1 },
  };

  /* ----------------------------------------------------------
     LEVEL CURVE — Soft Cap + 20% Scaling per tier
     Tier 1 (Lv 1-5):   300 pts base
     Tier 2 (Lv 6-10):  base × 1.2
     Tier 3 (Lv 11-20): base × 1.44
     Tier 4 (Lv 21-30): base × 1.728
     Elite (Lv 31+):    base × 2.073
  ---------------------------------------------------------- */
  function ptsToNextLevel(level) {
    const base = 300;
    const tier = Math.floor((level - 1) / 5);
    return Math.floor(base * Math.pow(1.2, tier) * Math.pow(level, 1.3));
  }

  function statLevelFromPts(totalPts) {
    let level = 1;
    let remaining = totalPts;
    while (remaining >= ptsToNextLevel(level)) {
      remaining -= ptsToNextLevel(level);
      level++;
      if (level > 99) break;
    }
    return { level, remaining, nextLevelCost: ptsToNextLevel(level) };
  }

  /* ----------------------------------------------------------
     LOAD / SAVE — multi-profile aware
  ---------------------------------------------------------- */
  function _storageKey() {
    const id = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
             || localStorage.getItem('operator_active_profile');
    return id ? `operator_attributes_${id}` : 'operator_attributes_v1';
  }

  function load() {
    try {
      const raw = localStorage.getItem(_storageKey());
      if (!raw) return JSON.parse(JSON.stringify(DEFAULT_STATS));
      const parsed = JSON.parse(raw);
      const merged = JSON.parse(JSON.stringify(DEFAULT_STATS));
      Object.keys(merged).forEach(k => {
        if (parsed[k]) merged[k] = parsed[k];
      });
      return merged;
    } catch { return JSON.parse(JSON.stringify(DEFAULT_STATS)); }
  }

  function save(stats) {
    try {
      localStorage.setItem(_storageKey(), JSON.stringify(stats));
    } catch (e) {
      console.warn('[AttributeEngine] Save failed:', e);
    }
  }

  /* ----------------------------------------------------------
     APPLY DELTAS — from ConversionEngine.sessionToStats()
  ---------------------------------------------------------- */
  function applyDeltas(deltas) {
    const stats = load();
    const changes = {};

    Object.keys(deltas).forEach(k => {
      // FIX [High]: use null check instead of falsy check — stats[k] is an object, always truthy if it exists
      if (stats[k] == null) return;
      const before = stats[k];
      const levelBefore = before.level;

      // FIX [High]: use ?? instead of || to preserve legitimate 0-value deltas
      stats[k].pts += deltas[k] ?? 0;
      if (stats[k].pts < 0) stats[k].pts = 0;

      // Recalculate level from total pts
      const { level, remaining, nextLevelCost } = statLevelFromPts(stats[k].pts);
      stats[k].level = level;

      changes[k] = {
        ptsGained: deltas[k],
        totalPts: stats[k].pts,
        levelBefore,
        levelAfter: level,
        leveledUp: level > levelBefore,
      };
    });

    save(stats);
    return { stats, changes };
  }

  /* ----------------------------------------------------------
     APPLY DISCIPLINE FROM STREAK (called separately)
  ---------------------------------------------------------- */
  function applyStreakDisc(streakDays) {
    const stats = load();
    const discPts = ConversionEngine.streakToDisc(streakDays);
    // Store raw disc score (overwrite, not additive — streak is current state)
    const { level } = statLevelFromPts(discPts);
    stats.DISC = { pts: discPts, level };
    save(stats);
    return stats.DISC;
  }

  /* ----------------------------------------------------------
     GET DISPLAY DATA — Lv.12 · 847 pts format
  ---------------------------------------------------------- */
  function getDisplay() {
    const stats = load();
    const display = {};
    const meta = ConversionEngine.STAT_META;

    Object.keys(stats).forEach(k => {
      const { pts, level } = stats[k];
      const { level: calcLevel, remaining, nextLevelCost } = statLevelFromPts(pts);
      const pct = Math.min(100, Math.round((remaining / nextLevelCost) * 100));

      display[k] = {
        key: k,
        label: meta[k]?.label || k,
        icon: meta[k]?.icon || '⚡',
        color: meta[k]?.color || '#fff',
        level: calcLevel,
        pts: Math.round(pts),
        pct,
        remaining: Math.round(remaining),
        nextLevelCost: Math.round(nextLevelCost),
        displayText: `Lv.${calcLevel} · ${Math.round(pts).toLocaleString()} pts`,
      };
    });

    return display;
  }

  /* ----------------------------------------------------------
     COMBAT POWER — Rank eligibility formula
     CP = (STR × 2) + END + SPD + POW + (DISC × 3)
     PRC and STA contribute as bonus modifiers
  ---------------------------------------------------------- */
  function getCombatPower() {
    const stats = load();
    const cp =
      (stats.STR.pts  * 2) +
      (stats.END.pts  * 1) +
      (stats.SPD.pts  * 1) +
      (stats.POW.pts  * 1) +
      (stats.DISC.pts * 3) +
      (stats.PRC.pts  * 0.5) +
      (stats.STA.pts  * 0.5);
    return Math.round(cp);
  }

  /* ----------------------------------------------------------
     TOTAL STAT PTS (for rank check alternative)
  ---------------------------------------------------------- */
  function getTotalPts() {
    const stats = load();
    return Math.round(Object.values(stats).reduce((sum, s) => sum + s.pts, 0));
  }

  /* ----------------------------------------------------------
     RAW STATS ACCESS
  ---------------------------------------------------------- */
  function getStats() { return load(); }

  /* ----------------------------------------------------------
     RESET (dev only)
  ---------------------------------------------------------- */
  function reset() {
    save(JSON.parse(JSON.stringify(DEFAULT_STATS)));
  }

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    ptsToNextLevel,
    statLevelFromPts,
    applyDeltas,
    applyStreakDisc,
    getDisplay,
    getCombatPower,
    getTotalPts,
    getStats,
    reset,
  };

})();

if (typeof module !== 'undefined') module.exports = AttributeEngine;
