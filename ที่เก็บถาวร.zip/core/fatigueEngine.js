/* ================================================================
   FATIGUE ENGINE — core/fatigueEngine.js
   Operator Military RPG

   หน้าที่เดียว:
   - คำนวณ Fatigue Score จากข้อมูลการฝึก
   - ตรวจ Deload Trigger Conditions
   - ส่งคืน Advisory (ไม่บังคับ)
   - ปรับ Attribute gain เมื่อ Fatigue สูง (soft penalty)

   ไม่มี Injury Risk Simulation — ใช้แค่ Fatigue + Deload Advisory
   ================================================================ */
'use strict';

const FatigueEngine = (() => {

  /* ----------------------------------------------------------
     FATIGUE THRESHOLDS
  ---------------------------------------------------------- */
  const FATIGUE_LEVELS = {
    FRESH:    { max: 25,  label: 'Fresh',          icon: '🟢', color: '#22c55e', gainMod: 1.0,  advice: 'พร้อมเต็มที่ ฝึกหนักได้เลย' },
    NORMAL:   { max: 50,  label: 'Normal',          icon: '🟡', color: '#eab308', gainMod: 0.95, advice: 'สภาพปกติ ฝึกตามแผนได้' },
    TIRED:    { max: 70,  label: 'Tired',           icon: '🟠', color: '#f97316', gainMod: 0.85, advice: 'เริ่มล้า ลด intensity เล็กน้อย' },
    FATIGUED: { max: 85,  label: 'High Fatigue',    icon: '🔴', color: '#ef4444', gainMod: 0.70, advice: 'ล้ามาก แนะนำ Deload หรือพักเพิ่ม' },
    OVERREACH:{ max: 100, label: 'Overreaching',    icon: '💀', color: '#7f1d1d', gainMod: 0.50, advice: 'เกินขีดจำกัด ควรพักอย่างน้อย 2 วัน' },
  };

  /* ----------------------------------------------------------
     DELOAD TRIGGER CONDITIONS
     ต้องเข้าเงื่อนไขอย่างน้อย 1 ข้อ
  ---------------------------------------------------------- */
  const DELOAD_TRIGGERS = {
    PERF_DROP:    'performance_drop',    // performance ลด 2 session ติด
    VOLUME_SPIKE: 'volume_spike',        // volume เพิ่ม > 20% จาก 4-week avg
    STREAK_FATIGUE: 'streak_fatigue',    // ฝึก >= 6 วันติด
    USER_FLAG:    'user_reported',       // ผู้ใช้รายงานเอง
    HIGH_FATIGUE: 'high_fatigue_score',  // Fatigue score >= 75
  };

  /* ----------------------------------------------------------
     COMPUTE FATIGUE SCORE (0–100)
     Input: session history array (recent sessions)
  ---------------------------------------------------------- */
  function computeFatigue(sessions = [], streak = 0) {
    if (!sessions.length) return { score: 0, level: FATIGUE_LEVELS.FRESH };

    let score = 0;

    // Factor 1: Streak fatigue (0–30 pts)
    // 6 days straight = max streak contribution
    const streakScore = Math.min(30, streak * 5);
    score += streakScore;

    // Factor 2: Volume load ช่วง 7 วันล่าสุด (0–40 pts)
    const recent7 = sessions.filter(s => {
      // FIX [High]: guard against Invalid Date when both s.date and s.ts are missing
      const rawDate = s.date || s.ts;
      if (!rawDate) return false;
      const ts = typeof rawDate === 'number' ? rawDate : new Date(rawDate).getTime();
      if (!isFinite(ts)) return false;
      const daysAgo = (Date.now() - ts) / 86400000;
      return daysAgo <= 7;
    });
    const recentCount = recent7.length;
    // 5+ sessions ใน 7 วัน = สูง
    const sessionDensityScore = Math.min(40, recentCount * 8);
    score += sessionDensityScore;

    // Factor 3: High intensity sessions (0–20 pts)
    const highIntensity = recent7.filter(s => s.intensity === 'high' || (s.readiness && s.readiness < 60));
    score += Math.min(20, highIntensity.length * 7);

    // Factor 4: Recovery gap — ถ้าไม่มีวันพักใน 7 วัน (+10)
    const hasDayOff = recentCount < 7;
    if (!hasDayOff) score += 10;

    score = Math.min(100, Math.round(score));

    const level = getFatigueLevel(score);
    return { score, level };
  }

  function getFatigueLevel(score) {
    if (score <= FATIGUE_LEVELS.FRESH.max)    return { ...FATIGUE_LEVELS.FRESH,     score };
    if (score <= FATIGUE_LEVELS.NORMAL.max)   return { ...FATIGUE_LEVELS.NORMAL,    score };
    if (score <= FATIGUE_LEVELS.TIRED.max)    return { ...FATIGUE_LEVELS.TIRED,     score };
    if (score <= FATIGUE_LEVELS.FATIGUED.max) return { ...FATIGUE_LEVELS.FATIGUED,  score };
    return { ...FATIGUE_LEVELS.OVERREACH, score };
  }

  /* ----------------------------------------------------------
     CHECK DELOAD TRIGGERS
     Input: sessions array, volumeHistory array, streak
     Output: { shouldDeload, triggers[], severity }
  ---------------------------------------------------------- */
  function checkDeloadTriggers(sessions = [], volumeHistory = [], streak = 0) {
    const triggers = [];

    // Trigger 1: Streak >= 6 วัน
    if (streak >= 6) {
      triggers.push({ id: DELOAD_TRIGGERS.STREAK_FATIGUE, label: `ฝึกติดต่อกัน ${streak} วัน` });
    }

    // Trigger 2: Volume spike > 20%
    if (volumeHistory.length >= 4) {
      const last4Avg = volumeHistory.slice(-5, -1).reduce((a, b) => a + b, 0) / 4;
      const thisWeek = volumeHistory[volumeHistory.length - 1] || 0;
      if (last4Avg > 0 && thisWeek > last4Avg * 1.2) {
        triggers.push({
          id: DELOAD_TRIGGERS.VOLUME_SPIKE,
          label: `Volume เพิ่ม ${Math.round(((thisWeek / last4Avg) - 1) * 100)}% จาก avg 4 สัปดาห์`,
        });
      }
    }

    // Trigger 3: Performance drop (2 sessions ติด ที่ volume ลดลง)
    if (sessions.length >= 3) {
      const last3 = sessions.slice(-3);
      const vols = last3.map(s => s.volume || 0);
      if (vols[1] < vols[0] * 0.95 && vols[2] < vols[1] * 0.95) {
        triggers.push({ id: DELOAD_TRIGGERS.PERF_DROP, label: 'Performance ลดลง 2 session ติดต่อกัน' });
      }
    }

    // Trigger 4: High fatigue score
    const { score } = computeFatigue(sessions, streak);
    if (score >= 75) {
      triggers.push({ id: DELOAD_TRIGGERS.HIGH_FATIGUE, label: `Fatigue Score สูง (${score}/100)` });
    }

    const severity = triggers.length >= 3 ? 'high' : triggers.length >= 2 ? 'medium' : triggers.length >= 1 ? 'low' : 'none';

    return {
      shouldDeload: triggers.length > 0,
      triggers,
      severity,
    };
  }

  /* ----------------------------------------------------------
     GET DELOAD ADVISORY — ส่งคืน Advisory message + plan
     ไม่บังคับ — ผู้ใช้เลือกเองว่าจะทำตามหรือไม่
  ---------------------------------------------------------- */
  function getDeloadAdvisory(sessions = [], volumeHistory = [], streak = 0) {
    const { shouldDeload, triggers, severity } = checkDeloadTriggers(sessions, volumeHistory, streak);
    const { score, level } = computeFatigue(sessions, streak);

    if (!shouldDeload) return { show: false, score, level };

    const advisory = {
      show: true,
      severity,
      score,
      level,
      triggers,
      // Military-themed message
      title: severity === 'high'
        ? '⚠️ COMBAT EFFICIENCY DROPPING'
        : '📊 RECOVERY ADVISORY',
      message: severity === 'high'
        ? 'ระดับความล้าสูงมาก แนะนำให้ลด load สัปดาห์นี้'
        : 'ตรวจพบสัญญาณเริ่มล้า พิจารณา Reduced Load Protocol',
      // Deload plan
      deloadPlan: {
        volumeReduction: 0.45,   // ลด 45%
        intensityReduction: 0.12, // ลด 12%
        durationDays: 7,
        label: 'Reduced Load Protocol (1 สัปดาห์)',
      },
      // ผลถ้าทำตาม vs ไม่ทำ
      benefits: {
        follow:    ['DISC +bonus เล็กน้อย', 'Long-term STR growth เสถียร', 'Fatigue ลดเร็ว'],
        ignore:    ['Short-term gain ยังได้', 'Fatigue multiplier เพิ่ม', 'Rank progress อาจช้าลง'],
      },
    };

    return advisory;
  }

  /* ----------------------------------------------------------
     APPLY FATIGUE MODIFIER ต่อ Attribute Gains
     เรียกหลัง computeFatigue() ก่อน applyDeltas()
  ---------------------------------------------------------- */
  function applyFatigueModifier(deltas, fatigueScore) {
    const level = getFatigueLevel(fatigueScore);
    const mod   = level.gainMod;

    const modified = {};
    Object.keys(deltas).forEach(k => {
      modified[k] = Math.round(deltas[k] * mod * 10) / 10;
    });

    return { modified, modifier: mod, level };
  }

  /* ----------------------------------------------------------
     RECORD DELOAD CHOICE — บันทึกว่าผู้ใช้เลือกอะไร
  ---------------------------------------------------------- */
  function _deloadKey() {
    const id = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
             || localStorage.getItem('operator_active_profile');
    return id ? `operator_deload_${id}` : 'operator_deload_log_v1';
  }

  function recordDeloadChoice(choice = 'follow') {
    try {
      const log = JSON.parse(localStorage.getItem(_deloadKey()) || '[]');
      log.push({ choice, date: new Date().toISOString() });
      if (log.length > 20) log.splice(0, log.length - 20);
      localStorage.setItem(_deloadKey(), JSON.stringify(log));
    } catch {}
  }

  function getDeloadHistory() {
    try {
      return JSON.parse(localStorage.getItem(_deloadKey()) || '[]');
    } catch { return []; }
  }

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    FATIGUE_LEVELS,
    DELOAD_TRIGGERS,
    computeFatigue,
    getFatigueLevel,
    checkDeloadTriggers,
    getDeloadAdvisory,
    applyFatigueModifier,
    recordDeloadChoice,
    getDeloadHistory,
  };

})();

if (typeof module !== 'undefined') module.exports = FatigueEngine;
