/* ================================================================
   ERROR LOGGER — core/errorLogger.js
   Operator Military RPG v2

   ─── แก้ปัญหา 5.1 Silent Catch ────────────────────────────────
   - Dev mode: verbose logging + console groups
   - Prod mode: silent (no console spam)
   - Capture save failures → user-visible toast
   - Error history (last 50 errors) for debug export

   ใช้งาน:
     Logger.debug(tag, ...args)     → dev only
     Logger.warn(tag, ...args)      → dev only
     Logger.error(tag, ...args)     → always logs + records
     Logger.saveFail(tag, err)      → shows user toast + logs
     Logger.catchWrap(fn, tag)      → replaces `catch {}` pattern
     Logger.getHistory()            → last 50 errors
     Logger.exportDiagnostic()      → download debug JSON
   ================================================================ */
'use strict';

const Logger = (() => {

  const MAX_HISTORY = 50;
  const _history    = [];

  /* ----------------------------------------------------------
     DEV MODE DETECTION
  ---------------------------------------------------------- */
  function isDevMode() {
    if (typeof window === 'undefined') return true; // Node.js
    return window.__OPERATOR_DEV__ === true
        || window.location?.hostname === 'localhost'
        || window.location?.hostname === '127.0.0.1'
        || window.location?.search?.includes('debug=1');
  }

  /* ----------------------------------------------------------
     RECORD TO HISTORY
  ---------------------------------------------------------- */
  function _record(level, tag, message) {
    _history.push({
      ts:      Date.now(),
      level,
      tag,
      message: typeof message === 'object' ? JSON.stringify(message) : String(message),
    });
    if (_history.length > MAX_HISTORY) _history.shift();
  }

  /* ----------------------------------------------------------
     LOG LEVELS
  ---------------------------------------------------------- */
  function debug(tag, ...args) {
    if (!isDevMode()) return;
    console.log(`%c[${tag}]`, 'color:#64748b', ...args);
  }

  function info(tag, ...args) {
    if (!isDevMode()) return;
    console.log(`%c[${tag}]`, 'color:#78cc55', ...args);
  }

  function warn(tag, ...args) {
    _record('warn', tag, args[0]);
    if (!isDevMode()) return;
    console.warn(`[${tag}]`, ...args);
  }

  function error(tag, ...args) {
    _record('error', tag, args[0]);
    console.error(`[${tag}]`, ...args);
  }

  /* ----------------------------------------------------------
     SAVE FAILURE — notify user if saves fail
     (แทน silent catch {} เมื่อ save ล้มเหลว)
  ---------------------------------------------------------- */
  function saveFail(tag, err) {
    _record('error', tag, 'Save failed: ' + (err?.message || err));
    warn(tag, 'Save failed:', err);

    // User notification — only in browser context
    if (typeof document !== 'undefined') {
      _showSaveWarning(tag);
    }
  }

  let _lastSaveWarnTime = 0;
  function _showSaveWarning(tag) {
    // Throttle: ไม่แสดงซ้ำภายใน 30 วินาที
    if (Date.now() - _lastSaveWarnTime < 30_000) return;
    _lastSaveWarnTime = Date.now();

    if (typeof showToast === 'function') {
      showToast('⚠️ บันทึกข้อมูลล้มเหลว — Storage เต็มหรือมีปัญหา');
    } else {
      // Fallback: banner
      const existing = document.getElementById('save-fail-banner');
      if (existing) return;
      const banner = document.createElement('div');
      banner.id = 'save-fail-banner';
      banner.style.cssText = `
        position:fixed; bottom:80px; left:50%; transform:translateX(-50%);
        background:#7f1d1d; color:#fca5a5; padding:10px 20px;
        border-radius:10px; font-size:13px; z-index:9999;
        border:1px solid #dc2626; max-width:90vw; text-align:center;
      `;
      banner.textContent = '⚠️ บันทึกข้อมูลล้มเหลว — Storage เต็มหรือมีปัญหา';
      document.body?.appendChild(banner);
      setTimeout(() => banner.remove(), 5000);
    }
  }

  /* ----------------------------------------------------------
     CATCH WRAP — แทน try { ... } catch {}
     ใช้: Logger.catchWrap(() => risky(), 'StorageEngine')
  ---------------------------------------------------------- */
  function catchWrap(fn, tag = 'Unknown', fallback = null) {
    try {
      return fn();
    } catch (e) {
      warn(tag, 'Caught error:', e?.message || e);
      return fallback;
    }
  }

  async function catchWrapAsync(fn, tag = 'Unknown', fallback = null) {
    try {
      return await fn();
    } catch (e) {
      warn(tag, 'Caught async error:', e?.message || e);
      return fallback;
    }
  }

  /* ----------------------------------------------------------
     ASSERT — dev-only assertion
  ---------------------------------------------------------- */
  function assert(condition, tag, message) {
    if (!condition) {
      error(tag, 'ASSERTION FAILED:', message);
      if (isDevMode()) {
        // Soft — don't throw, just log
        console.trace(`Assertion: ${message}`);
      }
    }
    return condition;
  }

  /* ----------------------------------------------------------
     STORAGE CHECK — warn if > 80% full
  ---------------------------------------------------------- */
  function checkStorageHealth() {
    try {
      let total = 0;
      for (const k of Object.keys(localStorage)) {
        total += (localStorage.getItem(k) || '').length * 2;
      }
      const usedKB  = Math.round(total / 1024);
      const limitKB = 5120;
      const pct     = usedKB / limitKB;

      if (pct > 0.90) {
        error('StorageHealth', `CRITICAL: Storage ${Math.round(pct*100)}% full (${usedKB}/${limitKB}KB)`);
        _showSaveWarning('StorageHealth');
      } else if (pct > 0.75) {
        warn('StorageHealth', `Storage ${Math.round(pct*100)}% full`);
      }

      return { usedKB, limitKB, pct: Math.round(pct * 100) };
    } catch { return null; }
  }

  /* ----------------------------------------------------------
     GET HISTORY
  ---------------------------------------------------------- */
  function getHistory() {
    return [..._history];
  }

  /* ----------------------------------------------------------
     EXPORT DIAGNOSTIC — download JSON สำหรับ debug
  ---------------------------------------------------------- */
  function exportDiagnostic() {
    const report = {
      exportedAt:     new Date().toISOString(),
      errors:         _history,
      storageHealth:  checkStorageHealth(),
      userAgent:      typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown',
      url:            typeof window !== 'undefined' ? window.location?.href : 'unknown',
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `operator_diagnostic_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  /* ----------------------------------------------------------
     INIT — run storage check on startup
  ---------------------------------------------------------- */
  function init() {
    if (typeof window !== 'undefined') {
      window.addEventListener('load', () => {
        setTimeout(checkStorageHealth, 3000);
        if (typeof StateValidator !== 'undefined') {
          StateValidator.cleanOldBackups();
        }
      });

      // Dev mode indicator
      if (isDevMode()) {
        console.log('%c[OPERATOR] Dev mode active — Logger verbose', 'color:#78cc55;font-weight:bold');
      }
    }
  }

  init();

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    isDevMode,
    debug, info, warn, error,
    saveFail,
    catchWrap, catchWrapAsync,
    assert,
    checkStorageHealth,
    getHistory,
    exportDiagnostic,
  };

})();

if (typeof module !== 'undefined') module.exports = Logger;
