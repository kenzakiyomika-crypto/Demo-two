/* ================================================================
   RANK SYSTEM — core/rankSystem.js  v2 Blueprint
   Operator Military RPG

   4 Tier — CP + Attr + Mission Gate
   CP = STR×2 + END×1.5 + POW×1.5 + SPD×1 + DISC×3 + PRC×0.5 + STA×0.5
   ================================================================ */
'use strict';

const RankSystem = (() => {

  const RANKS = [
    // Tier 0
    { id:0,  tier:0, nameThai:'พลเรือน',        nameEn:'Civilian',       emoji:'👤',        cpRequired:0,    attrReq:{},                                    mission:null },
    { id:1,  tier:0, nameThai:'ผู้ฝึกขั้นต้น',  nameEn:'Recruit',        emoji:'🎽',        cpRequired:150,  attrReq:{},                                    mission:'first_workout' },
    { id:2,  tier:0, nameThai:'พลทหาร',          nameEn:'Private',        emoji:'🪖',        cpRequired:300,  attrReq:{STR:5,END:5},                         mission:'basic_test' },
    // Tier 1
    { id:3,  tier:1, nameThai:'สิบตรี',           nameEn:'Corporal',       emoji:'⭐',        cpRequired:600,  attrReq:{STR:8,END:8,DISC:6},                  mission:'sessions_10' },
    { id:4,  tier:1, nameThai:'สิบเอก',           nameEn:'Sergeant',       emoji:'⭐⭐',      cpRequired:900,  attrReq:{STR:12,END:12,DISC:10},               mission:'streak_7' },
    { id:5,  tier:1, nameThai:'จ่าสิบเอก',        nameEn:'Staff Sergeant', emoji:'⭐⭐⭐',    cpRequired:1300, attrReq:{STR:18,END:18,DISC:15},               mission:'sessions_30' },
    // Tier 2
    { id:6,  tier:2, nameThai:'ร้อยตรี',          nameEn:'Lieutenant',     emoji:'🔰',        cpRequired:1800, attrReq:{STR:25,END:25,DISC:20,SPD:15},        mission:'streak_30' },
    { id:7,  tier:2, nameThai:'ร้อยเอก',          nameEn:'Captain',        emoji:'🔰🔰',      cpRequired:2400, attrReq:{STR:35,END:35,DISC:30,SPD:20},        mission:'sessions_60' },
    { id:8,  tier:2, nameThai:'พันตรี',           nameEn:'Major',          emoji:'🔰🔰🔰',    cpRequired:3200, attrReq:{STR:50,END:50,DISC:45,SPD:30},        mission:'streak_60' },
    // Tier 3
    { id:9,  tier:3, nameThai:'พันโท',            nameEn:'Lt. Colonel',    emoji:'🎖️',        cpRequired:4200, attrReq:{STR:65,END:65,DISC:60,SPD:45,POW:45}, mission:'sessions_100' },
    { id:10, tier:3, nameThai:'พันเอก',           nameEn:'Colonel',        emoji:'🎖️🎖️',      cpRequired:5500, attrReq:{STR:80,END:80,DISC:75,SPD:60,POW:60}, mission:'streak_180' },
    { id:11, tier:3, nameThai:'พันเอกพิเศษ',     nameEn:'General',        emoji:'🌟🌟',      cpRequired:7000, attrReq:{STR:100,END:100,DISC:90,SPD:75,POW:75},mission:'elite_badge_2' },
  ];

  const MISSIONS = {
    first_workout: { label:'ออกกำลังกายครั้งแรก',   check:(p)=> p.totalSessions>=1 },
    basic_test:    { label:'ผ่านการทดสอบพื้นฐาน',    check:(p)=> (p.physicalTests?.pushup_max||0)>=10 || p.totalSessions>=5 },
    sessions_10:   { label:'บันทึก 10 sessions',      check:(p)=> p.totalSessions>=10 },
    streak_7:      { label:'ฝึกติดต่อกัน 7 วัน',     check:(p)=> p.streak>=7 },
    sessions_30:   { label:'บันทึก 30 sessions',      check:(p)=> p.totalSessions>=30 },
    streak_30:     { label:'ฝึกติดต่อกัน 30 วัน',    check:(p)=> p.streak>=30 },
    sessions_60:   { label:'บันทึก 60 sessions',      check:(p)=> p.totalSessions>=60 },
    streak_60:     { label:'ฝึกติดต่อกัน 60 วัน',    check:(p)=> p.streak>=60 },
    sessions_100:  { label:'บันทึก 100 sessions',     check:(p)=> p.totalSessions>=100 },
    streak_180:    { label:'Streak สะสม 180 วัน',     check:(p)=> (p.totalStreak||p.streak)>=180 },
    elite_badge_2: { label:'Elite Badge ≥ 2 สาย',     check:(p)=> (p.sfAchieved?.length||0)>=2 },
  };

  const SF_TIERS = [
    { id:'infantry',    labelThai:'มาตรฐานทหารราบ',      flag:'🪖', color:'#78716c', passive:'+2% STR gain',
      checks:{ pushup:{label:'Push-up ≥ 35',key:'pushup_max',min:35}, run2km:{label:'2.4km < 16 นาที',key:'run_2km_min',max:16} },
      attrReq:{STR:5,END:5} },
    { id:'ranger',      labelThai:'ระดับ Ranger',         flag:'⚔️', color:'#4ade80', passive:'+3% STR, +3% END',
      checks:{ pushup:{label:'Push-up ≥ 49',key:'pushup_max',min:49}, pullup:{label:'Pull-up ≥ 12',key:'pullup_max',min:12}, run5km:{label:'5km < 23 นาที',key:'run_5km_min',max:23} },
      attrReq:{STR:10,END:10,DISC:8} },
    { id:'airborne',    labelThai:'ระดับ Airborne',       flag:'🪂', color:'#60a5fa', passive:'+4% END, +2% SPD',
      checks:{ pushup:{label:'Push-up ≥ 60',key:'pushup_max',min:60}, pullup:{label:'Pull-up ≥ 15',key:'pullup_max',min:15}, run5km:{label:'5km < 22 นาที',key:'run_5km_min',max:22}, plank:{label:'Plank ≥ 3 นาที',key:'plank_min',min:3} },
      attrReq:{STR:12,END:12,DISC:10} },
    { id:'heavy_infantry',labelThai:'ทหารราบหนัก',       flag:'🛡️', color:'#f97316', passive:'+5% STR, +3% POW',
      checks:{ squat:{label:'Squat ≥ 1.5x BW',key:'squat_bw_ratio',min:1.5}, deadlift:{label:'Deadlift ≥ 2x BW',key:'deadlift_bw_ratio',min:2.0} },
      attrReq:{STR:15,POW:12} },
    { id:'recon',       labelThai:'หน่วยลาดตระเวน',      flag:'🎯', color:'#a78bfa', passive:'+5% SPD, +3% END',
      checks:{ run5km:{label:'5km < 20 นาที',key:'run_5km_min',max:20}, pullup:{label:'Pull-up ≥ 15',key:'pullup_max',min:15} },
      attrReq:{SPD:15,END:15,DISC:12} },
    { id:'special_ops', labelThai:'หน่วยรบพิเศษ / SEAL', flag:'🔱', color:'#f59e0b', passive:'+5% ทุก stat',
      checks:{ pushup:{label:'Push-up ≥ 80',key:'pushup_max',min:80}, pullup:{label:'Pull-up ≥ 20',key:'pullup_max',min:20}, run5km:{label:'5km < 20 นาที',key:'run_5km_min',max:20}, plank:{label:'Plank ≥ 5 นาที',key:'plank_min',min:5} },
      attrReq:{STR:15,END:15,DISC:12,SPD:12} },
    { id:'tier1',       labelThai:'Tier 1 — Delta/SAS',   flag:'💀', color:'#ef4444', passive:'+10% Combat Power',
      checks:{ pushup:{label:'Push-up ≥ 100',key:'pushup_max',min:100}, pullup:{label:'Pull-up ≥ 25',key:'pullup_max',min:25}, run5km:{label:'5km < 18 นาที',key:'run_5km_min',max:18}, plank:{label:'Plank ≥ 10 นาที',key:'plank_min',min:10} },
      attrReq:{STR:20,END:20,DISC:15,SPD:15,POW:15} },
  ];

  function _key() {
    const id = (typeof StorageEngine!=='undefined' ? StorageEngine.getActiveProfileId() : null)
             || localStorage.getItem('operator_active_profile');
    return id ? `operator_rank_${id}` : 'operator_rank_v1';
  }

  function _load() {
    try { const r=localStorage.getItem(_key()); return r?JSON.parse(r):_def(); } catch { return _def(); }
  }
  function _def() { return {currentRankId:0,unlockedMissions:[],sfAchieved:[],physicalTests:{},history:[],totalSessions:0,totalStreak:0}; }
  function _save(d) {
    try {
      localStorage.setItem(_key(), JSON.stringify(d));
    } catch(e) {
      // FIX [High]: log save failure instead of silent catch
      if (typeof Logger !== 'undefined') Logger.saveFail('RankSystem', e);
      else console.warn('[RankSystem] Save failed:', e?.message);
    }
  }

  function calcCombatPower(stats) {
    return Math.round(
      (stats.STR?.pts||0)*2.0 + (stats.END?.pts||0)*1.5 + (stats.POW?.pts||0)*1.5 +
      (stats.SPD?.pts||0)*1.0 + (stats.DISC?.pts||0)*3.0 + (stats.PRC?.pts||0)*0.5 + (stats.STA?.pts||0)*0.5
    );
  }

  function _attrOk(req,stats) {
    return Object.entries(req).every(([k,lv])=>(stats[k]?.level||0)>=lv);
  }

  function evaluateRank(stats,streak,totalSessions) {
    const data=_load(); const cp=calcCombatPower(stats);
    const profile={cp,stats,streak,totalSessions,sfAchieved:data.sfAchieved,physicalTests:data.physicalTests,totalStreak:data.totalStreak||streak};
    let newId=0;
    for(const r of RANKS){
      if(cp<r.cpRequired) break;
      if(!_attrOk(r.attrReq,stats)) continue;
      if(r.mission&&!data.unlockedMissions.includes(r.mission)) continue;
      newId=r.id;
    }
    const promoted=newId>data.currentRankId;
    if(promoted){data.history.push({from:data.currentRankId,to:newId,date:new Date().toISOString(),cp});data.currentRankId=newId;}
    data.totalSessions=Math.max(data.totalSessions,totalSessions||0);
    data.totalStreak=Math.max(data.totalStreak||0,streak||0);
    _save(data);
    const cur=RANKS[data.currentRankId]; const nxt=RANKS[Math.min(data.currentRankId+1,RANKS.length-1)];
    return {current:cur,next:nxt,promoted,cp,cpToNext:Math.max(0,(nxt?.cpRequired||0)-cp)};
  }

  function checkMissions(stats,streak,totalSessions) {
    const data=_load();
    const profile={stats,streak,totalSessions,sfAchieved:data.sfAchieved,physicalTests:data.physicalTests,totalStreak:data.totalStreak||streak};
    const unlocked=[];
    Object.entries(MISSIONS).forEach(([id,m])=>{
      if(!data.unlockedMissions.includes(id)&&m.check(profile)){data.unlockedMissions.push(id);unlocked.push({id,label:m.label});}
    });
    if(unlocked.length)_save(data);
    return unlocked;
  }

  function recordPhysicalTest(key,val) {
    const data=_load(); if(!data.physicalTests)data.physicalTests={};
    const cur=data.physicalTests[key]; const isTime=key.includes('_min');
    data.physicalTests[key]=(cur===undefined)?val:(isTime?Math.min(cur,val):Math.max(cur,val));
    _save(data); return evaluateSFTiers();
  }

  function evaluateSFTiers(statsOverride) {
    const data=_load(); const tests=data.physicalTests||{};
    let stats=statsOverride;
    if(!stats&&typeof AttributeEngine!=='undefined')stats=AttributeEngine.getStats();
    return SF_TIERS.map(tier=>{
      const cr={}; let allOk=true;
      Object.entries(tier.checks).forEach(([k,c])=>{
        const v=tests[c.key]; const ok=v!==undefined?(c.min!==undefined?v>=c.min:v<=c.max):false;
        cr[k]={...c,value:v,passed:ok}; if(!ok)allOk=false;
      });
      const attrOk=stats?_attrOk(tier.attrReq||{},stats):true; if(!attrOk)allOk=false;
      const ach=(data.sfAchieved||[]).includes(tier.id);
      if(allOk&&!ach){if(!data.sfAchieved)data.sfAchieved=[];data.sfAchieved.push(tier.id);_save(data);}
      const pc=Object.values(cr).filter(c=>c.passed).length; const tc=Object.keys(cr).length;
      return {...tier,checkResults:cr,attrOk,passed:allOk,achieved:(data.sfAchieved||[]).includes(tier.id),progress:`${pc}/${tc}`,progressPct:tc>0?Math.round((pc/tc)*100):0};
    });
  }

  function getState() {
    const data=_load();
    return {currentRank:RANKS[data.currentRankId]||RANKS[0],allRanks:RANKS,sfTiers:evaluateSFTiers(),unlockedMissions:data.unlockedMissions,physicalTests:data.physicalTests,totalSessions:data.totalSessions,sfAchieved:data.sfAchieved};
  }

  function incrementSessions() { const d=_load(); d.totalSessions=(d.totalSessions||0)+1; _save(d); return d.totalSessions; }
  function getRankData() { return _load(); }

  return { RANKS, SF_TIERS, MISSIONS, calcCombatPower, evaluateRank, checkMissions, recordPhysicalTest, evaluateSFTiers, getState, incrementSessions, getRankData };

})();

if(typeof module!=='undefined')module.exports=RankSystem;
