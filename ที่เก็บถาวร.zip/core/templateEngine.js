/* ================================================================
   TEMPLATE ENGINE — core/templateEngine.js
   Operator Military RPG v2

   สร้างแผนฝึก 4-Week Adaptive Hybrid
   - Rule-based (ไม่ต้องใช้ AI)
   - รับ goal weights + body focus + equipment
   - สร้าง weekly plan ที่ปรับ progressive overload อัตโนมัติ
   - Week 4 = Deload เสมอ
   ================================================================ */
'use strict';

const TemplateEngine = (() => {

  /* ----------------------------------------------------------
     GOAL WEIGHTS
     แต่ละ goal มี volume factor + intensity factor + cardio factor
  ---------------------------------------------------------- */
  const GOAL_WEIGHTS = {
    strength:      { volume: 0.8,  intensity: 1.3, cardio: 0.5, restMod: 1.4 },
    hypertrophy:   { volume: 1.2,  intensity: 0.7, cardio: 0.6, restMod: 0.9 },
    fat_loss:      { volume: 1.1,  intensity: 0.8, cardio: 1.3, restMod: 0.6 },
    endurance:     { volume: 1.0,  intensity: 0.6, cardio: 1.5, restMod: 0.6 },
    military_prep: { volume: 1.1,  intensity: 1.0, cardio: 1.2, restMod: 0.9 },
    hybrid:        { volume: 1.0,  intensity: 1.0, cardio: 1.0, restMod: 1.0 },
  };

  /* ----------------------------------------------------------
     REP RANGES per goal
  ---------------------------------------------------------- */
  const REP_RANGES = {
    strength:      { min: 3,  max: 6,  sets: 5 },
    hypertrophy:   { min: 8,  max: 12, sets: 4 },
    fat_loss:      { min: 12, max: 20, sets: 3 },
    endurance:     { min: 15, max: 25, sets: 3 },
    military_prep: { min: 8,  max: 15, sets: 4 },
    hybrid:        { min: 8,  max: 15, sets: 4 },
  };

  /* ----------------------------------------------------------
     WEEKLY VOLUME TARGETS (reps × sets baseline)
  ---------------------------------------------------------- */
  const BASE_WEEKLY_VOLUME = {
    beginner:     8000,
    intermediate: 12000,
    advanced:     18000,
  };

  /* ----------------------------------------------------------
     EXERCISE POOL per muscle group + equipment
  ---------------------------------------------------------- */
  const EXERCISE_POOL = {
    chest: {
      bodyweight: ['Push-up', 'Wide Push-up', 'Diamond Push-up', 'Decline Push-up'],
      dumbbell:   ['Dumbbell Press', 'Dumbbell Fly', 'Incline Dumbbell Press'],
      barbell:    ['Bench Press', 'Incline Bench Press', 'Close-grip Bench'],
    },
    back: {
      bodyweight:  ['Inverted Row', 'Superman', 'Pull-up'],
      pullupbar:   ['Pull-up', 'Chin-up', 'Hanging Knee Raise'],
      dumbbell:    ['Dumbbell Row', 'Seal Row'],
      barbell:     ['Barbell Row', 'Deadlift', 'Rack Pull'],
    },
    legs: {
      bodyweight: ['Squat', 'Lunge', 'Glute Bridge', 'Step-up', 'Jump Squat'],
      dumbbell:   ['Goblet Squat', 'Romanian Deadlift', 'Dumbbell Lunge'],
      barbell:    ['Back Squat', 'Front Squat', 'Romanian Deadlift', 'Hip Thrust'],
    },
    shoulders: {
      bodyweight: ['Pike Push-up', 'Wall Handstand', 'Lateral Raise (no weight)'],
      dumbbell:   ['Overhead Press', 'Lateral Raise', 'Front Raise', 'Face Pull'],
      barbell:    ['Military Press', 'Push Press'],
    },
    core: {
      bodyweight: ['Plank', 'Hollow Hold', 'Leg Raise', 'Bicycle Crunch', 'Dead Bug', 'Mountain Climber'],
    },
    cardio: {
      bodyweight: ['วิ่ง 2-5km', 'Jump Rope 10 นาที', 'Burpee 3x15', 'Jumping Jack'],
      kettlebell: ['Kettlebell Swing', 'Kettlebell Clean'],
    },
  };

  /* ----------------------------------------------------------
     SPLIT TEMPLATES — แบ่งวันฝึกตาม goal + daysPerWeek
  ---------------------------------------------------------- */
  const SPLITS = {
    3: {
      strength:      ['fullbody', 'fullbody', 'fullbody'],
      hypertrophy:   ['push',     'pull',     'legs'],
      fat_loss:      ['upper',    'cardio',   'lower'],
      endurance:     ['run',      'circuit',  'run'],
      military_prep: ['push_pull','run',      'legs_core'],
      hybrid:        ['upper',    'lower',    'cardio'],
    },
    4: {
      strength:      ['upper',    'lower',    'upper',    'lower'],
      hypertrophy:   ['push',     'pull',     'legs',     'upper'],
      fat_loss:      ['upper',    'cardio',   'lower',    'cardio'],
      endurance:     ['run',      'circuit',  'run',      'long_run'],
      military_prep: ['push_pull','run',      'legs_core','fullbody'],
      hybrid:        ['push',     'run',      'pull_legs','core'],
    },
    5: {
      strength:      ['upper',    'lower',    'upper',    'lower',    'fullbody'],
      hypertrophy:   ['chest_shoulders','back','legs',    'arms',     'fullbody'],
      fat_loss:      ['upper',    'cardio',   'lower',    'cardio',   'upper'],
      endurance:     ['run',      'circuit',  'run',      'long_run', 'circuit'],
      military_prep: ['push_pull','run',      'legs_core','fullbody', 'run'],
      hybrid:        ['push',     'run',      'pull',     'legs',     'core'],
    },
    6: {
      strength:      ['upper',    'lower',    'upper',    'lower',    'upper',    'lower'],
      hypertrophy:   ['chest',    'back',     'legs',     'shoulders','arms',     'fullbody'],
      fat_loss:      ['upper',    'cardio',   'lower',    'cardio',   'upper',    'cardio'],
      endurance:     ['run',      'circuit',  'run',      'long_run', 'circuit',  'run'],
      military_prep: ['push_pull','run',      'legs_core','upper',    'run',      'fullbody'],
      hybrid:        ['push',     'run',      'pull',     'legs',     'core',     'fullbody'],
    },
  };

  const DAY_NAMES_TH = ['วันที่ 1', 'วันที่ 2', 'วันที่ 3', 'วันที่ 4', 'วันที่ 5', 'วันที่ 6', 'วันที่ 7'];
  const SESSION_ICONS = {
    push: '💪', pull: '🏋️', legs: '🦵', upper: '💪', lower: '🦵',
    fullbody: '⚡', cardio: '🏃', run: '🏃', long_run: '🏃',
    core: '🎯', circuit: '🔥', push_pull: '⚔️', legs_core: '🦵',
    chest: '💪', back: '🏋️', shoulders: '💪', arms: '💪',
    chest_shoulders: '💪',
  };

  /* ----------------------------------------------------------
     PICK EXERCISES for a session type
  ---------------------------------------------------------- */
  function _pickExercises(sessionType, equipment = [], repRange, numExercises = 4) {
    const hasEquip = (e) => equipment.length === 0 || equipment.includes(e) || equipment.includes('Bodyweight');
    const pool = [];

    const muscleSets = {
      push:             ['chest', 'shoulders'],
      pull:             ['back'],
      legs:             ['legs'],
      upper:            ['chest', 'back', 'shoulders'],
      lower:            ['legs'],
      fullbody:         ['chest', 'back', 'legs', 'core'],
      cardio:           ['cardio'],
      run:              ['cardio'],
      long_run:         ['cardio'],
      core:             ['core'],
      circuit:          ['chest', 'legs', 'core', 'cardio'],
      push_pull:        ['chest', 'back', 'shoulders'],
      legs_core:        ['legs', 'core'],
      chest:            ['chest'],
      back:             ['back'],
      shoulders:        ['shoulders'],
      arms:             ['chest', 'back'],
      chest_shoulders:  ['chest', 'shoulders'],
    };

    const muscles = muscleSets[sessionType] || ['fullbody'];

    muscles.forEach(muscle => {
      const musclePool = EXERCISE_POOL[muscle];
      if (!musclePool) return;

      if (hasEquip('บาร์เบล') && musclePool.barbell) pool.push(...musclePool.barbell);
      else if (hasEquip('ดัมเบล') && musclePool.dumbbell) pool.push(...musclePool.dumbbell);
      else if (hasEquip('บาร์โหน') && musclePool.pullupbar) pool.push(...musclePool.pullupbar);
      else if (hasEquip('Kettlebell') && musclePool.kettlebell) pool.push(...musclePool.kettlebell);
      else if (musclePool.bodyweight) pool.push(...musclePool.bodyweight);
    });

    // Deduplicate + shuffle
    const unique = [...new Set(pool)];
    const shuffled = unique.sort(() => Math.random() - 0.5);
    return shuffled.slice(0, numExercises).map(name => ({
      name,
      sets: repRange.sets,
      reps: `${repRange.min}–${repRange.max}`,
    }));
  }

  /* ----------------------------------------------------------
     BUILD WEEK — สร้าง 1 สัปดาห์
  ---------------------------------------------------------- */
  function _buildWeek(weekNum, goalId, daysPerWeek, equipment, fitnessLevel, isDeload) {
    const repRange   = { ...REP_RANGES[goalId] || REP_RANGES.hybrid };
    const goalWeight = GOAL_WEIGHTS[goalId] || GOAL_WEIGHTS.hybrid;
    const split      = (SPLITS[daysPerWeek] || SPLITS[4])[goalId] || (SPLITS[4])[goalId] || (SPLITS[4]).hybrid;

    // Progressive overload: เพิ่ม volume ทีละ 5-10% ต่อสัปดาห์
    const overloadMod = isDeload ? 0.55 : 1 + (weekNum - 1) * 0.07;
    const baseVol     = BASE_WEEKLY_VOLUME[fitnessLevel] || BASE_WEEKLY_VOLUME.beginner;
    const weekVolume  = Math.round(baseVol * goalWeight.volume * overloadMod);

    // Deload: ลด reps + sets
    if (isDeload) {
      repRange.min  = Math.max(5, Math.floor(repRange.min * 0.6));
      repRange.max  = Math.max(8, Math.floor(repRange.max * 0.6));
      repRange.sets = Math.max(2, repRange.sets - 1);
    }

    const restBase = 60;
    const restSec  = Math.round(restBase * goalWeight.restMod);

    const days = split.map((sessionType, i) => {
      const exercises = _pickExercises(sessionType, equipment, repRange, 4);
      return {
        day:       DAY_NAMES_TH[i] || `วันที่ ${i + 1}`,
        type:      sessionType,
        icon:      SESSION_ICONS[sessionType] || '⚡',
        exercises,
        restSec,
        note:      isDeload ? '💤 Deload — ลด load 45%, เน้นฟอร์ม' : `Rest ${restSec}s ระหว่าง set`,
        isDeload,
      };
    });

    // เติม rest days
    while (days.length < 7) {
      days.push({
        day:      DAY_NAMES_TH[days.length] || `วันที่ ${days.length + 1}`,
        type:     'rest',
        icon:     '😴',
        exercises:[],
        note:     'พักฟื้น — Active recovery: เดิน / ยืดเหยียด',
        isDeload,
      });
    }

    return {
      week:        weekNum,
      label:       isDeload      ? '💤 Deload Week'
                 : weekNum === 3 ? '🔥 Peak Week'
                 : weekNum === 2 ? '⚡ Build Week'
                 :                 '🔧 Foundation Week',
      weekVolume,
      restSec,
      overloadMod: Math.round(overloadMod * 100),
      days,
    };
  }

  /* ----------------------------------------------------------
     BLEND GOALS — ผสม primary + secondary (60/40)
  ---------------------------------------------------------- */
  function _blendGoalId(primaryId, secondaryId) {
    if (!secondaryId || secondaryId === primaryId) return primaryId;
    // ถ้า goal ใกล้กัน ใช้ primary
    // ถ้าต่างกันมาก ใช้ hybrid เป็น default
    const compatMap = {
      'strength+hypertrophy':   'hypertrophy',
      'hypertrophy+strength':   'hypertrophy',
      'strength+military_prep': 'military_prep',
      'endurance+fat_loss':     'fat_loss',
      'fat_loss+endurance':     'fat_loss',
    };
    return compatMap[`${primaryId}+${secondaryId}`] || primaryId;
  }

  /* ----------------------------------------------------------
     GENERATE 4-WEEK PLAN — Public entry point
  ---------------------------------------------------------- */
  function generate4WeekPlan(config = {}) {
    const {
      primaryGoal   = 'hybrid',
      secondaryGoal = null,
      daysPerWeek   = 4,
      equipment     = [],
      fitnessLevel  = 'beginner',
    } = config;

    const effectiveGoal = _blendGoalId(primaryGoal, secondaryGoal);
    const weeks = [];

    for (let w = 1; w <= 4; w++) {
      const isDeload = w === 4;
      weeks.push(_buildWeek(w, effectiveGoal, daysPerWeek, equipment, fitnessLevel, isDeload));
    }

    return {
      goalId:        effectiveGoal,
      primaryGoal,
      secondaryGoal,
      daysPerWeek,
      fitnessLevel,
      equipment,
      weeks,
      generatedAt:   new Date().toISOString(),
      summary: {
        avgVolumePerWeek: Math.round(weeks.slice(0, 3).reduce((s, w) => s + w.weekVolume, 0) / 3),
        totalSessions:    weeks.reduce((s, w) => s + w.days.filter(d => d.type !== 'rest').length, 0),
        deloadWeek:       4,
      },
    };
  }

  /* ----------------------------------------------------------
     SAVE / LOAD CURRENT PLAN
  ---------------------------------------------------------- */
  function savePlan(plan, profileId) {
    const key = profileId ? `operator_plan_${profileId}` : 'operator_current_plan';
    try {
      localStorage.setItem(key, JSON.stringify(plan));
      return true;
    } catch { return false; }
  }

  function loadPlan(profileId) {
    const key = profileId ? `operator_plan_${profileId}` : 'operator_current_plan';
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }

  /* ----------------------------------------------------------
     GET CURRENT WEEK PLAN
  ---------------------------------------------------------- */
  function getCurrentWeekPlan(profileId) {
    const plan  = loadPlan(profileId);
    if (!plan) return null;

    const cycleInfo = typeof ProfileManager !== 'undefined'
      ? ProfileManager.getCycleInfo(profileId)
      : { currentWeek: 1 };

    const weekIndex = Math.min(cycleInfo.currentWeek - 1, plan.weeks.length - 1);
    return plan.weeks[weekIndex] || plan.weeks[0];
  }

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    GOAL_WEIGHTS,
    REP_RANGES,
    generate4WeekPlan,
    savePlan,
    loadPlan,
    getCurrentWeekPlan,
  };

})();

if (typeof module !== 'undefined') module.exports = TemplateEngine;
