/* ================================================================
   GOAL ENGINE — core/goalEngine.js
   Operator Military RPG

   หน้าที่เดียว:
   - รับ Goal Configuration จากผู้ใช้ (onboarding)
   - คำนวณ Attribute Scaling Multipliers
   - Generate Training Template แบบ rule-based (ไม่ใช้ AI)
   - บันทึก Goal ลง SM (StateManager)

   ปรัชญา: Scientific Core, Gamified Scaling
   ================================================================ */
'use strict';

const GoalEngine = (() => {

  /* ----------------------------------------------------------
     GOAL DEFINITIONS
  ---------------------------------------------------------- */
  const GOALS = {
    strength: {
      id: 'strength',
      labelThai: 'เพิ่มความแข็งแรง',
      labelEn: 'Strength',
      icon: '🏋️',
      color: '#ef4444',
      desc: 'เพิ่ม 1RM, ยกน้ำหนักได้มากขึ้น',
      // Attribute scaling multipliers
      attrScale: { STR: 1.3, POW: 1.1, END: 0.9, SPD: 0.8, DISC: 1.0, PRC: 1.1, STA: 0.9 },
      // Training parameters
      training: { repRange: [3, 6], restSec: [120, 180], setsPerEx: [4, 5], weeklyFreq: 4 },
      // Rank path bonus: ไปเร็วขึ้นในสาย Infantry/Assault
      rankPathBonus: ['infantry', 'assault'],
    },
    hypertrophy: {
      id: 'hypertrophy',
      labelThai: 'เพิ่มกล้ามเนื้อ',
      labelEn: 'Hypertrophy',
      icon: '💪',
      color: '#f97316',
      desc: 'กล้ามใหญ่ขึ้น, นิยามชัด',
      attrScale: { STR: 1.1, POW: 1.0, END: 1.0, SPD: 0.9, DISC: 1.0, PRC: 1.2, STA: 1.0 },
      training: { repRange: [8, 12], restSec: [60, 90], setsPerEx: [3, 4], weeklyFreq: 4 },
      rankPathBonus: ['infantry'],
    },
    fat_loss: {
      id: 'fat_loss',
      labelThai: 'ลดไขมัน',
      labelEn: 'Fat Loss',
      icon: '🔥',
      color: '#f59e0b',
      desc: 'ลดไขมัน, เพิ่ม definition',
      attrScale: { STR: 0.9, POW: 1.0, END: 1.2, SPD: 1.2, DISC: 1.1, PRC: 0.9, STA: 1.1 },
      training: { repRange: [12, 20], restSec: [30, 60], setsPerEx: [3, 4], weeklyFreq: 5 },
      rankPathBonus: ['recon'],
    },
    endurance: {
      id: 'endurance',
      labelThai: 'เพิ่มความทนทาน',
      labelEn: 'Endurance',
      icon: '🏃',
      color: '#3b82f6',
      desc: 'วิ่งไกล, ทนนาน, หัวใจแข็งแรง',
      attrScale: { STR: 0.8, POW: 0.8, END: 1.4, SPD: 1.2, DISC: 1.0, PRC: 0.9, STA: 1.2 },
      training: { repRange: [15, 25], restSec: [30, 45], setsPerEx: [2, 3], weeklyFreq: 5 },
      rankPathBonus: ['recon'],
    },
    military_prep: {
      id: 'military_prep',
      labelThai: 'เตรียมสอบทหาร/หน่วยพิเศษ',
      labelEn: 'Military Prep',
      icon: '🪖',
      color: '#10b981',
      desc: 'Pushup/Pullup/Run มาตรฐานทหาร',
      attrScale: { STR: 1.1, POW: 1.0, END: 1.2, SPD: 1.1, DISC: 1.3, PRC: 1.0, STA: 1.1 },
      training: { repRange: [8, 15], restSec: [60, 90], setsPerEx: [3, 5], weeklyFreq: 5 },
      rankPathBonus: ['infantry', 'recon'],
    },
    hybrid: {
      id: 'hybrid',
      labelThai: 'ฟิตรอบด้าน',
      labelEn: 'Hybrid / General',
      icon: '⚡',
      color: '#8b5cf6',
      desc: 'สมดุลทุกด้าน, เติบโตช้ากว่าแต่ยั่งยืน',
      attrScale: { STR: 1.0, POW: 1.0, END: 1.0, SPD: 1.0, DISC: 1.0, PRC: 1.0, STA: 1.0 },
      training: { repRange: [8, 15], restSec: [60, 90], setsPerEx: [3, 4], weeklyFreq: 4 },
      rankPathBonus: [],
    },
  };

  /* ----------------------------------------------------------
     BODY FOCUS AREAS (3-2-1 Priority System)
  ---------------------------------------------------------- */
  const BODY_FOCUS = {
    upper:  { labelThai: 'Upper Body', icon: '💪', muscles: ['chest', 'back', 'shoulders', 'arms'] },
    lower:  { labelThai: 'Lower Body', icon: '🦵', muscles: ['legs', 'glutes', 'calves'] },
    core:   { labelThai: 'Core',       icon: '🎯', muscles: ['core', 'abs'] },
    cardio: { labelThai: 'Cardio',     icon: '🏃', muscles: ['cardio'] },
  };

  const PRIORITY_LEVELS = { 3: 'มาก', 2: 'กลาง', 1: 'น้อย' };

  /* ----------------------------------------------------------
     STORAGE KEY — multi-profile aware
  ---------------------------------------------------------- */
  function _storageKey() {
    const id = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
             || localStorage.getItem('operator_active_profile');
    return id ? `operator_goal_${id}` : 'operator_goal_config_v1';
  }

  /* ----------------------------------------------------------
     LOAD / SAVE — with expiry cleanup (Fix 3.2)
  ---------------------------------------------------------- */
  const GOAL_MAX_AGE_MS = 120 * 24 * 60 * 60 * 1000; // 120 วัน

  function load() {
    try {
      const raw = localStorage.getItem(_storageKey())
               || localStorage.getItem('operator_goal_config_v1');
      if (!raw) return null;
      const config = JSON.parse(raw);

      // Fix 3.2: cleanup stale goal config (> 120 days old)
      if (config.savedAt) {
        const age = Date.now() - config.savedAt;
        if (age > GOAL_MAX_AGE_MS) {
          if (typeof Logger !== 'undefined') Logger.info('GoalEngine', 'Goal config expired, clearing');
          localStorage.removeItem(_storageKey());
          return null;
        }
      }

      return config;
    } catch (e) {
      if (typeof Logger !== 'undefined') Logger.warn('GoalEngine', 'Load failed:', e?.message);
      return null;
    }
  }

  function save(config) {
    try {
      localStorage.setItem(_storageKey(), JSON.stringify({ ...config, savedAt: Date.now() }));
    } catch (e) {
      if (typeof Logger !== 'undefined') Logger.saveFail('GoalEngine', e);
      else console.warn('[GoalEngine] Save failed:', e);
    }
  }

  /* ----------------------------------------------------------
     VALIDATE CONFIG
  ---------------------------------------------------------- */
  function validateConfig(config) {
    const errors = [];
    if (!config.primaryGoal || !GOALS[config.primaryGoal]) {
      errors.push('กรุณาเลือกเป้าหมายหลัก');
    }
    if (!config.bodyFocus || Object.keys(config.bodyFocus).length === 0) {
      errors.push('กรุณาเลือกส่วนที่ต้องการเน้น');
    }
    return { valid: errors.length === 0, errors };
  }

  /* ----------------------------------------------------------
     SET CONFIG — บันทึก Goal Configuration
  ---------------------------------------------------------- */
  function setConfig(config) {
    const { valid, errors } = validateConfig(config);
    if (!valid) return { success: false, errors };

    const fullConfig = {
      primaryGoal:   config.primaryGoal,
      secondaryGoal: config.secondaryGoal || null,
      bodyFocus:     config.bodyFocus || { upper: 2, lower: 2, core: 1, cardio: 1 },
      baseline:      config.baseline || {},   // physical test results at start
      customNote:    config.customNote || '',
    };

    save(fullConfig);
    return { success: true, config: fullConfig };
  }

  /* ----------------------------------------------------------
     GET ATTRIBUTE MULTIPLIERS
     ผสม primary + secondary (secondary = 40% weight)
  ---------------------------------------------------------- */
  function getAttrMultipliers() {
    const config = load();
    if (!config || !config.primaryGoal) return _defaultMultipliers();

    const primary = GOALS[config.primaryGoal];
    if (!primary) return _defaultMultipliers();

    const multipliers = { ...primary.attrScale };

    // Blend secondary goal (40% influence)
    if (config.secondaryGoal && GOALS[config.secondaryGoal]) {
      const secondary = GOALS[config.secondaryGoal].attrScale;
      Object.keys(multipliers).forEach(stat => {
        multipliers[stat] = multipliers[stat] * 0.6 + (secondary[stat] || 1.0) * 0.4;
        multipliers[stat] = Math.round(multipliers[stat] * 100) / 100;
      });
    }

    return multipliers;
  }

  function _defaultMultipliers() {
    return { STR: 1.0, END: 1.0, SPD: 1.0, POW: 1.0, DISC: 1.0, PRC: 1.0, STA: 1.0 };
  }

  /* ----------------------------------------------------------
     GET TRAINING PARAMS — สำหรับ Training Generator
  ---------------------------------------------------------- */
  function getTrainingParams() {
    const config = load();
    if (!config || !config.primaryGoal) return GOALS.hybrid.training;
    return GOALS[config.primaryGoal]?.training || GOALS.hybrid.training;
  }

  /* ----------------------------------------------------------
     GENERATE WEEKLY TEMPLATE — rule-based, ไม่ใช้ AI
     ส่งคืน template สัปดาห์ตาม goal + focus + equipment
  ---------------------------------------------------------- */
  function generateWeeklyTemplate(equipment = [], daysPerWeek = 4) {
    const config = load();
    const goal   = GOALS[config?.primaryGoal || 'hybrid'];
    const focus  = config?.bodyFocus || { upper: 2, lower: 2, core: 1, cardio: 1 };
    const params = goal.training;

    // คำนวณวันที่จัดสรรตาม priority
    const totalPriority = Object.values(focus).reduce((a, b) => a + b, 0);
    const dayAlloc = {};
    let assigned = 0;
    Object.entries(focus).sort((a, b) => b[1] - a[1]).forEach(([area, pri], i) => {
      const days = i < daysPerWeek - assigned
        ? Math.max(1, Math.round((pri / totalPriority) * daysPerWeek))
        : 0;
      dayAlloc[area] = days;
      assigned += days;
    });

    // สร้าง day templates
    const hasEquip = (e) => equipment.length === 0 || equipment.includes(e);
    const days = [];

    const dayNames = ['วันที่ 1', 'วันที่ 2', 'วันที่ 3', 'วันที่ 4', 'วันที่ 5', 'วันที่ 6'];
    let dayIndex = 0;

    const sessionTemplates = {
      upper: {
        name: 'Upper Body',
        icon: '💪',
        exercises: [
          hasEquip('บาร์โหน') ? { name: 'Pull-up', sets: params.setsPerEx[0], reps: `${params.repRange[0]}-${params.repRange[1]}` } : { name: 'Push-up', sets: params.setsPerEx[0], reps: `${params.repRange[0]}-${params.repRange[1]}` },
          { name: 'Push-up', sets: params.setsPerEx[0], reps: `${params.repRange[0]}-${params.repRange[1]}` },
          hasEquip('ดัมเบล') ? { name: 'Dumbbell Row', sets: 3, reps: `${params.repRange[0]}-${params.repRange[1]}` } : { name: 'Inverted Row', sets: 3, reps: `${params.repRange[0]}-${params.repRange[1]}` },
        ],
      },
      lower: {
        name: 'Lower Body',
        icon: '🦵',
        exercises: [
          hasEquip('บาร์เบล') ? { name: 'Squat', sets: params.setsPerEx[0], reps: `${params.repRange[0]}-${params.repRange[1]}` } : { name: 'Bodyweight Squat', sets: params.setsPerEx[0], reps: `${params.repRange[1]}-${params.repRange[1]+5}` },
          { name: 'Lunge', sets: 3, reps: `${params.repRange[0]}-${params.repRange[1]}` },
          { name: 'Calf Raise', sets: 3, reps: `${params.repRange[1]}-${params.repRange[1]+5}` },
        ],
      },
      core: {
        name: 'Core + Stability',
        icon: '🎯',
        exercises: [
          { name: 'Plank', sets: 3, reps: '30-60 วินาที' },
          { name: 'Hollow Hold', sets: 3, reps: '20-30 วินาที' },
          { name: 'Leg Raise', sets: 3, reps: `${params.repRange[0]}-${params.repRange[1]}` },
        ],
      },
      cardio: {
        name: 'Cardio / Conditioning',
        icon: '🏃',
        exercises: [
          { name: 'วิ่ง', sets: 1, reps: '2-5 กม.', note: 'Pace สบาย' },
          { name: 'Jump Rope', sets: 3, reps: '2 นาที' },
          { name: 'Burpee', sets: 3, reps: `${params.repRange[0]}-${params.repRange[1]}` },
        ],
      },
    };

    Object.entries(dayAlloc).forEach(([area, numDays]) => {
      for (let d = 0; d < numDays && dayIndex < daysPerWeek; d++, dayIndex++) {
        days.push({
          day: dayNames[dayIndex],
          type: area,
          ...sessionTemplates[area],
          restSec: params.restSec,
          note: `Rest ${params.restSec[0]}–${params.restSec[1]} วิ ระหว่าง set`,
        });
      }
    });

    // เติม rest day
    while (days.length < 7) {
      days.push({ day: dayNames[days.length] || `วันที่ ${days.length + 1}`, type: 'rest', name: 'พักฟื้น', icon: '😴', exercises: [] });
    }

    return {
      goal: goal.labelThai,
      goalId: config?.primaryGoal || 'hybrid',
      params,
      days,
      generatedAt: new Date().toISOString(),
    };
  }

  /* ----------------------------------------------------------
     GET CURRENT CONFIG (public)
  ---------------------------------------------------------- */
  function getConfig() { return load(); }
  function getGoals()  { return GOALS; }
  function getBodyFocusAreas() { return BODY_FOCUS; }
  function getPriorityLevels() { return PRIORITY_LEVELS; }
  function hasConfig()         { return !!load(); }

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    GOALS,
    BODY_FOCUS,
    PRIORITY_LEVELS,
    setConfig,
    getConfig,
    getAttrMultipliers,
    getTrainingParams,
    generateWeeklyTemplate,
    getGoals,
    getBodyFocusAreas,
    getPriorityLevels,
    hasConfig,
  };

})();

if (typeof module !== 'undefined') module.exports = GoalEngine;
