/* ================================================================
   DECISION ENGINE — engine/decision_engine.js
   Tactical Adaptive Training OS

   "เสถียรกว่า AI cloud" — deterministic, reproducible, fast

   ✅ Features:
     evaluate()               — main decision: day type + intensity
     detectConsecutiveHeavy() — วันหนักติดกัน detection
     calcCNSFatigue()         — CNS fatigue score จาก training history
     calcAccumulatedStress()  — ACWR-inspired training load ratio
     checkInjuryRisk()        — push/pull, quad/ham, shoulder imbalance
     explain()                — Explain Mode: เหตุผลภาษาไทย
     getStateSummary()        — state machine current state
   ================================================================ */
'use strict';

const DecisionEngine = {

  /* ----------------------------------------------------------
     THRESHOLDS
  ---------------------------------------------------------- */
  T: {
    READINESS_RECOVERY:     40,   // < 40% → recovery day บังคับ
    READINESS_LIGHT:        60,   // < 60% → light day
    READINESS_NORMAL:       75,   // < 75% → normal day
    CNS_HEAVY_LIMIT:        70,   // CNS fatigue > 70 → no heavy day
    CONSECUTIVE_HEAVY_MAX:  2,    // หนักได้สูงสุด 2 วันติดกัน
    MUSCLE_FATIGUE_REST:    70,   // fatigue > 70% → ห้ามฝึกกล้ามนั้น
    ACWR_HIGH:              1.5,  // ACWR > 1.5 → injury risk สูง
    ACWR_LOW:               0.8,  // ACWR < 0.8 → undertrained
    IMBALANCE_THRESHOLD:    0.6,  // ratio < 0.6 = imbalance
  },

  /* ----------------------------------------------------------
     evaluate — main decision function
     คืน DayPlan: { type, intensity, muscles, reasons[], warnings[] }
  ---------------------------------------------------------- */
  evaluate() {
    const OE       = window.OPERATOR_ENGINE;
    const reasons  = [];
    const warnings = [];

    if (!OE) {
      return {
        type:      'push',
        intensity: 0.75,
        muscles:   ['chest', 'shoulders', 'arms'],
        reasons:   ['ใช้โปรแกรมเริ่มต้น (Engine ยังไม่โหลด)'],
        warnings:  [],
        explainTH: 'ไม่มีข้อมูล Engine — ใช้โปรแกรมเริ่มต้น',
      };
    }

    const state     = OE.state;
    const readiness = Math.round(state.readiness || 100);
    const fatigue   = state.fatigue  || {};
    const phase     = typeof OE.getCurrentPhase === 'function' ? OE.getCurrentPhase() : { intensity: 0.75, nameTH: 'Base' };

    // ── Rule 1: Readiness บังคับ Recovery ──────────────────────
    if (readiness < this.T.READINESS_RECOVERY) {
      reasons.push(`Readiness ต่ำมาก (${readiness}%) — พักฟื้น`);
      return this._buildPlan('recovery', 0.3, [], reasons, warnings, OE);
    }

    // ── Rule 2: CNS Fatigue ─────────────────────────────────────
    const cns = this.calcCNSFatigue();
    if (cns > this.T.CNS_HEAVY_LIMIT) {
      reasons.push(`CNS Fatigue สูง (${cns.toFixed(0)}%) — ลด Intensity`);
      warnings.push(`⚠️ CNS ล้า — หลีกเลี่ยงท่าที่ต้องการ coordination สูง`);
    }

    // ── Rule 3: Consecutive Heavy Days ─────────────────────────
    const consec = this.detectConsecutiveHeavy();
    if (consec >= this.T.CONSECUTIVE_HEAVY_MAX) {
      reasons.push(`ฝึกหนัก ${consec} วันติดกัน — สลับ moderate/recovery`);
      warnings.push(`⚠️ ${consec} วันติดกัน — ควร Moderate หรือ Recovery วันนี้`);
    }

    // ── Rule 4: ACWR Training Load ─────────────────────────────
    const acwr = this.calcAccumulatedStress();
    if (acwr.ratio > this.T.ACWR_HIGH) {
      reasons.push(`Training Load สูง (ACWR ${acwr.ratio.toFixed(2)}) — ลด Volume 20%`);
      warnings.push(`⚠️ Overreaching risk — ลด Volume วันนี้`);
    }

    // ── Rule 5: Injury Risk ─────────────────────────────────────
    const injury = this.checkInjuryRisk();
    if (injury.risk !== 'low') {
      warnings.push(...injury.warnings);
    }

    // ── Rule 6: กล้ามเนื้อไหนพร้อม ──────────────────────────────
    const availableMuscles = Object.entries(fatigue)
      .filter(([, f]) => f < this.T.MUSCLE_FATIGUE_REST)
      .map(([m]) => m);

    const restedMuscles = Object.entries(fatigue)
      .sort((a, b) => a[1] - b[1])  // เรียงจาก fatigue น้อยสุด
      .slice(0, 3)
      .map(([m]) => m);

    // ── Rule 7: เลือก day type ─────────────────────────────────
    const type      = this._pickDayType(readiness, consec, cns, restedMuscles, acwr);
    const intensity = this._calcIntensity(readiness, consec, cns, phase, acwr);

    if (!reasons.length) reasons.push(`Readiness ${readiness}% — ฝึกได้ปกติ`);

    return this._buildPlan(type, intensity, restedMuscles, reasons, warnings, OE);
  },

  /* ----------------------------------------------------------
     _pickDayType — เลือก day type จาก rules
  ---------------------------------------------------------- */
  _pickDayType(readiness, consec, cns, restedMuscles, acwr) {
    // Recovery conditions
    if (readiness < this.T.READINESS_LIGHT)      return 'recovery';
    if (consec >= this.T.CONSECUTIVE_HEAVY_MAX)  return 'moderate';
    if (acwr.ratio > this.T.ACWR_HIGH)           return 'moderate';
    if (cns > this.T.CNS_HEAVY_LIMIT)            return 'moderate';

    // ตาม muscle readiness
    const hasFreshLegs  = restedMuscles.includes('legs');
    const hasFreshChest = restedMuscles.includes('chest');
    const hasFreshBack  = restedMuscles.includes('back');
    const hasFreshCore  = restedMuscles.includes('core');

    // วนรอบ push/pull/run/core ตาม muscle state
    if (hasFreshLegs)                          return 'run';
    if (hasFreshChest && hasFreshBack)         return 'fullbody';
    if (hasFreshChest)                         return 'push';
    if (hasFreshBack)                          return 'pull';
    if (hasFreshCore)                          return 'core';

    return 'recovery';
  },

  /* ----------------------------------------------------------
     _calcIntensity — คำนวณ intensity ตาม rules
  ---------------------------------------------------------- */
  _calcIntensity(readiness, consec, cns, phase, acwr) {
    let base = phase.intensity || 0.75;

    if (readiness < 60)                          base *= 0.70;
    else if (readiness < 75)                     base *= 0.85;

    if (consec >= this.T.CONSECUTIVE_HEAVY_MAX)  base *= 0.80;
    if (cns > 60)                                base *= (1 - (cns - 60) / 200);
    if (acwr.ratio > 1.3)                        base *= 0.85;

    return Math.max(0.4, Math.min(1.0, base));
  },

  /* ----------------------------------------------------------
     detectConsecutiveHeavy — นับวันหนักติดกัน
     อ้างอิงจาก workoutLog ที่บันทึกประเภทวัน (ถ้ามี)
     หรือใช้ streak + session volume เป็น proxy
  ---------------------------------------------------------- */
  detectConsecutiveHeavy() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return 0;

    // ใช้ workoutLog ถ้ามี
    const log = OE.state.workoutLog;
    if (Array.isArray(log) && log.length > 0) {
      const sorted = [...log].sort((a, b) => new Date(b.date) - new Date(a.date));
      let count = 0;
      for (const entry of sorted) {
        if (entry.intensity === 'heavy' || (entry.volume && entry.volume > 5000)) {
          count++;
        } else break;
      }
      return count;
    }

    // Fallback: ประมาณจาก fatigue pattern
    const fatigue = OE.state.fatigue || {};
    const highFatigueCount = Object.values(fatigue).filter(f => f > 50).length;
    // ถ้ากล้ามเนื้อ > 2 กลุ่มมี fatigue สูง และ streak > 0 → น่าจะฝึกมาหลายวัน
    if (highFatigueCount >= 3 && OE.state.streak > 2) return 2;
    if (highFatigueCount >= 2 && OE.state.streak > 1) return 1;
    return 0;
  },

  /* ----------------------------------------------------------
     calcCNSFatigue — คำนวณ CNS Fatigue Score (0-100)
     สูตร: weighted average ของ muscle fatigue + streak penalty
     + high-intensity session count
  ---------------------------------------------------------- */
  calcCNSFatigue() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return 0;

    const fatigue = OE.state.fatigue || {};
    const streak  = OE.state.streak  || 0;

    // base = avg fatigue ทุก muscle
    const values  = Object.values(fatigue);
    // FIX [High]: avgFatigue already guarded; also fix Math.max spread on empty → -Infinity
    const avgFatigue = values.length
      ? values.reduce((a, b) => a + (isFinite(b) ? b : 0), 0) / values.length
      : 0;

    // streak penalty: ฝึกทุกวัน > 5 วัน → CNS เริ่มล้า
    const streakPenalty = streak > 5 ? Math.min(30, (streak - 5) * 5) : 0;

    // max muscle fatigue penalty
    // FIX [High]: Math.max(...emptyArray, 0) is OK because 0 is always included,
    // but add explicit guard for clarity and safety
    const maxFatigue = values.length ? Math.max(...values.map(v => isFinite(v) ? v : 0), 0) : 0;
    const maxPenalty = maxFatigue > 80 ? (maxFatigue - 80) * 0.5 : 0;

    const cns = Math.min(100, avgFatigue * 0.6 + streakPenalty + maxPenalty);
    return Math.round(cns);
  },

  /* ----------------------------------------------------------
     calcAccumulatedStress — ACWR-inspired ratio
     Acute Workload (7 วัน) / Chronic Workload (28 วัน average)
     ratio > 1.5 = overreaching risk
     ratio < 0.8 = detrained / undertraining
  ---------------------------------------------------------- */
  calcAccumulatedStress() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return { acute: 0, chronic: 0, ratio: 1.0, zone: 'normal' };

    const totalVol    = OE.state.totalVolume    || 0;
    const weeklyVol   = OE.state.weeklyVolume   || {};
    const weekNumber  = OE.state.weekNumber     || 1;

    // acute = sum of weekly volumes ปัจจุบัน
    const acute = Object.values(weeklyVol).reduce((a, b) => a + b, 0);

    // chronic = total / weeks elapsed (ประมาณ)
    const weeksElapsed = Math.max(1, weekNumber);
    const chronic = weeksElapsed > 0 ? totalVol / weeksElapsed : acute;

    const ratio = chronic > 0 ? acute / chronic : 1.0;

    const zone = ratio > 1.5  ? 'high_risk'
               : ratio > 1.3  ? 'caution'
               : ratio > 0.8  ? 'optimal'
               : ratio > 0.5  ? 'low'
               : 'detrained';

    return { acute: Math.round(acute), chronic: Math.round(chronic), ratio, zone };
  },

  /* ----------------------------------------------------------
     checkInjuryRisk — ตรวจ muscle imbalance patterns
  ---------------------------------------------------------- */
  checkInjuryRisk() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return { risk: 'low', warnings: [] };

    const weeklyVol = OE.state.weeklyVolume || {};
    const fatigue   = OE.state.fatigue || {};
    const warnings  = [];

    // Push/Pull imbalance
    const pushVol = (weeklyVol.chest || 0) + (weeklyVol.shoulders || 0) * 0.5;
    const pullVol = weeklyVol.back || 0;
    if (pullVol > 0 && pushVol / pullVol > 1.8) {
      warnings.push('⚠️ Push มากกว่า Pull เกิน 1.8× — ไหล่อาจบาดเจ็บ เพิ่มดึงข้อ');
    }
    if (pushVol > 0 && pullVol / pushVol < this.T.IMBALANCE_THRESHOLD) {
      warnings.push('⚠️ Back อ่อนแอกว่า Chest — เพิ่ม Row/Pull Up วันนี้');
    }

    // Shoulder overuse
    const shoulderFatigue = fatigue.shoulders || 0;
    const chestFatigue    = fatigue.chest     || 0;
    if (shoulderFatigue > 70 && chestFatigue > 60) {
      warnings.push('⚠️ Shoulder fatigue สูง ('+Math.round(shoulderFatigue)+'%) — หลีกเลี่ยงท่า overhead ทุกชนิด');
    }

    // Core weakness relative to legs
    const legVol  = weeklyVol.legs || 0;
    const coreVol = weeklyVol.core || 0;
    if (legVol > 0 && coreVol / legVol < 0.3) {
      warnings.push('⚠️ Core Volume ต่ำกว่า Legs มาก — เพิ่ม Plank/Situps ป้องกัน LBP');
    }

    const risk = warnings.length === 0 ? 'low'
               : warnings.length === 1 ? 'moderate'
               : 'high';

    return { risk, warnings };
  },

  /* ----------------------------------------------------------
     explain — Explain Mode: เหตุผลภาษาไทยสำหรับ day plan
     @param plan  DayPlan จาก evaluate()
     @returns string multiline
  ---------------------------------------------------------- */
  explain(plan) {
    if (!plan) return 'ไม่มีข้อมูล';

    const OE        = window.OPERATOR_ENGINE;
    const readiness = OE ? Math.round(OE.state.readiness || 100) : '?';
    const cns       = this.calcCNSFatigue();
    const consec    = this.detectConsecutiveHeavy();
    const acwr      = this.calcAccumulatedStress();
    const injury    = this.checkInjuryRisk();

    const typeLabel = {
      push:     '💪 Push Day',
      pull:     '🔝 Pull Day',
      run:      '🏃 Cardio Day',
      core:     '🎯 Core Day',
      fullbody: '🔥 Full Body',
      moderate: '⚡ Moderate Day',
      recovery: '💤 Recovery Day',
    }[plan.type] || plan.type;

    const lines = [
      `📋 วันนี้: ${typeLabel} (Intensity ${Math.round((plan.intensity || 0.75) * 100)}%)`,
      ``,
      `🔍 เหตุผล:`,
    ];

    // Readiness
    lines.push(`  • Readiness: ${readiness}%${readiness < 60 ? ' ⚠️ ต่ำ' : readiness >= 80 ? ' ✅ ดี' : ' 🟡 ปานกลาง'}`);

    // CNS
    if (cns > 50) lines.push(`  • CNS Fatigue: ${cns}% — ${cns > 70 ? 'สูงมาก ควรพัก' : 'ควรลด intensity'}`);

    // Consecutive
    if (consec >= 2) lines.push(`  • ฝึกหนัก ${consec} วันติดกัน — สลับวัน moderate`);

    // ACWR
    if (acwr.zone === 'high_risk') lines.push(`  • Training Load สูงเกิน (${acwr.ratio.toFixed(1)}×) — ลด Volume`);
    else if (acwr.zone === 'low')  lines.push(`  • Training Load ต่ำ — สามารถเพิ่ม Volume ได้`);

    // Muscle fatigue
    const OEfatigue = OE?.state?.fatigue || {};
    const tired = Object.entries(OEfatigue)
      .filter(([, f]) => f > this.T.MUSCLE_FATIGUE_REST)
      .map(([m, f]) => `${m} (${Math.round(f)}%)`)
      .join(', ');
    if (tired) lines.push(`  • กล้ามเนื้อพัก: ${tired}`);

    // Custom reasons
    if (plan.reasons?.length) {
      plan.reasons.forEach(r => {
        if (!lines.some(l => l.includes(r.slice(0, 20)))) {
          lines.push(`  • ${r}`);
        }
      });
    }

    // Warnings
    if (plan.warnings?.length || injury.warnings.length) {
      lines.push('', '⚠️ คำเตือน:');
      [...(plan.warnings || []), ...injury.warnings].forEach(w => lines.push(`  ${w}`));
    }

    return lines.join('\n');
  },

  /* ----------------------------------------------------------
     getStateSummary — snapshot สำหรับ debug/display
  ---------------------------------------------------------- */
  getStateSummary() {
    const OE = window.OPERATOR_ENGINE;
    const plan  = this.evaluate();
    const cns   = this.calcCNSFatigue();
    const acwr  = this.calcAccumulatedStress();
    const inj   = this.checkInjuryRisk();
    const consec = this.detectConsecutiveHeavy();

    return {
      plan,
      cns,
      acwr,
      injuryRisk: inj,
      consecutiveHeavy: consec,
      readiness: OE ? Math.round(OE.state.readiness || 100) : 0,
      explain: this.explain(plan),
    };
  },

  /* ----------------------------------------------------------
     _buildPlan — helper
  ---------------------------------------------------------- */
  _buildPlan(type, intensity, muscles, reasons, warnings, OE) {
    const plan = { type, intensity, muscles, reasons, warnings };
    plan.explainTH = this.explain(plan);
    return plan;
  },
};

window.DecisionEngine = DecisionEngine;
console.log('%c[DecisionEngine] Loaded — Deterministic AI ready', 'color:#78cc55');
