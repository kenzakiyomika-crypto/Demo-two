/* ================================================================
   STATE MANAGER — storage/state_manager.js
   Tactical Adaptive Training OS

   Single source of truth — แทน localStorage.getItem ที่กระจัดกระจาย
   ทุก module อ่าน/เขียน state ผ่าน SM เท่านั้น

   ✅ Features:
     get/set/update  — typed access พร้อม validation
     subscribe()     — reactive: แจ้ง callback เมื่อ key เปลี่ยน
     snapshot()      — full state dump สำหรับ debug
     reset()         — reset to defaults (dev only)
     autoSave()      — debounce save to localStorage + IDB backup
   ================================================================ */
'use strict';

const SM = (() => {

  /* ----------------------------------------------------------
     SCHEMA — keys ทั้งหมดของระบบ + defaults
  ---------------------------------------------------------- */
  const SCHEMA = {
    // Profile
    profile:          { key: 'profile_v1',          default: {} },
    equipment:        { key: 'equipment',            default: [] },
    trainLocation:    { key: 'train_location',       default: 'บ้าน' },
    customGoal:       { key: 'custom_goal',          default: '' },

    // AI Settings
    aiProvider:       { key: 'ai_provider',          default: 'gemini' },
    geminiKey:        { key: 'gemini_api_key',       default: '' },
    openaiKey:        { key: 'openai_api_key',       default: '' },
    geminiModel:      { key: 'gemini_model',         default: 'gemini-1.5-flash' },
    openaiModel:      { key: 'openai_model',         default: 'gpt-4o-mini' },

    // Engine State (synced กับ ProductionEngine)
    engineState:      { key: 'operator_production_v1', default: null },

    // Training Cycle (auto-periodization)
    trainingCycleWeek:{ key: 'training_cycle_week', default: 1 },
    cycleTotalWeeks:  { key: 'cycle_total_weeks',   default: 4 },
    lastCycleReset:   { key: 'last_cycle_reset',    default: null },

    // Program
    weeklyProgram:    { key: 'weekly_program',       default: null },
    aiUsage:          { key: 'ai_usage',             default: {} },

    // UI
    currentTab:       { key: 'current_tab',          default: 'dashboard' },
    darkMode:         { key: 'dark_mode',            default: false },
  };

  /* ----------------------------------------------------------
     PRIVATE
  ---------------------------------------------------------- */
  const _cache     = {};          // in-memory cache
  const _listeners = {};          // reactive subscriptions
  let   _saveTimer = null;

  /* ----------------------------------------------------------
     _lsRead — อ่านจาก localStorage พร้อม parse
  ---------------------------------------------------------- */
  function _lsRead(lsKey, fallback) {
    try {
      const raw = localStorage.getItem(lsKey);
      if (raw === null || raw === undefined) return fallback;
      return JSON.parse(raw);
    } catch {
      return fallback;
    }
  }

  /* ----------------------------------------------------------
     _lsWrite — เขียน localStorage พร้อม stringify
  ---------------------------------------------------------- */
  function _lsWrite(lsKey, value) {
    try {
      if (value === null || value === undefined) {
        localStorage.removeItem(lsKey);
      } else {
        localStorage.setItem(lsKey, JSON.stringify(value));
      }
    } catch (e) {
      console.warn('[SM] localStorage write failed:', lsKey, e.message);
    }
  }

  /* ----------------------------------------------------------
     get — อ่าน value (cache → localStorage → default)
  ---------------------------------------------------------- */
  function get(name) {
    if (name in _cache) return _cache[name];
    const schema = SCHEMA[name];
    if (!schema) { console.warn('[SM] Unknown key:', name); return undefined; }
    const val = _lsRead(schema.key, schema.default);
    _cache[name] = val;
    return val;
  }

  /* ----------------------------------------------------------
     set — เขียน value + notify listeners
  ---------------------------------------------------------- */
  function set(name, value) {
    const schema = SCHEMA[name];
    if (!schema) { console.warn('[SM] Unknown key:', name); return; }
    const old = _cache[name];
    _cache[name] = value;
    _lsWrite(schema.key, value);
    _notify(name, value, old);
    _scheduleSave();
  }

  /* ----------------------------------------------------------
     update — partial update สำหรับ object
  ---------------------------------------------------------- */
  function update(name, partial) {
    const current = get(name) || {};
    if (typeof current !== 'object' || Array.isArray(current)) {
      set(name, partial);
      return;
    }
    set(name, { ...current, ...partial });
  }

  /* ----------------------------------------------------------
     subscribe — reactive listener
     @param name     schema key
     @param callback fn(newValue, oldValue)
     @returns unsubscribe function
  ---------------------------------------------------------- */
  function subscribe(name, callback) {
    if (!_listeners[name]) _listeners[name] = [];
    _listeners[name].push(callback);
    return () => {
      _listeners[name] = _listeners[name].filter(cb => cb !== callback);
    };
  }

  function _notify(name, newVal, oldVal) {
    (_listeners[name] || []).forEach(cb => {
      try { cb(newVal, oldVal); } catch {}
    });
  }

  /* ----------------------------------------------------------
     _scheduleSave — debounce IDB backup (500ms)
  ---------------------------------------------------------- */
  function _scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => {
      if (typeof TrainingDB !== 'undefined' && TrainingDB.isAvailable()) {
        TrainingDB.backupSettings();
      }
    }, 500);
  }

  /* ----------------------------------------------------------
     getTrainingCycleIntensity — auto-periodization
     4-week cycle: 80% → 90% → 100% → 60% (deload)
  ---------------------------------------------------------- */
  function getTrainingCycleIntensity() {
    const week = get('trainingCycleWeek') || 1;
    const map  = { 1: 0.80, 2: 0.90, 3: 1.00, 4: 0.60 };
    const cycleWeek = ((week - 1) % 4) + 1;
    return {
      week:      cycleWeek,
      intensity: map[cycleWeek] || 0.80,
      isDeload:  cycleWeek === 4,
      label:     cycleWeek === 4 ? '💤 Deload Week'
                : cycleWeek === 3 ? '🔥 Peak Week'
                : cycleWeek === 2 ? '⚡ Build Week'
                : '🔧 Foundation Week',
    };
  }

  /* ----------------------------------------------------------
     advanceCycleWeek — เลื่อนไปสัปดาห์ถัดไป
  ---------------------------------------------------------- */
  function advanceCycleWeek() {
    const current = get('trainingCycleWeek') || 1;
    set('trainingCycleWeek', current + 1);
    return getTrainingCycleIntensity();
  }

  /* ----------------------------------------------------------
     snapshot — full state dump
  ---------------------------------------------------------- */
  function snapshot() {
    const out = {};
    Object.keys(SCHEMA).forEach(name => { out[name] = get(name); });
    return out;
  }

  /* ----------------------------------------------------------
     invalidateCache — force re-read from localStorage
  ---------------------------------------------------------- */
  function invalidateCache(name) {
    if (name) delete _cache[name];
    else Object.keys(_cache).forEach(k => delete _cache[k]);
  }

  /* ----------------------------------------------------------
     init — pre-warm cache สำหรับ keys ที่ใช้บ่อย
  ---------------------------------------------------------- */
  function init() {
    ['profile', 'equipment', 'aiProvider', 'trainingCycleWeek', 'weeklyProgram'].forEach(get);
    console.log('%c[SM] StateManager ready', 'color:#78cc55');
  }

  return {
    get, set, update, subscribe,
    getTrainingCycleIntensity, advanceCycleWeek,
    snapshot, invalidateCache, init,
    SCHEMA,
  };
})();

window.SM = SM;
SM.init();
