/* ================================================================
   TREND ANALYZER — engine/trend_analyzer.js
   Tactical Adaptive Training OS

   "ระบบที่วิเคราะห์ตัวเองและปรับตัวเอง"

   ✅ Features:
     analyzeTrend()         — 7-day review: strength/endurance/consistency
     getWeeklyReport()      — รายงานสัปดาห์ภาษาไทย
     adjustProgramSmart()   — ปรับโปรแกรมอัตโนมัติถ้าไม่พัฒนา
     getConsistencyScore()  — คะแนนความสม่ำเสมอ (0-100)
     detectStrengthTrend()  — ตรวจว่า strength ↑↓ stable
     detectEnduranceTrend() — ตรวจจาก volume + run data
     getSmartRecommendation() — คำแนะนำ actionable ภาษาไทย
   ================================================================ */
'use strict';

const TrendAnalyzer = {

  /* ----------------------------------------------------------
     CONFIG
  ---------------------------------------------------------- */
  CONFIG: {
    TREND_WINDOW_DAYS:       7,   // วิเคราะห์ย้อนหลัง 7 วัน
    MIN_WORKOUTS_FOR_TREND:  3,   // ต้องมีอย่างน้อย 3 workout ต่อสัปดาห์
    STRENGTH_IMPROVEMENT:    5,   // % ขึ้นไปถือว่า improving
    ENDURANCE_MIN_RUNS:      2,   // ต้องมี 2 run sessions/week
    CONSISTENCY_TARGET:      4,   // target 4 workout/week
  },

  /* ----------------------------------------------------------
     analyzeTrend — วิเคราะห์ประสิทธิภาพ 7 วัน
     @returns TrendReport object
  ---------------------------------------------------------- */
  analyzeTrend() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return this._emptyReport();

    const state     = OE.state;
    const history   = state.exerciseHistory || {};
    const now       = new Date();
    const weekAgo   = new Date(now - 7 * 24 * 60 * 60 * 1000);
    const weekAgoStr = weekAgo.toISOString().split('T')[0];

    // รวม sessions ใน 7 วันล่าสุด
    const recentSessions = this._getRecentSessions(history, weekAgoStr);
    const consistency    = this.getConsistencyScore(recentSessions.workoutDays);
    const strength       = this.detectStrengthTrend(history, weekAgoStr);
    const endurance      = this.detectEnduranceTrend(recentSessions);
    const volume         = this._calcWeeklyVolume(recentSessions.entries);

    // Overall score
    const overallScore = Math.round(
      (consistency.score * 0.4) +
      (strength.score    * 0.35) +
      (endurance.score   * 0.25)
    );

    const grade = overallScore >= 80 ? 'A'
                : overallScore >= 65 ? 'B'
                : overallScore >= 50 ? 'C'
                : overallScore >= 35 ? 'D'
                : 'F';

    const recommendations = this.getSmartRecommendation({
      consistency, strength, endurance, volume, state,
    });

    return {
      period:       '7 วันล่าสุด',
      workouts:     recentSessions.workoutDays,
      consistency,
      strength,
      endurance,
      volume,
      overallScore,
      grade,
      recommendations,
      reportTH:     this._buildReportTH({ consistency, strength, endurance, volume, overallScore, grade, recommendations }),
      adjustments:  this.adjustProgramSmart({ consistency, strength, endurance }),
    };
  },

  /* ----------------------------------------------------------
     getConsistencyScore — คะแนนความสม่ำเสมอ
     @param workoutDays  จำนวนวันที่ออกกำลังกายใน 7 วัน
  ---------------------------------------------------------- */
  getConsistencyScore(workoutDays) {
    const target = this.CONFIG.CONSISTENCY_TARGET;
    const score  = Math.min(100, Math.round((workoutDays / target) * 100));

    const label = score >= 90 ? '🟢 สม่ำเสมอมาก'
                : score >= 70 ? '🟡 ค่อนข้างสม่ำเสมอ'
                : score >= 50 ? '🟠 ไม่สม่ำเสมอ'
                : '🔴 ต้องปรับปรุง';

    const advice = score >= 90 ? 'ดีมาก — รักษาระดับนี้ไว้'
                 : score >= 70 ? 'ดี — พยายามออกกำลังกายให้ครบ 4 วัน/สัปดาห์'
                 : score >= 50 ? 'ต้องเพิ่มความสม่ำเสมอ — ตั้ง reminder ทุกวัน'
                 : 'ออกกำลังกายน้อยมาก — เริ่มจาก 3 วัน/สัปดาห์ก่อน';

    return { workoutDays, target, score, label, advice };
  },

  /* ----------------------------------------------------------
     detectStrengthTrend — ตรวจ strength trend จาก exercise history
  ---------------------------------------------------------- */
  detectStrengthTrend(history, weekAgoStr) {
    let improving = 0, declining = 0, stable = 0, total = 0;
    const details = [];

    // ท่าหลักที่วัด strength (สำหรับทหาร)
    const keyExercises = [
      'push up', 'วิดพื้น', 'pushups',
      'pull up', 'ดึงข้อ', 'pullups',
      'sit up', 'situps', 'วิดหน้าท้อง',
      'squat', 'squat', 'dips',
    ];

    Object.entries(history).forEach(([name, sessions]) => {
      if (!sessions || sessions.length < 2) return;

      const isKey = keyExercises.some(k => name.includes(k));
      const recent = sessions.filter(s => s.date >= weekAgoStr);
      const before = sessions.filter(s => s.date < weekAgoStr).slice(-3);

      if (!recent.length || !before.length) return;

      // เปรียบ volume เฉลี่ย
      const avgRecent = this._avgVol(recent);
      const avgBefore = this._avgVol(before);
      const changePct = avgBefore > 0 ? ((avgRecent - avgBefore) / avgBefore) * 100 : 0;

      total++;
      const weight = isKey ? 2 : 1;  // ท่าหลักมี weight มากกว่า

      if (changePct > this.CONFIG.STRENGTH_IMPROVEMENT) {
        improving += weight;
        details.push({ name, changePct: changePct.toFixed(1), direction: 'up' });
      } else if (changePct < -this.CONFIG.STRENGTH_IMPROVEMENT) {
        declining += weight;
        details.push({ name, changePct: changePct.toFixed(1), direction: 'down' });
      } else {
        stable += weight;
        details.push({ name, changePct: changePct.toFixed(1), direction: 'stable' });
      }
    });

    const totalWeight = improving + declining + stable || 1;
    const score = Math.round((improving / totalWeight) * 100);

    const trend = score >= 60  ? 'improving'
                : score >= 35  ? 'stable'
                : 'declining';

    const label = trend === 'improving' ? '📈 Strength กำลังพัฒนา'
                : trend === 'stable'    ? '➡️ Strength คงที่'
                : '📉 Strength ลดลง';

    const advice = trend === 'improving' ? 'ดีมาก — เพิ่ม Progressive Overload ต่อ'
                 : trend === 'stable'    ? 'ลอง Plateau Breaker: เพิ่ม variation'
                 : 'ลด Volume ลง 20% แล้วเพิ่มใหม่ทีละน้อย';

    return { trend, improving, declining, stable, total, score, label, advice, details };
  },

  /* ----------------------------------------------------------
     detectEnduranceTrend — ตรวจ endurance จาก run/cardio sessions
  ---------------------------------------------------------- */
  detectEnduranceTrend(recentSessions) {
    const runSessions = recentSessions.entries
      .filter(e => e.name?.toLowerCase().includes('run') || e.name?.includes('วิ่ง') || e.name?.includes('sprint'));

    const runCount = runSessions.length;
    const target   = this.CONFIG.ENDURANCE_MIN_RUNS;
    const score    = Math.min(100, Math.round((runCount / target) * 100));

    const label = score >= 100 ? '🟢 Cardio ดีมาก'
                : score >= 50  ? '🟡 Cardio พอใช้'
                : '🟠 ต้องเพิ่ม Cardio';

    const advice = score >= 100 ? 'รักษาระดับ — ลอง Tempo Run เพิ่ม'
                 : score >= 50  ? `ควรเพิ่มเป็น ${target} sessions/week`
                 : 'เพิ่ม วิ่ง 1.6km อย่างน้อย 2 วัน/สัปดาห์';

    return { runCount, target, score, label, advice };
  },

  /* ----------------------------------------------------------
     getSmartRecommendation — คำแนะนำ actionable
  ---------------------------------------------------------- */
  getSmartRecommendation({ consistency, strength, endurance, volume, state }) {
    const recs = [];

    // Consistency
    if (consistency.score < 70) {
      recs.push({
        priority: 'high',
        area:     'consistency',
        action:   `เพิ่มความสม่ำเสมอ — ออกกำลังกายให้ได้ ${this.CONFIG.CONSISTENCY_TARGET} วัน/สัปดาห์`,
        tip:      'ตั้ง alarm 06:00 ทุกวัน แม้แค่ 20 นาทีก็ดี',
      });
    }

    // Strength plateau
    if (strength.trend === 'declining') {
      recs.push({
        priority: 'high',
        area:     'strength',
        action:   'ลด Volume 20% สัปดาห์นี้ แล้วเริ่ม Progressive Overload ใหม่',
        tip:      'Deload week ช่วยให้ฟื้นตัวและกลับมาแข็งแรงกว่าเดิม',
      });
    } else if (strength.trend === 'stable' && strength.total > 2) {
      recs.push({
        priority: 'medium',
        area:     'strength',
        action:   'เพิ่ม Plateau Breaker: ลอง variation ใหม่สำหรับท่าที่ค้าง',
        tip:      ProgressionEngine ? 'ดูคำแนะนำ Variation ใน Progress Tab' : 'ลอง Tempo หรือ Partial Rep',
      });
    }

    // Endurance
    if (endurance.score < 50) {
      recs.push({
        priority: 'medium',
        area:     'endurance',
        action:   'เพิ่มวิ่ง 1.6km อย่างน้อย 2 ครั้ง/สัปดาห์',
        tip:      'วิ่งช้าๆ ก็ได้ สำคัญกว่าคือทำ — สอบทหารต้องวิ่งได้',
      });
    }

    // Volume imbalance from ProgressionEngine (ถ้ามี)
    if (typeof ProgressionEngine !== 'undefined') {
      const volStatus = ProgressionEngine.checkVolumeThreshold();
      Object.entries(volStatus).forEach(([muscle, status]) => {
        if (status.deloadNeeded) {
          recs.push({
            priority: 'high',
            area:     'volume',
            action:   `ลด ${muscle} volume ลง 40% สัปดาห์นี้`,
            tip:      `Volume สูงเกิน threshold (${status.setsEstimate}/${status.threshold} sets est.)`,
          });
        }
      });
    }

    // Injury risk (ถ้า DecisionEngine โหลดแล้ว)
    if (typeof DecisionEngine !== 'undefined') {
      const injury = DecisionEngine.checkInjuryRisk();
      if (injury.risk !== 'low') {
        injury.warnings.forEach(w => {
          recs.push({ priority: 'high', area: 'injury', action: w.replace(/⚠️ /, ''), tip: 'ป้องกันดีกว่าแก้' });
        });
      }
    }

    // Sort by priority
    const order = { high: 0, medium: 1, low: 2 };
    recs.sort((a, b) => (order[a.priority] || 1) - (order[b.priority] || 1));

    return recs.slice(0, 4); // สูงสุด 4 recommendations
  },

  /* ----------------------------------------------------------
     adjustProgramSmart — แนะนำการปรับโปรแกรมอัตโนมัติ
  ---------------------------------------------------------- */
  adjustProgramSmart({ consistency, strength, endurance }) {
    const adjustments = [];

    if (consistency.score < 50) {
      adjustments.push({
        type:   'reduce_complexity',
        action: 'ลดวันฝึกเหลือ 3 วัน/สัปดาห์ เน้นความสม่ำเสมอก่อน',
      });
    }

    if (strength.trend === 'declining') {
      adjustments.push({
        type:   'deload',
        action: 'เพิ่ม Deload Week ทันที — ลด Volume 40%',
        trigger: 'strength_declining',
      });
    }

    if (endurance.score < 50) {
      adjustments.push({
        type:   'add_cardio',
        action: 'เพิ่มวัน Run ในโปรแกรม — อย่างน้อย 2 วัน',
        trigger: 'low_endurance',
      });
    }

    if (strength.trend === 'improving' && consistency.score >= 80) {
      adjustments.push({
        type:   'progress_overload',
        action: 'เพิ่ม Progressive Overload — ทุก exercise ที่ stable 3+ sessions',
        trigger: 'ready_to_progress',
      });
    }

    return adjustments;
  },

  /* ----------------------------------------------------------
     getWeeklyReport — รายงาน 7 วัน ใช้ใน UI
  ---------------------------------------------------------- */
  getWeeklyReport() {
    return this.analyzeTrend();
  },

  /* ----------------------------------------------------------
     _buildReportTH — สร้าง report string ภาษาไทย
  ---------------------------------------------------------- */
  _buildReportTH({ consistency, strength, endurance, volume, overallScore, grade, recommendations }) {
    const lines = [
      `📊 รายงาน 7 วัน — Grade: ${grade} (${overallScore}/100)`,
      ``,
      `🏋️ ความสม่ำเสมอ: ${consistency.label} (${consistency.workoutDays}/${consistency.target} วัน)`,
      `   → ${consistency.advice}`,
      ``,
      `💪 Strength: ${strength.label}`,
      `   → ${strength.advice}`,
      ``,
      `🏃 Cardio: ${endurance.label} (${endurance.runCount} sessions)`,
      `   → ${endurance.advice}`,
    ];

    if (recommendations.length) {
      lines.push('', '🎯 สิ่งที่ควรทำสัปดาห์หน้า:');
      recommendations.forEach((r, i) => {
        const icon = r.priority === 'high' ? '🔴' : r.priority === 'medium' ? '🟡' : '🟢';
        lines.push(`${icon} ${i + 1}. ${r.action}`);
        if (r.tip) lines.push(`   💡 ${r.tip}`);
      });
    }

    return lines.join('\n');
  },

  /* ----------------------------------------------------------
     _getRecentSessions — ดึง session ภายใน N วัน
  ---------------------------------------------------------- */
  _getRecentSessions(history, fromDateStr) {
    const entries = [];
    const workoutDates = new Set();

    Object.entries(history).forEach(([name, sessions]) => {
      sessions.forEach(s => {
        if (s.date >= fromDateStr) {
          entries.push({ name, ...s });
          workoutDates.add(s.date);
        }
      });
    });

    return {
      entries,
      workoutDays: workoutDates.size,
      dates: [...workoutDates].sort(),
    };
  },

  /* ----------------------------------------------------------
     _calcWeeklyVolume — คำนวณ volume ใน 7 วัน จาก sessions
  ---------------------------------------------------------- */
  _calcWeeklyVolume(entries) {
    let total = 0;
    entries.forEach(e => {
      const reps   = typeof e.reps === 'string' ? parseInt(e.reps) || 0 : (e.reps || 0);
      const weight = e.weight > 0 ? e.weight : 1;
      total += (e.sets || 0) * reps * weight;
    });
    return { total: Math.round(total), unit: 'kg·reps' };
  },

  _avgVol(sessions) {
    if (!sessions.length) return 0;
    const total = sessions.reduce((sum, s) => {
      const reps = typeof s.reps === 'string' ? parseInt(s.reps) || 0 : (s.reps || 0);
      const w    = s.weight > 0 ? s.weight : 1;
      return sum + (s.sets || 0) * reps * w;
    }, 0);
    return total / sessions.length;
  },

  _emptyReport() {
    return {
      period:      '7 วันล่าสุด',
      workouts:    0,
      overallScore: 0,
      grade:       'N/A',
      reportTH:    'ยังไม่มีข้อมูลเพียงพอ — เริ่มบันทึก Workout ก่อน',
      recommendations: [],
      adjustments: [],
    };
  },
};

window.TrendAnalyzer = TrendAnalyzer;
console.log('%c[TrendAnalyzer] Loaded', 'color:#78cc55');
