/* ================================================================
   OPERATOR ASCENSION ENGINE  —  ascension_engine.js
   Realism Mode: Sports Science Grade

   Architecture:
     ✅ Exponential Fatigue Decay (per-muscle k coefficient)
     ✅ Stimulus-to-Fatigue Ratio (SFR)
     ✅ Volume Landmarks: MEV / MAV / MRV
     ✅ HRV-Inspired Readiness Score (multi-factor)
     ✅ 4-Week Microcycle Periodization (auto-deload wk4)
     ✅ Estimated 1RM (e1RM) — Epley formula
     ✅ Neural Efficiency Layer
     ✅ Overtraining Detection + Force Deload
     ✅ Realistic Certification Gate
     ✅ Operator Rating (OR) — composite formula
     ✅ Physical Profile per muscle (Strength/Hypertrophy/Neural/Recovery)

   Load Order: after engine.js
   Safe: extends OPERATOR_ENGINE, never overwrites core state schema
   ================================================================ */
'use strict';

/* ============================================================
   EXERCISE PROFILES  —  Stimulus-to-Fatigue Ratio (SFR)
   stimulus / fatigueCost = SFR
   higher SFR = more bang per fatigue unit
   ============================================================ */
const EXERCISE_PROFILES = {
  // Compound heavy
  'squat':             { stimulus: 1.8, fatigueCost: 1.6, muscles: ['legs'],        type: 'compound' },
  'deadlift':          { stimulus: 2.0, fatigueCost: 1.9, muscles: ['back','legs'], type: 'compound' },
  'bench press':       { stimulus: 1.6, fatigueCost: 1.3, muscles: ['chest'],       type: 'compound' },
  'overhead press':    { stimulus: 1.5, fatigueCost: 1.2, muscles: ['shoulders'],   type: 'compound' },
  'barbell row':       { stimulus: 1.6, fatigueCost: 1.3, muscles: ['back'],        type: 'compound' },
  // Bodyweight compound
  'push up':           { stimulus: 1.2, fatigueCost: 0.8, muscles: ['chest','arms'],type: 'compound_bw' },
  'วิดพื้น':            { stimulus: 1.2, fatigueCost: 0.8, muscles: ['chest','arms'],type: 'compound_bw' },
  'pull up':           { stimulus: 1.4, fatigueCost: 0.9, muscles: ['back','arms'], type: 'compound_bw' },
  'ดึงข้อ':             { stimulus: 1.4, fatigueCost: 0.9, muscles: ['back','arms'], type: 'compound_bw' },
  'dip':               { stimulus: 1.2, fatigueCost: 0.8, muscles: ['chest','arms'],type: 'compound_bw' },
  'pike push up':      { stimulus: 1.1, fatigueCost: 0.7, muscles: ['shoulders'],   type: 'compound_bw' },
  // Isolation
  'curl':              { stimulus: 0.8, fatigueCost: 0.5, muscles: ['arms'],        type: 'isolation' },
  'lateral raise':     { stimulus: 0.7, fatigueCost: 0.4, muscles: ['shoulders'],   type: 'isolation' },
  'fly':               { stimulus: 0.8, fatigueCost: 0.5, muscles: ['chest'],       type: 'isolation' },
  // Core
  'plank':             { stimulus: 0.9, fatigueCost: 0.5, muscles: ['core'],        type: 'core' },
  'sit up':            { stimulus: 0.8, fatigueCost: 0.4, muscles: ['core'],        type: 'core' },
  'situp':             { stimulus: 0.8, fatigueCost: 0.4, muscles: ['core'],        type: 'core' },
  'leg raise':         { stimulus: 1.0, fatigueCost: 0.5, muscles: ['core'],        type: 'core' },
  // Cardio
  'run':               { stimulus: 0.8, fatigueCost: 0.9, muscles: ['legs'],        type: 'cardio' },
  'วิ่ง':               { stimulus: 0.8, fatigueCost: 0.9, muscles: ['legs'],        type: 'cardio' },
  'sprint':            { stimulus: 1.1, fatigueCost: 1.2, muscles: ['legs'],        type: 'cardio' },
};

/* ============================================================
   MUSCLE RECOVERY COEFFICIENTS  (k in e^(-k*hours))
   Large slow muscles recover slower → smaller k
   ============================================================ */
const MUSCLE_K = {
  legs:      0.08,  // ขา — ฟื้นช้าสุด
  back:      0.09,
  chest:     0.10,
  shoulders: 0.11,
  arms:      0.13,  // ฟื้นเร็วกว่า
  core:      0.14,  // ฟื้นเร็วสุด
};

/* ============================================================
   VOLUME LANDMARKS  (MEV / MAV / MRV)
   ค่าตาม Dr. Mike Israetel's RP Hypertrophy guidelines
   unit: sets per week
   ============================================================ */
const VOLUME_LANDMARKS = {
  chest:     { MEV: 8,  MAV: 16, MRV: 22 },
  back:      { MEV: 10, MAV: 18, MRV: 25 },
  legs:      { MEV: 8,  MAV: 16, MRV: 20 },
  shoulders: { MEV: 6,  MAV: 14, MRV: 20 },
  arms:      { MEV: 6,  MAV: 14, MRV: 18 },
  core:      { MEV: 8,  MAV: 16, MRV: 25 },
};

/* ============================================================
   ASCENSION ENGINE SINGLETON
   ============================================================ */
const AscensionEngine = {

  /* ----------------------------------------------------------
     STATE EXTENSION  (เพิ่มเข้าไปใน OPERATOR_ENGINE.state)
  ---------------------------------------------------------- */
  _initExtension() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return;

    const s = OE.state;

    if (!s._ascension) {
      s._ascension = {
        // Volume tracking (sets/week per muscle)
        weeklySets: { chest:0, back:0, legs:0, shoulders:0, arms:0, core:0 },

        // Neural efficiency (0–100, starts 50)
        neuralEfficiency: { chest:50, back:50, legs:50, shoulders:50, arms:50, core:50 },

        // Physical adaptation profiles
        physicalProfile: this._initPhysicalProfile(),

        // Periodization microcycle (4-week)
        periodization: { week: 1, phase: 'volume', cycleStart: Date.now() },

        // Overtraining tracking
        overtraining: {
          consecutiveLowReadiness: 0,
          volumeAboveMRV:          {},
          forceDeload:             false,
        },

        // e1RM per exercise (strength trend)
        e1RM: {},

        // Sleep log
        sleepLog: [],

        // Certification status
        certification: {
          volumeWeeks:      0,  // สัปดาห์ที่อยู่ใน MAV zone
          strengthPassed:   false,
          noOvertraining:   true,
          consistencyPct:   0,
          workoutDates:     [],
        },

        // Readiness history (30 days)
        readinessHistory: [],

        // Session XP history for grade tracking
        gradeHistory: [],  // 'S','A','B','C'

        lastUpdated: Date.now(),
      };

      this._save();
    }
  },

  _initPhysicalProfile() {
    const muscles = ['chest','back','legs','shoulders','arms','core'];
    const profile = {};
    muscles.forEach(m => {
      profile[m] = {
        strengthAdaptation:    0,   // 0–100
        hypertrophyAdaptation: 0,
        neuralAdaptation:      0,
        recoverySpeed:         50,  // 0–100
      };
    });
    return profile;
  },

  _save() {
    const OE = window.OPERATOR_ENGINE;
    if (OE?.state) {
      try {
        // FIX [High]: use profile-aware storage key (matches Store.KEY in engine.js)
        const pid = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
                 || localStorage.getItem('operator_active_profile');
        const storeKey = pid ? `operator_production_${pid}` : 'operator_production_v1';
        const raw = localStorage.getItem(storeKey);
        const data = raw ? JSON.parse(raw) : OE.state;
        data._ascension = OE.state._ascension;
        data.lastUpdate = Date.now();
        localStorage.setItem(storeKey, JSON.stringify(data));
      } catch(e) {
        // FIX [High]: log instead of silent catch
        if (typeof Logger !== 'undefined') Logger.saveFail('AscensionEngine', e);
      }
    }
  },

  get _a() {
    return window.OPERATOR_ENGINE?.state?._ascension;
  },

  /* ----------------------------------------------------------
     EXPONENTIAL FATIGUE RECOVERY — per-muscle k coefficient
     fatigue(t) = fatigue0 × e^(-k × hours)
     ถูก trigger จาก AscensionEngine.tick()
  ---------------------------------------------------------- */
  recoverFatigue(muscle, hours) {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return;

    // Recovery speed modifier from physicalProfile
    const baseK     = MUSCLE_K[muscle] || 0.10;
    const recSpeed  = this._a?.physicalProfile?.[muscle]?.recoverySpeed || 50;
    const k         = baseK * (0.7 + (recSpeed / 100) * 0.6);  // k range: 0.7×base – 1.3×base

    const current   = OE.state.fatigue[muscle] || 0;
    if (current <= 0) return;

    const recovered = current * Math.exp(-k * hours);
    OE.state.fatigue[muscle] = Math.max(0, recovered);
  },

  /* ----------------------------------------------------------
     HOURLY TICK — replace engine's simple decay with ScienceMode
  ---------------------------------------------------------- */
  tick() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE || !this._a) return;

    const now      = Date.now();
    const rawHours = (now - (this._a.lastUpdated || now)) / 3_600_000;
    const hours    = Math.min(Math.max(0, isFinite(rawHours) ? rawHours : 0), 240);

    if (hours < 0.05) return;

    // Per-muscle exponential decay
    const muscles = Object.keys(MUSCLE_K);
    muscles.forEach(m => this.recoverFatigue(m, hours));

    // Update base engine's calculateReadiness
    OE.calculateReadiness();

    this._a.lastUpdated = now;

    // Update periodization
    this._checkPeriodizationAdvance();

    // Update overtraining detection
    this._checkOvertraining();

    // Track readiness history
    this._trackReadiness();

    this._save();
  },

  /* ----------------------------------------------------------
     READINESS SCORE  (HRV-inspired, multi-factor)
     readiness = 100
       - avgFatigue × 0.6
       - yesterdayIntensity × 0.3
       + sleepScore × 0.4
  ---------------------------------------------------------- */
  calcAdvancedReadiness() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE || !this._a) return OE?.state?.readiness || 80;

    const fatValues  = Object.values(OE.state.fatigue);
    const avgFatigue = fatValues.reduce((a, b) => a + b, 0) / fatValues.length;

    const yesterday  = this._a.readinessHistory.slice(-2)[0]?.intensity || 0;
    const sleepScore = this._getLastSleepScore();

    const raw = 100
      - (avgFatigue       * 0.6)
      - (yesterday        * 0.3)
      + (sleepScore       * 0.4);

    const clamped = Math.max(0, Math.min(100, raw));

    // Store back
    OE.state.readiness = clamped;
    return clamped;
  },

  getReadinessLabel() {
    const r = this.calcAdvancedReadiness();
    if (r >= 90) return { label: '⚡ PEAK',          color: '#00ff88', advice: 'MAX intensity ได้เลย', tier: 'peak'     };
    if (r >= 70) return { label: '🟢 Train Hard',    color: '#2ecc71', advice: 'ฝึกหนักได้ตามแผน',     tier: 'hard'     };
    if (r >= 50) return { label: '🟡 Moderate',      color: '#f1c40f', advice: 'ลด volume 15%',        tier: 'moderate' };
    if (r >= 30) return { label: '🟠 Light Day',     color: '#e67e22', advice: 'ลด volume 30% ใช้ RPE ต่ำ', tier: 'light' };
    return               { label: '🔴 Deload Now',   color: '#e74c3c', advice: 'Active recovery เท่านั้น', tier: 'deload' };
  },

  /* ----------------------------------------------------------
     VOLUME LANDMARK ANALYSIS
     คืน zone สำหรับแต่ละกล้ามเนื้อ
  ---------------------------------------------------------- */
  analyzeVolumeLandmarks() {
    if (!this._a) return {};
    const result = {};

    Object.keys(VOLUME_LANDMARKS).forEach(muscle => {
      const { MEV, MAV, MRV } = VOLUME_LANDMARKS[muscle];
      const sets = this._a.weeklySets[muscle] || 0;

      let zone, advice, color;

      if (sets < MEV) {
        zone   = 'below_mev';
        advice = `เพิ่ม volume — ต้องการ ≥${MEV} sets/wk`;
        color  = '#778899';
      } else if (sets <= MAV) {
        zone   = 'mav';  // sweet spot
        advice = `✅ MAV Zone — volume เหมาะสม (${sets}/${MAV})`;
        color  = '#2ecc71';
      } else if (sets <= MRV) {
        zone   = 'above_mav';
        advice = `⚠️ เกิน MAV — เข้าใกล้ MRV (${sets}/${MRV})`;
        color  = '#f1c40f';
      } else {
        zone   = 'above_mrv';
        advice = `🔴 เกิน MRV! Fatigue spike — Deload ด่วน`;
        color  = '#e74c3c';
      }

      result[muscle] = { sets, MEV, MAV, MRV, zone, advice, color };
    });

    return result;
  },

  /* ----------------------------------------------------------
     STIMULUS-TO-FATIGUE RATIO (SFR) Logging
     เรียกหลัง logWorkout — ปรับ fatigue ตาม SFR จริง
  ---------------------------------------------------------- */
  applySFR(exercises) {
    const OE = window.OPERATOR_ENGINE;
    if (!OE || !this._a) return;

    exercises.forEach(ex => {
      const name    = (ex.name || '').toLowerCase().trim();
      const profile = this._getExerciseProfile(name);
      const SFR     = profile.stimulus / profile.fatigueCost;

      const sets   = Number(ex.sets)   || 3;
      const reps   = Number(ex.reps)   || 10;
      const weight = Number(ex.weight) > 0 ? Number(ex.weight) : 1;

      const rawVolume = sets * reps * weight;

      // Neural efficiency modifier
      profile.muscles.forEach(muscle => {
        // FIX [Critical]: was `!OE.state.fatigue[muscle] === undefined` which is ALWAYS false
        // due to operator precedence (!x first → boolean, then boolean===undefined → false)
        // Correct intent: skip if muscle key is not tracked in fatigue object
        if (OE.state.fatigue[muscle] === undefined) return;

        const neural      = this._a.neuralEfficiency?.[muscle] || 50;
        const neuralMod   = 1 - (neural - 50) / 1000;  // 50 neural = 1.0x, 100 neural = 0.95x
        const fatigueCost = (rawVolume * 0.001) * profile.fatigueCost * neuralMod;

        OE.state.fatigue[muscle] = Math.min(100,
          (OE.state.fatigue[muscle] || 0) + fatigueCost
        );

        // Track weekly sets
        if (this._a.weeklySets[muscle] !== undefined)
          this._a.weeklySets[muscle] += sets;

        // Physical profile adaptation (slow)
        this._adaptPhysicalProfile(muscle, SFR, rawVolume);
      });

      // e1RM update
      this._updateE1RM(name, reps, weight);
    });

    // Check MRV spike
    this._checkMRVSpike();

    this._save();
  },

  /* ----------------------------------------------------------
     ESTIMATED 1RM  (Epley formula)
     e1RM = weight × (1 + reps / 30)
  ---------------------------------------------------------- */
  _updateE1RM(exerciseName, reps, weight) {
    if (!weight || weight <= 0 || !reps) return;
    const e1rm = weight * (1 + reps / 30);
    if (!this._a.e1RM[exerciseName]) this._a.e1RM[exerciseName] = [];
    this._a.e1RM[exerciseName].push({
      date: new Date().toISOString().split('T')[0],
      e1rm: +e1rm.toFixed(1),
      reps, weight,
    });
    // Keep last 30 entries
    if (this._a.e1RM[exerciseName].length > 30)
      this._a.e1RM[exerciseName] = this._a.e1RM[exerciseName].slice(-30);
  },

  getE1RMTrend(exerciseName) {
    const name = (exerciseName || '').toLowerCase().trim();
    const history = this._a?.e1RM?.[name] || [];
    if (history.length < 2) return { trend: 'insufficient', current: 0, delta: 0 };

    const first = history[0].e1rm;
    const last  = history[history.length - 1].e1rm;
    const delta = +((last - first) / first * 100).toFixed(1);

    return {
      current: last,
      start:   first,
      delta,
      trend: delta > 5 ? 'gaining' : delta > 0 ? 'stable' : 'declining',
      history,
    };
  },

  /* ----------------------------------------------------------
     NEURAL EFFICIENCY LAYER
     Grade S บ่อย → neural efficiency ↑ (fatigue cost ↓)
  ---------------------------------------------------------- */
  recordGrade(muscles, grade) {
    if (!this._a) return;
    const gradeScore = { S: 4, A: 3, B: 2, C: 1, F: 0 }[grade] || 1;

    muscles.forEach(muscle => {
      if (this._a.neuralEfficiency[muscle] === undefined) return;
      const current = this._a.neuralEfficiency[muscle];
      // Grade S = +2, A = +1, B = 0, C = -0.5
      const delta = gradeScore >= 4 ? 2 : gradeScore === 3 ? 1 : gradeScore === 2 ? 0 : -0.5;
      this._a.neuralEfficiency[muscle] = Math.max(0, Math.min(100, current + delta));
    });

    // Store grade history for OR calculation
    this._a.gradeHistory.push({ date: new Date().toISOString().split('T')[0], grade, gradeScore });
    if (this._a.gradeHistory.length > 90)
      this._a.gradeHistory = this._a.gradeHistory.slice(-90);

    this._save();
  },

  /* ----------------------------------------------------------
     OVERTRAINING DETECTION
     - 7d vol > MRV
     - readiness < 40 for 3+ consecutive days
     - fatigue not recovering
  ---------------------------------------------------------- */
  _checkOvertraining() {
    if (!this._a) return;
    const OT = this._a.overtraining;
    const r  = window.OPERATOR_ENGINE?.state?.readiness || 100;

    // Track consecutive low readiness
    if (r < 40) {
      OT.consecutiveLowReadiness = (OT.consecutiveLowReadiness || 0) + 1;
    } else {
      OT.consecutiveLowReadiness = 0;
    }

    const isMRVBreached = Object.values(this.analyzeVolumeLandmarks())
      .some(v => v.zone === 'above_mrv');

    const fatigueStuck = Object.values(window.OPERATOR_ENGINE?.state?.fatigue || {})
      .every(f => f > 65);

    if (
      OT.consecutiveLowReadiness >= 3 ||
      (isMRVBreached && fatigueStuck)
    ) {
      if (!OT.forceDeload) {
        OT.forceDeload = true;
        this._triggerForceDeload();
      }
    } else {
      OT.forceDeload = false;
    }
  },

  _checkMRVSpike() {
    if (!this._a) return;
    const landmarks = this.analyzeVolumeLandmarks();
    const OT = this._a.overtraining;

    Object.entries(landmarks).forEach(([muscle, data]) => {
      if (data.zone === 'above_mrv') {
        OT.volumeAboveMRV = OT.volumeAboveMRV || {};
        OT.volumeAboveMRV[muscle] = (OT.volumeAboveMRV[muscle] || 0) + 1;

        // Spike fatigue when MRV breached
        const OE = window.OPERATOR_ENGINE;
        if (OE) {
          OE.state.fatigue[muscle] = Math.min(100,
            (OE.state.fatigue[muscle] || 0) + 15
          );
        }
      }
    });
  },

  _triggerForceDeload() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return;

    // Reduce volume 40%
    Object.keys(this._a.weeklySets).forEach(m => {
      this._a.weeklySets[m] = Math.floor(this._a.weeklySets[m] * 0.6);
    });

    // Reduce fatigue
    Object.keys(OE.state.fatigue).forEach(m => {
      OE.state.fatigue[m] *= 0.65;
    });

    OE.calculateReadiness();

    if (typeof showToast === 'function')
      showToast('⚠️ FORCE DELOAD — ร่างกายเกิน MRV / Readiness ต่ำ 3+ วัน', 'error');

    this._save();
  },

  isForceDeload() {
    return this._a?.overtraining?.forceDeload === true;
  },

  /* ----------------------------------------------------------
     4-WEEK MICROCYCLE PERIODIZATION
     Week 1: Volume Build
     Week 2: Intensity Focus
     Week 3: Overreach
     Week 4: Deload (auto)
  ---------------------------------------------------------- */
  getPeriodizationPhase() {
    const week = ((this._a?.periodization?.week || 1) - 1) % 4 + 1;

    const phases = {
      1: { name: 'Volume Build',      nameTH: 'สร้าง Volume',     volMod: 1.10, intMod: 0.80, color: '#2ecc71' },
      2: { name: 'Intensity Focus',   nameTH: 'เพิ่ม Intensity',  volMod: 0.95, intMod: 0.90, color: '#f1c40f' },
      3: { name: 'Overreach',         nameTH: 'กดดันสูงสุด',       volMod: 1.15, intMod: 0.95, color: '#e67e22' },
      4: { name: 'Deload',            nameTH: 'Deload พัก',        volMod: 0.60, intMod: 0.65, color: '#e74c3c' },
    };

    return { ...phases[week], week };
  },

  _checkPeriodizationAdvance() {
    if (!this._a) return;
    const cycleStart = this._a.periodization.cycleStart || Date.now();
    const weeksElapsed = (Date.now() - cycleStart) / (7 * 24 * 3_600_000);
    const expectedWeek = Math.floor(weeksElapsed) + 1;

    if (expectedWeek > (this._a.periodization.week || 1)) {
      this._a.periodization.week = expectedWeek;

      const phase = this.getPeriodizationPhase();

      // Auto reset weekly sets at start of each week
      if (phase.week === 1 || expectedWeek % 1 === 0) {
        Object.keys(this._a.weeklySets).forEach(m => {
          this._a.weeklySets[m] = 0;
        });
      }

      // Deload week: apply volume reduction
      if (((expectedWeek - 1) % 4) === 3) {  // week 4 of cycle
        this._applyDeload(0.40);
        if (typeof showToast === 'function')
          showToast('🔄 Deload Week เริ่มต้น — Volume ลด 40%');
      }
    }
  },

  _applyDeload(reduction) {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return;
    Object.keys(this._a.weeklySets).forEach(m => {
      this._a.weeklySets[m] = Math.floor(this._a.weeklySets[m] * (1 - reduction));
    });
    Object.keys(OE.state.fatigue).forEach(m => {
      OE.state.fatigue[m] *= (1 - reduction * 0.5);
    });
    OE.calculateReadiness();
  },

  /* ----------------------------------------------------------
     PHYSICAL PROFILE ADAPTATION
     Slow-growing adaptation per stimulus
  ---------------------------------------------------------- */
  _adaptPhysicalProfile(muscle, SFR, volume) {
    if (!this._a?.physicalProfile?.[muscle]) return;
    const p = this._a.physicalProfile[muscle];

    // Slow adaptation: 1 session = tiny growth
    const stimBonus = Math.min(0.5, SFR * 0.1);

    // Hypertrophy peaks in 8-12 rep range → volume
    if (volume > 0) {
      p.hypertrophyAdaptation = Math.min(100, p.hypertrophyAdaptation + stimBonus * 0.4);
    }

    // Strength from high SFR (heavy compound)
    if (SFR > 1.3) {
      p.strengthAdaptation = Math.min(100, p.strengthAdaptation + stimBonus * 0.3);
    }

    // Neural from consistency
    const neural = this._a.neuralEfficiency[muscle] || 50;
    p.neuralAdaptation = Math.min(100, neural * 0.8);

    // Recovery speed improves with consistent training
    p.recoverySpeed = Math.min(100, p.recoverySpeed + 0.05);
  },

  /* ----------------------------------------------------------
     OPERATOR RATING (OR)  —  Composite Formula
     OR =
       (Strength Index    × 0.35)
     + (Work Capacity     × 0.25)
     + (Fatigue Mgmt      × 0.20)
     + (Consistency Score × 0.20)
  ---------------------------------------------------------- */
  calcOperatorRating() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE || !this._a) return { OR: 0, breakdown: {} };

    // Strength Index: avg e1RM progress across exercises
    const e1RMEntries = Object.values(this._a.e1RM);
    let strengthIndex = 50;  // base
    if (e1RMEntries.length > 0) {
      const gains = e1RMEntries.map(entries => {
        if (entries.length < 2) return 0;
        const first = entries[0].e1rm;
        const last  = entries[entries.length - 1].e1rm;
        return Math.max(0, (last - first) / first * 100);
      });
      const avgGain = gains.reduce((a, b) => a + b, 0) / gains.length;
      strengthIndex = Math.min(100, 50 + avgGain * 2);
    }

    // Work Capacity: total volume relative to expected
    const volScore = Math.min(100, (OE.state.totalVolume / 100_000) * 50);

    // Fatigue Management: how well readiness is maintained
    const recentReadiness = this._a.readinessHistory.slice(-7).map(r => r.value);
    const avgReadiness = recentReadiness.length > 0
      ? recentReadiness.reduce((a, b) => a + b, 0) / recentReadiness.length
      : OE.state.readiness;
    const fatigueScore = Math.min(100, avgReadiness);

    // Consistency: % workout days in last 30 days
    const consistencyPct = this._calcConsistency30Days();
    const consistencyScore = consistencyPct * 100;

    const OR = (
      (strengthIndex    * 0.35) +
      (volScore         * 0.25) +
      (fatigueScore     * 0.20) +
      (consistencyScore * 0.20)
    );

    return {
      OR:         Math.round(OR),
      breakdown: {
        strengthIndex:    Math.round(strengthIndex),
        workCapacity:     Math.round(volScore),
        fatigueManagement: Math.round(fatigueScore),
        consistency:      Math.round(consistencyScore),
        consistencyPct:   Math.round(consistencyPct * 100),
      },
    };
  },

  _calcConsistency30Days() {
    if (!this._a?.certification?.workoutDates) return 0;
    const thirtyDaysAgo = Date.now() - 30 * 86_400_000;
    const recentDates = this._a.certification.workoutDates
      .filter(d => {
        // FIX [High]: guard against invalid date strings → NaN from getTime()
        if (!d) return false;
        const t = new Date(d).getTime();
        return isFinite(t) && t > thirtyDaysAgo;
      });
    const uniqueDates = new Set(recentDates).size;
    return Math.min(1, uniqueDates / 20);  // 20 sessions/30 days = 100%
  },

  /* ----------------------------------------------------------
     CERTIFICATION GATE
     ต้องผ่าน:
       1. Strength threshold (e1RM progress ≥ 10%)
       2. Volume consistency (MAV zone ≥ 2 weeks)
       3. No overtraining flag
  ---------------------------------------------------------- */
  getCertificationStatus() {
    if (!this._a) return { eligible: false, requirements: [] };

    const { OR, breakdown } = this.calcOperatorRating();

    const e1RMOk = breakdown.strengthIndex >= 60;
    const volumeOk = this._a.certification.volumeWeeks >= 2;
    const noOT = !this._a.overtraining.forceDeload;
    const consistencyOk = breakdown.consistencyPct >= 70;

    const requirements = [
      { label: 'Strength Index ≥ 60',        met: e1RMOk,        value: breakdown.strengthIndex },
      { label: 'MAV Zone ≥ 2 สัปดาห์',       met: volumeOk,      value: this._a.certification.volumeWeeks + ' wk' },
      { label: 'ไม่มี Overtraining Flag',     met: noOT,          value: noOT ? '✅' : '🔴 flagged' },
      { label: 'Consistency ≥ 70%',           met: consistencyOk, value: breakdown.consistencyPct + '%' },
    ];

    return {
      eligible: requirements.every(r => r.met),
      requirements,
      OR,
    };
  },

  /* ----------------------------------------------------------
     SLEEP LOG
  ---------------------------------------------------------- */
  logSleep(hours, quality) {
    if (!this._a) return;
    // quality: 1-10 scale
    this._a.sleepLog.push({
      date:    new Date().toISOString().split('T')[0],
      hours:   Math.min(12, Math.max(0, hours || 7)),
      quality: Math.min(10, Math.max(1, quality || 7)),
    });
    if (this._a.sleepLog.length > 30)
      this._a.sleepLog = this._a.sleepLog.slice(-30);
    this._save();
  },

  _getLastSleepScore() {
    if (!this._a?.sleepLog?.length) return 7 * 7;  // default neutral
    const last = this._a.sleepLog[this._a.sleepLog.length - 1];
    return ((last.hours / 8) * 0.5 + (last.quality / 10) * 0.5) * 70;  // 0-70 range
  },

  /* ----------------------------------------------------------
     READINESS HISTORY TRACKING
  ---------------------------------------------------------- */
  _trackReadiness() {
    if (!this._a) return;
    const r = window.OPERATOR_ENGINE?.state?.readiness || 80;
    const today = new Date().toISOString().split('T')[0];

    const last = this._a.readinessHistory[this._a.readinessHistory.length - 1];
    if (last?.date === today) {
      last.value = r;
    } else {
      this._a.readinessHistory.push({ date: today, value: r, intensity: 0 });
    }

    if (this._a.readinessHistory.length > 30)
      this._a.readinessHistory = this._a.readinessHistory.slice(-30);
  },

  /* ----------------------------------------------------------
     COMBAT MODE READINESS ADJUSTMENT
     auto-adjust reps target ตาม readiness tier
  ---------------------------------------------------------- */
  adjustTargetReps(baseReps) {
    const label = this.getReadinessLabel();
    const mods  = { peak: 1.10, hard: 1.00, moderate: 0.90, light: 0.75, deload: 0.55 };
    const mod   = mods[label.tier] || 1.0;
    return Math.max(1, Math.round(baseReps * mod));
  },

  /* ----------------------------------------------------------
     WORKOUT HOOK — เรียกหลัง logWorkout ทุกครั้ง
  ---------------------------------------------------------- */
  onWorkoutLogged(exercises, grade = 'B') {
    if (!this._a) return;

    // Apply SFR-based fatigue
    this.applySFR(exercises);

    // Record grade for neural efficiency
    const allMuscles = [...new Set(
      exercises.flatMap(ex => {
        const p = this._getExerciseProfile((ex.name || '').toLowerCase());
        return p.muscles;
      })
    )];
    this.recordGrade(allMuscles, grade);

    // Update certification tracking
    const today = new Date().toISOString().split('T')[0];
    if (!this._a.certification.workoutDates.includes(today))
      this._a.certification.workoutDates.push(today);

    // Track MAV zone weeks
    const landmarks = this.analyzeVolumeLandmarks();
    const inMAV = Object.values(landmarks).filter(l => l.zone === 'mav').length;
    if (inMAV >= 3) this._a.certification.volumeWeeks++;

    // Update readiness intensity log
    const total = exercises.reduce((s, ex) => s + (Number(ex.sets) * Number(ex.reps) || 0), 0);
    const normalizedIntensity = Math.min(100, total / 2);
    if (this._a.readinessHistory.length > 0)
      this._a.readinessHistory[this._a.readinessHistory.length - 1].intensity = normalizedIntensity;

    this.calcAdvancedReadiness();
    this._save();
  },

  /* ----------------------------------------------------------
     HELPER — get exercise profile (fuzzy match)
  ---------------------------------------------------------- */
  _getExerciseProfile(name) {
    const n = (name || '').toLowerCase();

    // Direct match
    if (EXERCISE_PROFILES[n]) return EXERCISE_PROFILES[n];

    // Fuzzy match
    for (const [key, prof] of Object.entries(EXERCISE_PROFILES)) {
      if (n.includes(key) || key.includes(n)) return prof;
    }

    // Default: moderate compound
    return { stimulus: 1.0, fatigueCost: 0.8, muscles: ['core'], type: 'unknown' };
  },

  /* ----------------------------------------------------------
     SUMMARY — ทุกอย่างในที่เดียว
  ---------------------------------------------------------- */
  getSummary() {
    if (!this._a) return null;
    const OE     = window.OPERATOR_ENGINE;
    const phase  = this.getPeriodizationPhase();
    const rl     = this.getReadinessLabel();
    const { OR, breakdown } = this.calcOperatorRating();
    const cert   = this.getCertificationStatus();
    const vol    = this.analyzeVolumeLandmarks();

    return {
      readiness:     Math.round(this.calcAdvancedReadiness()),
      readinessLabel: rl,
      phase,
      OR, breakdown,
      certification: cert,
      volumeLandmarks: vol,
      forceDeload: this.isForceDeload(),
      neuralEfficiency: this._a.neuralEfficiency,
      physicalProfile:  this._a.physicalProfile,
      periodizationWeek: this._a.periodization.week,
    };
  },

  /* ----------------------------------------------------------
     INIT
  ---------------------------------------------------------- */
  init() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) {
      console.warn('[AscensionEngine] OPERATOR_ENGINE not found — retrying in 500ms');
      setTimeout(() => this.init(), 500);
      return;
    }

    this._initExtension();

    // Patch OPERATOR_ENGINE.logWorkout to call AscensionEngine.onWorkoutLogged
    if (!OE._ascensionPatched) {
      const originalLog = OE.logWorkout.bind(OE);
      OE.logWorkout = (exercises, grade) => {
        const result = originalLog(exercises);
        AscensionEngine.onWorkoutLogged(exercises, grade || 'B');
        return result;
      };
      OE._ascensionPatched = true;
    }

    // Patch getReadinessLabel to use advanced model
    OE.getReadinessLabel = () => AscensionEngine.getReadinessLabel();

    // Replace engine tick with Ascension tick
    if (window._ascensionTick) clearInterval(window._ascensionTick);
    window._ascensionTick = setInterval(() => {
      AscensionEngine.tick();
      if (typeof renderReadiness  === 'function') renderReadiness();
      if (typeof renderMuscleGrid === 'function') renderMuscleGrid();
    }, 3_600_000);

    // Initial tick
    this.tick();

    // Expose on OPERATOR_ENGINE for Combat Mode access
    OE.ascension         = this;
    OE.getAscensionSummary = () => this.getSummary();
    OE.adjustTargetReps    = (r) => this.adjustTargetReps(r);
    OE.logSleep            = (h, q) => this.logSleep(h, q);
    OE.getE1RMTrend        = (n) => this.getE1RMTrend(n);
    OE.calcOperatorRating  = () => this.calcOperatorRating();
    OE.getCertStatus       = () => this.getCertificationStatus();
    OE.getPeriodPhase      = () => this.getPeriodizationPhase();
    OE.analyzeVolume       = () => this.analyzeVolumeLandmarks();

    console.log(
      '%c[AscensionEngine ⚡ Realism Mode] Loaded',
      'color:#00ff88;font-weight:bold',
      `| OR: ${this.calcOperatorRating().OR} | Readiness: ${Math.round(this.calcAdvancedReadiness())}%`,
      `| Phase: Week ${this._a?.periodization?.week} ${this.getPeriodizationPhase().nameTH}`
    );
  },
};

window.AscensionEngine = AscensionEngine;

/* ============================================================
   AUTO-INIT — รอหลัง engine.js โหลดเสร็จ
   ============================================================ */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => AscensionEngine.init());
} else {
  // engine.js อาจยังไม่เสร็จ — ให้ init หลัง DOMContentLoaded + delay เล็กน้อย
  setTimeout(() => AscensionEngine.init(), 100);
}
