// ============================================================
// OPERATOR TRAINING SYSTEM — app.js (FIXED v4)
// Single unified source of truth for all data + AI logic
//
// FIXES v2:
//   [FIX-1] _guessMusclFromWorkoutType → _guessMuscleFromWorkoutType (เพิ่ม 'e')
//   [FIX-2] XP ใน saveWorkout: Engine.logWorkout() จัดการ XP แล้ว
//   [FIX-3] fitness key: getProfile/saveProfile ถูกต้องแล้ว
//
// FIXES v3 (new):
//   [FIX-5] saveWorkout: dbAdd wrapped in try/catch — ป้องกัน crash ถ้า IDB fail
//   [FIX-6] Optional chaining (?.) บน unsafe function calls ทุกจุด
//
// FIXES v4 (hotfix):
//   [HF-1] MutationObserver → loadSettingsUI debounced + state guard
//          ป้องกัน loop: observer fire → loadSettingsUI → classList → observer fire
//   [HF-3] _recoveryInterval ลบทิ้ง — ซ้ำกับ _engineTick ใน engine.js
//          engine.js จัดการ hourly tick อยู่แล้ว ไม่ต้องมี 2 ตัว
// ============================================================
'use strict';

// ─────────────────────────────────────────────
// INDEXEDDB
// ─────────────────────────────────────────────
let db;
const DB_NAME = 'OperatorDB', DB_VER = 1;

function initDB() {
  return new Promise((res, rej) => {
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = e => {
      const d = e.target.result;
      ['workouts','weights','tests'].forEach(s => {
        if (!d.objectStoreNames.contains(s))
          d.createObjectStore(s, { keyPath:'id', autoIncrement:true });
      });
    };
    req.onsuccess = e => { db = e.target.result; res(); };
    req.onerror   = rej;
  });
}
const dbAdd    = (store, data) => new Promise((res,rej)=>{ const t=db.transaction(store,'readwrite'); const r=t.objectStore(store).add(data); r.onsuccess=()=>res(r.result); r.onerror=rej; });
const dbGetAll = (store)       => new Promise((res,rej)=>{ const t=db.transaction(store,'readonly');  const r=t.objectStore(store).getAll();  r.onsuccess=()=>res(r.result); r.onerror=rej; });

// ─────────────────────────────────────────────
// STORAGE — unified read/write layer
// ─────────────────────────────────────────────
const LS = {
  get: (k, def=null) => { try { const v=localStorage.getItem(k); return v!==null ? JSON.parse(v) : def; } catch { return def; } },
  set: (k, v)        => localStorage.setItem(k, JSON.stringify(v)),
  raw: (k, def='')   => localStorage.getItem(k) ?? def,
  setRaw: (k, v)     => localStorage.setItem(k, v)
};

// ─────────────────────────────────────────────
// PROFILE
// ─────────────────────────────────────────────
function getProfile() {
  const p = LS.get('profile', {});
  return {
    name:        p.name        || LS.raw('name',        'Operator'),
    age:         p.age         || LS.raw('age',         ''),
    height:      p.height      || LS.raw('height',      ''),
    weight:      p.weight      || LS.raw('weight',      ''),
    fitness:     p.fitness     || LS.raw('fitness_level','beginner'),
    goal:        p.goal        || LS.raw('goal',        'fat_loss'),
    startDate:   p.startDate   || null,
    startWeight: p.startWeight || p.weight || LS.raw('weight',''),
  };
}

function saveProfile(updates) {
  const current = LS.get('profile', {});
  const merged  = { ...current, ...updates };
  LS.set('profile', merged);
  ['name','age','height','weight','fitness','goal'].forEach(k => {
    if (merged[k] !== undefined) LS.setRaw(k === 'fitness' ? 'fitness_level' : k, String(merged[k]));
  });
}

const getCustomGoal    = () => LS.raw('custom_goal', '');
const setCustomGoal    = v  => { LS.setRaw('custom_goal', v); LS.set('custom_goal', v); };

function getEquipment() {
  try { return JSON.parse(localStorage.getItem('equipment')) || []; } catch { return []; }
}
function setEquipment(arr) {
  localStorage.setItem('equipment', JSON.stringify(arr));
  LS.set('equipment', arr);
}

const getTrainLocation = () => LS.raw('train_location', 'บ้าน');
const setTrainLocation = v  => { LS.setRaw('train_location', v); LS.set('train_location', v); };

const getProvider = () => localStorage.getItem('ai_provider') || 'openai';
const setProvider = v  => { localStorage.setItem('ai_provider', v); LS.set('aiProvider', v); };

const getOpenAIKey = () => [
  'openai_api_key', 'openai_key', 'apiKey', 'openaiKey'
].map(k => (localStorage.getItem(k)||'').trim()).find(v => v.length > 10) || '';

const getGeminiKey = () => [
  'gemini_api_key', 'gemini_key', 'geminiKey', 'gemini'
].map(k => (localStorage.getItem(k)||'').trim()).find(v => v.length > 10) || '';

function getActiveKey() {
  return getProvider() === 'gemini' ? getGeminiKey() : getOpenAIKey();
}

window.debugKeys = () => {
  const p = getProvider();
  const k = getActiveKey();
  console.table({
    provider: p,
    openai_key: getOpenAIKey().slice(0,8)+'…' || '(none)',
    gemini_key: getGeminiKey().slice(0,8)+'…' || '(none)',
    active_key_length: k.length,
    active_key_valid: k.length > 10,
  });
  return `Provider: ${p} | Key valid: ${k.length > 10}`;
};

// ─────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────
const RANKS = [
  { name:'Recruit',       emoji:'🪖', xp:0     },
  { name:'Cadet',         emoji:'🎖️', xp:500   },
  { name:'Operator',      emoji:'⚔️', xp:1200  },
  { name:'Assault',       emoji:'🛡️', xp:2500  },
  { name:'Recon',         emoji:'🎯', xp:4500  },
  { name:'Ghost',         emoji:'👻', xp:7500  },
  { name:'Special Forces',emoji:'⭐', xp:12000 },
];
const FITNESS_LABELS = { beginner:'มือใหม่', intermediate:'ปานกลาง', advanced:'ขั้นสูง' };
const GOAL_LABELS    = { fat_loss:'ลดไขมัน', muscle:'เพิ่มกล้าม', military:'สอบทหาร', general:'ฟิตทั่วไป' };
const DAYS_TH        = ['อา','จ','อ','พ','พฤ','ศ','ส'];
const WORKOUT_TYPES  = { push:'Push Day', pull:'Pull Day', run:'Run Day', core:'Core Day', fullbody:'Full Body', cardio:'Cardio', recovery:'Recovery' };
const EXERCISES      = ['Pushups','Pullups','Situps','Squats','Burpees','Plank','Running','Walking','Dead hang','Negative pullups','Scapula pullups','Leg raises','Russian twist','Sprint intervals','Dips','Mountain climbers'];

// ─────────────────────────────────────────────
// RANK HELPERS
// ─────────────────────────────────────────────
const getRank     = xp => { let r=RANKS[0]; for(const x of RANKS) if(xp>=x.xp) r=x; return r; };
const getNextRank = xp => RANKS.find(r => xp < r.xp) || null;

// ─────────────────────────────────────────────
// PHASE
// ─────────────────────────────────────────────
function getPhase(profile) {
  if (!profile?.startDate) return { phase:1, week:1, totalWeeks:16, name:'Phase 1 – Base Building', icon:'🏗️', fill:0 };
  const weeks = Math.floor((Date.now() - profile.startDate) / (7*24*60*60*1000));
  if (weeks < 16)  return { phase:1, week:weeks+1,  totalWeeks:16, name:'Phase 1 – Base Building',       icon:'🏗️', fill:((weeks+1)/16)*100 };
  if (weeks < 32)  return { phase:2, week:weeks-15, totalWeeks:16, name:'Phase 2 – Strength Development', icon:'⚔️', fill:((weeks-15)/16)*100 };
  return              { phase:3, week:weeks-31, totalWeeks:20, name:'Phase 3 – Peak Operator',        icon:'🎖️', fill:Math.min(((weeks-31)/20)*100,100) };
}

// ─────────────────────────────────────────────
// DAILY RESET
// ─────────────────────────────────────────────
function checkDailyReset() {
  const today = new Date().toDateString();
  if (LS.get('lastReset') !== today) {
    LS.set('gtg', 0);
    LS.set('missionsCompleted', {});
    LS.set('missionXpToday', 0);
    LS.set('lastReset', today);
  }
}

// ─────────────────────────────────────────────
// MISSIONS TEMPLATE
// ─────────────────────────────────────────────
function getMissionsTemplate(profile) {
  const protein = Math.round((parseFloat(profile.weight) || 90) * 1.8);
  return [
    { id:'m1', name:'Pushups 100 ครั้ง',        xp:5, icon:'💪' },
    { id:'m2', name:'GTG Pullup 50 ครั้ง',       xp:5, icon:'🔝' },
    { id:'m3', name:'เดิน/วิ่ง 5 กม.',           xp:5, icon:'🏃' },
    { id:'m4', name:'ดื่มน้ำ 3 ลิตร',            xp:5, icon:'💧' },
    { id:'m5', name:`กินโปรตีน ${protein} กรัม`, xp:5, icon:'🥩' },
    { id:'m6', name:'Situps 100 ครั้ง',          xp:5, icon:'🏋️' },
  ];
}

// ─────────────────────────────────────────────
// VALIDATION
// ─────────────────────────────────────────────
function validateWorkoutInput(sets, reps, weight) {
  const s = Number(sets)   || 0;
  const r = Number(reps)   || 0;
  const w = Number(weight) || 0;
  if (s < 1 || s > 10)   return false;
  if (r < 1 || r > 100)  return false;
  if (w < 0 || w > 500)  return false;
  return true;
}

function completeWorkout(exercises) {
  if (!exercises || exercises.length === 0) return { xpGained: 0 };
  let totalVolume = 0;
  exercises.forEach(ex => {
    const sets   = Number(ex.sets)   || 1;
    const reps   = Number(ex.reps)   || 10;
    const weight = Number(ex.weight) || 1;
    totalVolume += sets * reps * weight;
  });
  const xpGained = Math.max(5, Math.floor(totalVolume / 100));
  return { xpGained, totalVolume };
}

// ─────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────
async function init() {
  await initDB();
  checkDailyReset();
  const profile = LS.get('profile');
  if (typeof FitnessEngine !== 'undefined') {
    FitnessEngine.init(profile || {});
  }

  // ── v2 Multi-Profile Mode ──────────────────────────────
  // If ProfileManager is loaded, the window.load handler in index.html
  // takes full ownership of routing (splash → profile select → app).
  // init() should NOT touch splash/screen routing in that case.
  if (typeof ProfileManager !== 'undefined') {
    // Only init engine state — ProfileUI handles screen flow
    if (profile || ProfileManager.hasActiveProfile()) {
      // Engine warm-up only, no screen changes
      if (typeof Engine !== 'undefined') Engine.init?.();
    }
    return;
  }

  // ── Legacy single-profile fallback ────────────────────
  setTimeout(() => {
    const splash     = document.getElementById('splash-screen');
    const onboarding = document.getElementById('onboarding-screen');
    const main       = document.getElementById('main-app');
    if (splash) splash.classList.add('hidden');
    if (!profile) {
      if (onboarding) onboarding.classList.remove('hidden');
    } else {
      if (main) main.classList.remove('hidden');
      loadApp();
    }
  }, 2000);
}

// ─────────────────────────────────────────────
// ONBOARDING
// ─────────────────────────────────────────────
function saveOnboarding() {
  const nameEl = document.getElementById('ob-name');
  const ageEl  = document.getElementById('ob-age');
  const htEl   = document.getElementById('ob-height');
  const wtEl   = document.getElementById('ob-weight');
  if (!nameEl || !ageEl || !htEl || !wtEl) { console.error('Missing onboarding form elements'); return; }

  const name   = nameEl.value.trim() || 'Operator';
  const ageRaw = parseInt(ageEl.value);
  const htRaw  = parseInt(htEl.value);
  const wtRaw  = parseFloat(wtEl.value);

  const errors = [];
  if (isNaN(ageRaw) || ageRaw < 10  || ageRaw > 80)  errors.push('อายุต้องอยู่ระหว่าง 10–80 ปี');
  if (isNaN(htRaw)  || htRaw  < 100 || htRaw  > 250) errors.push('ส่วนสูงต้องอยู่ระหว่าง 100–250 ซม.');
  if (isNaN(wtRaw)  || wtRaw  < 30  || wtRaw  > 300) errors.push('น้ำหนักต้องอยู่ระหว่าง 30–300 กก.');
  if (errors.length) { alert('⚠️ ' + errors.join('\n')); return; }

  const fitEl   = document.querySelector('input[name="fitness"]:checked');
  const goalEl  = document.querySelector('input[name="goal"]:checked');
  const fitness = fitEl?.value  || 'beginner';
  const goal    = goalEl?.value || 'fat_loss';

  saveProfile({ name, age:ageRaw, height:htRaw, weight:wtRaw, fitness, goal, startDate:Date.now(), startWeight:wtRaw });
  LS.set('xp', 0); LS.set('streak', 0); LS.set('lastWorkoutDate', null);
  dbAdd('weights', { date:new Date().toISOString().split('T')[0], weight:wtRaw }).catch(()=>{});

  const onboarding = document.getElementById('onboarding-screen');
  const main       = document.getElementById('main-app');
  if (onboarding) onboarding.classList.add('hidden');
  if (main) main.classList.remove('hidden');

  generateLocalProgram(true);
  if (typeof FitnessEngine !== 'undefined') FitnessEngine.init(getProfile());
  loadApp();
  showToast('🎉 ยินดีต้อนรับสู่ระบบฝึก Operator!');
}

// ─────────────────────────────────────────────
// LOAD APP
// ─────────────────────────────────────────────
function loadApp() {
  renderTopBar();
  renderDashboard();
  renderMissions();
  restoreOrRenderProgram();
  renderWorkoutHistory();
  renderProgress();
  renderStats();
  loadSettingsUI();
  if (typeof initEngine === 'function') initEngine();
}

// ─────────────────────────────────────────────
// TOP BAR
// ─────────────────────────────────────────────
function renderTopBar() {
  const xp      = LS.get('xp', 0);
  const profile = getProfile();
  const rank    = getRank(xp);
  const oeRank   = window.OPERATOR_ENGINE ? OPERATOR_ENGINE.getRank()          : null;
  const oeStreak = window.OPERATOR_ENGINE ? OPERATOR_ENGINE.state.streak       : LS.get('streak', 0);
  const oeXP     = window.OPERATOR_ENGINE ? OPERATOR_ENGINE.state.xp           : xp;

  const nameEl   = document.getElementById('top-name');
  const rankEl   = document.getElementById('top-rank');
  const badgeEl  = document.getElementById('rank-badge');
  const xpEl     = document.getElementById('xp-count');
  const streakEl = document.getElementById('streak-count');

  if (nameEl)   nameEl.textContent   = profile.name;
  if (rankEl)   rankEl.textContent   = oeRank ? oeRank.name  : rank.name;
  if (badgeEl)  badgeEl.textContent  = oeRank ? oeRank.emoji : rank.emoji;
  if (xpEl)     xpEl.textContent     = oeXP;
  if (streakEl) streakEl.textContent = oeStreak;

  if (window.OPERATOR_ENGINE && OPERATOR_ENGINE.state && OPERATOR_ENGINE.getRank) {
    try {
      LS.set('streak', OPERATOR_ENGINE.state.streak || 0);
      LS.set('oe_rank_tier', OPERATOR_ENGINE.getRank().tier || 0);
    } catch (e) { console.error('renderTopBar Engine sync error:', e); }
  }
}

// ─────────────────────────────────────────────
// XP
// ─────────────────────────────────────────────
function addXP(amount) {
  const prev = LS.get('xp', 0);
  const next = prev + amount;
  LS.set('xp', next);
  if (getRank(next).name !== getRank(prev).name)
    showToast(`🎖️ เลื่อนยศเป็น ${getRank(next).emoji} ${getRank(next).name}!`);
  renderTopBar();
  const el = document.getElementById('xp-current');
  if (el) el.textContent = next;
}

// ─────────────────────────────────────────────
// DASHBOARD
// ─────────────────────────────────────────────
function renderDashboard() {
  const profile   = getProfile();
  const xp        = LS.get('xp', 0);
  const gtg       = LS.get('gtg', 0);
  const phaseInfo = getPhase(profile);

  const phaseBanner = document.getElementById('phase-banner');
  if (phaseBanner) {
    const nameEl = phaseBanner.querySelector('.phase-name');
    const iconEl = phaseBanner.querySelector('.phase-icon');
    const weekEl = phaseBanner.querySelector('.phase-week');
    if (nameEl) nameEl.textContent = phaseInfo.name;
    if (iconEl) iconEl.textContent = phaseInfo.icon;
    if (weekEl) weekEl.textContent = `สัปดาห์ที่ ${phaseInfo.week} / ${phaseInfo.totalWeeks}`;
  }
  const phaseFill = document.getElementById('phase-fill');
  if (phaseFill) phaseFill.style.width = phaseInfo.fill + '%';

  const rank  = getRank(xp);
  const nextR = getNextRank(xp);
  const xpCurrentEl = document.getElementById('xp-current');
  const xpBarFill   = document.getElementById('xp-bar-fill');
  const xpNextEl    = document.getElementById('xp-next');
  if (xpCurrentEl) xpCurrentEl.textContent = xp;
  if (nextR) {
    if (xpBarFill) xpBarFill.style.width = ((xp - rank.xp) / (nextR.xp - rank.xp) * 100) + '%';
    if (xpNextEl)  xpNextEl.textContent  = nextR.xp;
  } else {
    if (xpBarFill) xpBarFill.style.width = '100%';
    if (xpNextEl)  xpNextEl.textContent  = 'MAX';
  }

  const gtgCountEl = document.getElementById('gtg-count');
  const gtgBarEl   = document.getElementById('gtg-bar-fill');
  if (gtgCountEl) gtgCountEl.textContent = gtg;
  if (gtgBarEl)   gtgBarEl.style.width   = Math.min(gtg/50*100,100) + '%';

  renderMissionPreview();

  dbGetAll('weights').then(records => {
    const dashWeightEl = document.getElementById('dash-weight');
    const weightLostEl = document.getElementById('weight-lost');
    if (!records.length) { if (dashWeightEl) dashWeightEl.textContent = profile.weight||'--'; return; }
    const sorted = records.sort((a,b)=>a.date.localeCompare(b.date));
    const latest = sorted[sorted.length-1].weight;
    const start  = parseFloat(profile.startWeight) || sorted[0].weight;
    if (dashWeightEl) dashWeightEl.textContent = latest;
    if (weightLostEl) weightLostEl.textContent = Math.max(0, start-latest).toFixed(1);
    drawMiniChart(sorted.map(r=>r.weight));
  }).catch(e => console.error('Weight fetch error:', e));

  renderWeekGrid();
}

// ─────────────────────────────────────────────
// MISSIONS
// ─────────────────────────────────────────────
function renderMissionPreview() {
  const done     = LS.get('missionsCompleted', {});
  const missions = getMissionsTemplate(getProfile()).slice(0,3);
  const container = document.getElementById('daily-missions-preview');
  if (!container) return;
  container.innerHTML = missions.map(m=>`
    <div class="mission-item ${done[m.id]?'done':''}" onclick="toggleMission('${m.id}')">
      <div class="mission-check">${done[m.id]?'✓':''}</div>
      <div class="mission-info"><div class="mission-name">${m.icon} ${m.name}</div><div class="mission-xp">+${m.xp} XP</div></div>
    </div>`).join('');
}

function renderMissions() {
  const done     = LS.get('missionsCompleted', {});
  const missions = getMissionsTemplate(getProfile());
  const xpToday  = LS.get('missionXpToday', 0);
  const el = document.getElementById('mission-xp-today');
  if (el) el.textContent = xpToday;
  const allMissionsEl = document.getElementById('all-missions');
  if (allMissionsEl) {
    allMissionsEl.innerHTML = missions.map(m=>`
      <div class="mission-item ${done[m.id]?'done':''}" onclick="toggleMission('${m.id}')">
        <div class="mission-check">${done[m.id]?'✓':''}</div>
        <div class="mission-info"><div class="mission-name">${m.icon} ${m.name}</div><div class="mission-xp">+${m.xp} XP</div></div>
      </div>`).join('');
  }
  const gtg = LS.get('gtg',0);
  ['gtg-count2','gtg-bar-fill2'].forEach(id=>{
    const e=document.getElementById(id); if(!e) return;
    if(id.includes('count')) e.textContent=gtg;
    else e.style.width=Math.min(gtg/50*100,100)+'%';
  });
}

function toggleMission(id) {
  const done     = LS.get('missionsCompleted', {});
  const missions = getMissionsTemplate(getProfile());
  const mission  = missions.find(m=>m.id===id);
  if (!mission) return;
  if (!done[id]) {
    done[id] = true;
    LS.set('missionsCompleted', done);
    addXP(mission.xp);
    LS.set('missionXpToday', (LS.get('missionXpToday',0) + mission.xp));
    showToast(`✅ ภารกิจสำเร็จ! +${mission.xp} XP`);
  } else {
    done[id] = false;
    LS.set('missionsCompleted', done);
  }
  renderMissions(); renderMissionPreview();
}

// ─────────────────────────────────────────────
// GTG
// ─────────────────────────────────────────────
function addGTG(n) {
  let gtg = Math.min(LS.get('gtg',0) + n, 200);
  LS.set('gtg', gtg);
  ['gtg-count','gtg-count2'].forEach(id=>{const e=document.getElementById(id);if(e)e.textContent=gtg;});
  ['gtg-bar-fill','gtg-bar-fill2'].forEach(id=>{const e=document.getElementById(id);if(e)e.style.width=Math.min(gtg/50*100,100)+'%';});
  addXP(2);
  if (gtg >= 50 && (gtg-n) < 50) showToast('🎉 GTG เป้าหมาย 50 สำเร็จ!');
}

// ─────────────────────────────────────────────
// WEEK GRID
// ─────────────────────────────────────────────
function renderWeekGrid() {
  const today   = new Date();
  const dow     = today.getDay();
  const trained = LS.get('trainedDays', {});
  const program = LS.get('program', null);
  let html = '';
  for (let i=0; i<7; i++) {
    const d   = new Date(today); d.setDate(today.getDate()-dow+i);
    const key = d.toISOString().split('T')[0];
    const isToday = i===dow, isDone = !!trained[key];
    const emoji   = isDone ? '✅' : isToday ? '🔥' : (program?.days?.[i]?.emoji || '○');
    html += `<div class="week-day ${isToday?'today':''} ${isDone?'done':''}">
      <div class="week-day-label">${DAYS_TH[i]}</div>
      <div class="week-day-icon">${emoji}</div></div>`;
  }
  const weekGridEl = document.getElementById('week-grid');
  if (weekGridEl) weekGridEl.innerHTML = html;
}

// ─────────────────────────────────────────────
// PROGRAM
// ─────────────────────────────────────────────
function generateProgram(silent=false) { generateLocalProgram(silent); }

function generateLocalProgram(silent=false) {
  const profile = getProfile();
  const phase   = getPhase(profile);
  const program = buildLocalProgram(profile, phase);
  LS.set('program', program);
  const aiSaved = localStorage.getItem('weekly_program');
  if (aiSaved && !silent) renderAIProgramResult(aiSaved);
  else renderProgram();
  if (!silent) showToast('📋 สร้างตารางฝึกใหม่แล้ว!');
}

function restoreOrRenderProgram() {
  const aiSaved = localStorage.getItem('weekly_program');
  if (aiSaved) renderAIProgramResult(aiSaved);
  else renderProgram();
}

function buildLocalProgram(profile, phase) {
  const f = profile.fitness || 'beginner';
  const p = phase.phase;
  const dayDefs = [
    { day:'วันจันทร์',   dayShort:'จ',  emoji:'💪', type:'Push Day',  focus:'Pushups + Core',          exercises:getPushDay(f,p)    },
    { day:'วันอังคาร',   dayShort:'อ',  emoji:'🔝', type:'Pull Day',  focus:'Pullup Progression',       exercises:getPullDay(f,p)    },
    { day:'วันพุธ',      dayShort:'พ',  emoji:'🏃', type:'Run Day',   focus:'Running + Cardio',          exercises:getRunDay(f,p)     },
    { day:'วันพฤหัสบดี', dayShort:'พฤ', emoji:'🎯', type:'Core Day',  focus:'Core + Mobility',          exercises:getCoreDay(f,p)    },
    { day:'วันศุกร์',    dayShort:'ศ',  emoji:'🔥', type:'Full Body', focus:'Full Body Circuit',         exercises:getFullBodyDay(f,p) },
    { day:'วันเสาร์',    dayShort:'ส',  emoji:'❤️', type:'Cardio',   focus:'Long Run / Walk',           exercises:getCardioDay(f,p)  },
    { day:'วันอาทิตย์',  dayShort:'อา', emoji:'💤', type:'Recovery', focus:'พัก / Stretch / Mobility',  exercises:getRecoveryDay()   },
  ];
  if (p === 1) dayDefs[1] = { ...dayDefs[1], type:'Core Day', focus:'Core + Mobility', exercises:getCoreDay(f,1) };
  return { phase:p, phaseName:phase.name, days:dayDefs, generatedAt:Date.now(), fitness:f, goal:profile.goal };
}

const M = { beginner:1, intermediate:1.5, advanced:2 };
function getPushDay(f,p){ const m=M[f]||1; return [
  {name:'Pushups',        sets:2+p, reps:`${Math.round(10*m*p)} ครั้ง`, rest:'60s'},
  {name:'Diamond Pushups',sets:3,   reps:`${Math.round(8*m)} ครั้ง`,   rest:'60s'},
  {name:'Wide Pushups',   sets:3,   reps:`${Math.round(10*m)} ครั้ง`,  rest:'60s'},
  {name:'Plank',          sets:3,   reps:`${20+15*p} วินาที`,           rest:'45s'},
];}
function getPullDay(f,p){ const adv=f==='advanced', mid=f==='intermediate'; if(p===1) return [
  {name:'Dead Hang',       sets:3, reps:'20 วินาที', rest:'90s'},
  {name:'Scapula Pullups', sets:3, reps:'10 ครั้ง',  rest:'60s'},
  {name:'Negative Pullups',sets:3, reps:'5 ครั้ง',   rest:'90s'},
]; if(p===2) return [
  {name:'Pullups',         sets:5, reps:adv?'8-10':mid?'5-7':'3-5', rest:'90s'},
  {name:'Dead Hang',       sets:3, reps:'45 วินาที', rest:'60s'},
  {name:'Negative Pullups',sets:3, reps:'6 ครั้ง',   rest:'90s'},
]; return [
  {name:'Pullups Max',     sets:5, reps:'ทำได้สูงสุด', rest:'2 นาที'},
  {name:'Leg Raises (bar)',sets:3, reps:'12 ครั้ง',    rest:'60s'},
  {name:'Dead Hang',       sets:3, reps:'60 วินาที',   rest:'60s'},
];}
function getRunDay(f,p){ const labels={1:{beginner:'เดินเร็ว 5 กม.',intermediate:'วิ่งช้า 5 กม.',advanced:'Tempo 6 กม.'},2:{beginner:'4×400m',intermediate:'5×400m',advanced:'8×400m'},3:{beginner:'1.6กม. Max',intermediate:'3กม.+Sprint',advanced:'5กม. Tempo'}}; return [
  {name:'Warmup Walk',           sets:1,   reps:'10 นาที',              rest:'–'},
  {name:labels[p][f]||'วิ่ง/เดิน',sets:1, reps:'ตามแผน',              rest:'–'},
  {name:'Sprint Intervals',      sets:p*3, reps:'30s sprint/90s เดิน', rest:'–'},
  {name:'Cooldown Stretch',      sets:1,   reps:'10 นาที',              rest:'–'},
];}
function getCoreDay(f,p){ const m=M[f]||1; return [
  {name:'Situps',           sets:4, reps:`${Math.round(20*p*m)} ครั้ง`, rest:'45s'},
  {name:'Leg Raises',       sets:3, reps:`${Math.round(12*p)} ครั้ง`,   rest:'45s'},
  {name:'Russian Twist',    sets:3, reps:`${Math.round(20*p)} ครั้ง`,   rest:'45s'},
  {name:'Plank',            sets:3, reps:`${30+15*p} วินาที`,            rest:'30s'},
  {name:'Mountain Climbers',sets:3, reps:`${Math.round(20*p)} ครั้ง`,   rest:'45s'},
];}
function getFullBodyDay(f,p){ const m=M[f]||1; return [
  {name:'Burpees', sets:p+2, reps:`${Math.round(10*m)} ครั้ง`, rest:'60s'},
  {name:'Pushups', sets:3,   reps:`${Math.round(15*m)} ครั้ง`, rest:'45s'},
  {name:'Squats',  sets:3,   reps:`${Math.round(20*m)} ครั้ง`, rest:'45s'},
  {name:'Situps',  sets:3,   reps:`${Math.round(20*m)} ครั้ง`, rest:'45s'},
  {name:'Pullups', sets:p,   reps:'ทำได้สูงสุด',               rest:'90s'},
];}
function getCardioDay(f,p){ return [
  {name:'Warmup',    sets:1,   reps:'10 นาที',         rest:'–'},
  {name:'Run / Walk',sets:1,   reps:`${20+p*10} นาที`, rest:'–'},
  {name:'Sprint',    sets:p*3, reps:'200m',             rest:'1 นาที'},
  {name:'Cooldown',  sets:1,   reps:'10 นาที',         rest:'–'},
];}
function getRecoveryDay(){ return [
  {name:'Stretching',  sets:1, reps:'15 นาที',    rest:'–'},
  {name:'Walking',     sets:1, reps:'20-30 นาที', rest:'–'},
  {name:'Foam Rolling',sets:1, reps:'10 นาที',    rest:'–'},
  {name:'Dead Hang',   sets:2, reps:'20 วินาที',  rest:'60s'},
];}

function renderProgram() {
  const program   = LS.get('program');
  const container = document.getElementById('program-content');
  if (!container) return;
  if (!program) { container.innerHTML='<div style="text-align:center;padding:40px;color:#9a9a9a">กด 🔄 หรือ ✨ เพื่อสร้างตารางฝึก</div>'; return; }
  const colors = {1:'#4a8a2a',2:'#2a6a8a',3:'#8a2a2a'};
  let html = `<div class="program-phase-header" style="border-left:4px solid ${colors[program.phase]||'#78cc55'}">
    <div class="program-phase-title">${program.phaseName}</div>
    <div class="program-phase-sub">${FITNESS_LABELS[program.fitness]||''} · ${GOAL_LABELS[program.goal]||''}</div></div>`;
  for (const day of program.days) {
    html += `<div class="program-day-card">
      <div class="program-day-header"><div class="program-day-name">${day.emoji} ${day.day}</div><div class="program-day-type">${day.type}</div></div>
      <div class="program-exercises"><div style="font-size:12px;color:#9a9a9a;margin-bottom:8px">${day.focus}</div>
      ${day.exercises.map((ex,i)=>`<div class="program-ex-item"><div class="program-ex-num">${i+1}</div>
        <div><div class="program-ex-name">${ex.name}</div>
        <div class="program-ex-detail">${ex.sets} เซต × ${ex.reps} · พัก ${ex.rest}</div></div></div>`).join('')}
      </div></div>`;
  }
  container.innerHTML = html;
}

// ─────────────────────────────────────────────
// AI PROGRAM GENERATOR
// ─────────────────────────────────────────────
function buildProgramPrompt(customGoalOverride) {
  const profile   = getProfile();
  const phase     = getPhase(profile);
  const equipment = getEquipment();
  const location  = getTrainLocation();
  const goal      = customGoalOverride || getCustomGoal() || GOAL_LABELS[profile.goal] || 'ฟิตทั่วไป';
  const fitnessLbl= FITNESS_LABELS[profile.fitness] || profile.fitness || 'มือใหม่';
  const eqList    = equipment.length > 0 ? equipment.join(', ') : 'ไม่มีอุปกรณ์ (Bodyweight เท่านั้น)';
  const eqRule    = (equipment.length === 0 || equipment.some(e=>e.includes('ไม่มีอุปกรณ์')))
    ? '⚠️ ใช้ Bodyweight เท่านั้น ห้ามใช้อุปกรณ์ใดๆ'
    : `✅ ใช้เฉพาะอุปกรณ์ที่ผู้ใช้มี: ${eqList} — ห้ามแนะนำท่าที่ต้องการอุปกรณ์อื่น`;
  return `คุณคือโค้ชฟิตเนสแนวหน่วยรบพิเศษ สร้างตารางฝึก 7 วันแบบ Periodization

━━ ข้อมูลผู้ฝึก ━━
ชื่อ: ${profile.name}
อายุ: ${profile.age} ปี  |  ส่วนสูง: ${profile.height} ซม.  |  น้ำหนัก: ${profile.weight} กก.
ระดับความฟิต: ${fitnessLbl}
Phase ปัจจุบัน: ${phase.name}

━━ สภาพแวดล้อม ━━
สถานที่ฝึก: ${location}
อุปกรณ์ที่มี: ${eqList}

━━ เป้าหมายของผู้ใช้ ━━
${goal}

━━ กฎการสร้างโปรแกรม (สำคัญมาก) ━━
${eqRule}
- ระบุ sets × reps หรือเวลา ให้ชัดเจนทุกท่า
- มีวันพักหรือ Active Recovery อย่างน้อย 1 วัน
- ปรับ Volume / Intensity ตามระดับ "${fitnessLbl}"
- โครงสร้างสัปดาห์: Push / Pull / Cardio / Core / Full Body / Cardio / Recovery
- ช่วยผู้ใช้เข้าใกล้เป้าหมายที่ระบุ

━━ รูปแบบคำตอบ (ครบ 7 วัน) ━━
**Day 1 – วันจันทร์ – Push Day**
• ชื่อท่า  3×15
• ชื่อท่า  3×12
...

**Day 2 – วันอังคาร – Pull Day**
...

(ทำต่อจนครบ Day 7)`;
}

function buildSystemPrompt() {
  const profile   = getProfile();
  const xp        = LS.get('xp', 0);
  const rank      = getRank(xp);
  const phase     = getPhase(profile);
  const goal      = getCustomGoal() || GOAL_LABELS[profile.goal] || '';
  const equipment = getEquipment();
  const location  = getTrainLocation();
  const eqLine    = equipment.length > 0 ? equipment.join(', ') : 'Bodyweight เท่านั้น';
  return `คุณคือโค้ช AI ฟิตเนสแนวหน่วยรบพิเศษ (Operator Training System)
ผู้ฝึก: ${profile.name} | อายุ ${profile.age} | น้ำหนัก ${profile.weight} กก. | ส่วนสูง ${profile.height} ซม.
ระดับ: ${FITNESS_LABELS[profile.fitness]||profile.fitness} | ยศ: ${rank.name} | ${phase.name}
สถานที่: ${location} | อุปกรณ์: ${eqLine}
เป้าหมาย: ${goal}
ตอบภาษาไทย กระชับ ให้กำลังใจ เน้นปฏิบัติ ใช้ emoji อ่านง่าย
เมื่อแนะนำท่า ให้เลือกเฉพาะท่าที่ใช้กับ "${eqLine}" ได้เท่านั้น`;
}

// [AI SYSTEM PACK] generateAIProgram ถูกจัดการโดย ai_hybrid_engine.js ทั้งหมด
// ใช้ late-binding stub เพื่อไม่ให้ function declaration นี้ overwrite
// window.generateAIProgram ที่ ai_hybrid_engine.js set ไว้
// (defer scripts รันตามลำดับ: ai_hybrid_engine.js → app_patches.js → app.js
//  function declaration ใน global scope = window property → จะ overwrite ถ้าไม่ระวัง)
// วิธีแก้: ใช้ function ที่ไม่ override แต่เรียก hybrid ผ่าน window ตอน runtime

function generateAIProgram() {
  // Delegate ไปยัง hybrid engine ที่โหลดหลังสุด
  if (typeof window._hybridGenerateAIProgram === 'function') {
    return window._hybridGenerateAIProgram();
  }
  // Fallback ถ้า hybrid ไม่โหลด → local program
  if (typeof generateLocalProgram === 'function') generateLocalProgram();
  if (typeof showToast === 'function') showToast('ใช้โปรแกรมพื้นฐาน (AI ยังไม่โหลด)');
}


function renderAIProgramResult(text) {
  const container = document.getElementById('program-content');
  if (!container) return;
  if (!text || typeof text !== 'string') {
    console.warn('renderAIProgramResult: text is invalid', text);
    generateLocalProgram();
    return;
  }
  const eq  = getEquipment();
  const loc = getTrainLocation();
  const eqText = eq.length ? eq.join(' · ') : 'Bodyweight';
  let html = `<div class="ai-program-result">
    <div class="ai-program-meta">
      <span>📍 ${loc}</span><span>🛠️ ${eqText}</span>
    </div>`;
  const lines = text.split('\n');
  let inDay = false;
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (/^\*{0,2}Day\s*\d/i.test(line) || /^วัน(จันทร์|อังคาร|พุธ|พฤหัสบดี|ศุกร์|เสาร์|อาทิตย์)/.test(line)) {
      if (inDay) html += '</div></div>';
      const title     = line.replace(/\*\*/g,'').replace(/^#+\s*/,'');
      const typeEmoji = /push/i.test(title)?'💪':/pull/i.test(title)?'🔝':/run|cardio/i.test(title)?'🏃':/core/i.test(title)?'🎯':/full|body/i.test(title)?'🔥':/recovery|พัก/i.test(title)?'💤':'📅';
      html += `<div class="program-day-card">
        <div class="program-day-header"><div class="program-day-name">${typeEmoji} ${title}</div></div>
        <div class="program-exercises">`;
      inDay = true;
    } else if (inDay && (line.startsWith('•')||line.startsWith('-')||line.startsWith('*')||/^\d+[\.\)]/.test(line))) {
      const content = line.replace(/^[•\-\*]\s*/,'').replace(/^\d+[\.\)]\s*/,'');
      const match = content.match(/^(.+?)\s{2,}(.+)$/) || content.match(/^(.+?)\s+(\d+[×x].+)$/);
      if (match) {
        html += `<div class="program-ex-item"><div class="program-ex-num">▸</div>
          <div><div class="program-ex-name">${match[1]}</div>
          <div class="program-ex-detail">${match[2]}</div></div></div>`;
      } else {
        html += `<div class="program-ex-item"><div class="program-ex-num">▸</div>
          <div><div class="program-ex-name">${content}</div></div></div>`;
      }
    } else if (inDay && !line.startsWith('#')) {
      html += `<div style="font-size:12px;color:#9a9a9a;padding:3px 0">${line}</div>`;
    }
  }
  if (inDay) html += '</div></div>';
  const modelName = localStorage.getItem('gemini_model') || 'gemini-1.5-flash';
  html += `<div class="ai-program-footer">✨ สร้างโดย AI (${getProvider()==='gemini'?modelName:'GPT-4o-mini'}) · บันทึกแล้ว</div></div>`;
  container.innerHTML = html;
}

// ─────────────────────────────────────────────
// RAW API HELPERS
// ─────────────────────────────────────────────
const GEMINI_MODEL = localStorage.getItem('gemini_model') || 'gemini-1.5-flash';
const OPENAI_MODEL = localStorage.getItem('openai_model') || 'gpt-4o-mini';

// [AI SYSTEM PACK] askOpenAIRaw และ askGeminiRaw ถูก override โดย ai_providers.js
// (โหลดก่อน app.js — ดูลำดับ script ใน index.html)
// function declarations ที่นี่จะ hoist และ overwrite window property ถ้าไม่ระวัง
// วิธีแก้: ใช้ if-guard ไม่ประกาศถ้า ai_providers.js โหลดแล้ว
// ai_providers.js set window.askGeminiRaw._fromProviders = true เป็น marker

if (!window.askOpenAIRaw?._fromProviders) {
  // ai_providers.js ยังไม่โหลด → ใช้ fallback minimal
  window.askOpenAIRaw = async function askOpenAIRawFallback(messages, apiKey, maxTokens = 450) {
    let r;
    try {
      r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
        body: JSON.stringify({ model: OPENAI_MODEL, messages, max_tokens: maxTokens }),
      });
    } catch (e) { throw new Error('Network error — ไม่สามารถเชื่อมต่อ OpenAI ได้'); }
    if (!r.ok) throw new Error(`OpenAI Error: HTTP ${r.status}`);
    const d = await r.json();
    const text = d?.choices?.[0]?.message?.content;
    if (!text) throw new Error('OpenAI ตอบกลับว่างเปล่า');
    return text;
  };
}

if (typeof window._geminiCalling === 'undefined') window._geminiCalling = false;

if (!window.askGeminiRaw?._fromProviders) {
  window.askGeminiRaw = async function askGeminiRawFallback(prompt, apiKey, maxTokens = 450) {
    if (window._geminiCalling) { return null; }
    window._geminiCalling = true;
    try {
      const model = localStorage.getItem('gemini_model') || 'gemini-1.5-flash';
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          generationConfig: { maxOutputTokens: maxTokens, temperature: 0.7 },
        }),
      });
      if (!r.ok) throw new Error(`Gemini Error: HTTP ${r.status}`);
      const d = await r.json();
      const text = d?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!text) throw new Error('Gemini ตอบกลับว่างเปล่า');
      return text;
    } finally {
      window._geminiCalling = false;
    }
  };
}


// ─────────────────────────────────────────────
// AI COACH CHAT
// ─────────────────────────────────────────────

// [QUOTA-FIX] Chat guard + rate limit
let _chatCalling    = false;
let _lastChatTime   = 0;
const CHAT_COOLDOWN = 2000; // ms ขั้นต่ำระหว่าง message

async function sendChat() {
  const input   = document.getElementById('chat-input');
  const sendBtn = document.querySelector('.chat-send-btn') || document.getElementById('chat-send-btn');
  if (!input) { console.error('Chat input not found'); return; }

  const msg = input.value.trim();
  if (!msg) return;

  // Rate limit guard
  const now = Date.now();
  if (_chatCalling) {
    showToast('⏳ AI กำลังตอบอยู่ รอสักครู่...');
    return;
  }
  if (now - _lastChatTime < CHAT_COOLDOWN) {
    showToast('⏳ รอสักครู่ก่อนส่งอีกครั้ง');
    return;
  }

  _chatCalling  = true;
  _lastChatTime = now;
  input.value   = '';

  // Disable input + button while AI responds
  input.disabled = true;
  if (sendBtn) { sendBtn.disabled = true; sendBtn.textContent = '⏳'; }

  appendChatMsg(msg, 'user');

  try {
    await callAI(msg);
  } finally {
    _chatCalling       = false;
    input.disabled     = false;
    input.focus();
    if (sendBtn) { sendBtn.disabled = false; sendBtn.textContent = '→'; }
  }
}

function quickAsk(msg) {
  // guard: ไม่ส่งถ้า chat กำลัง busy
  if (_chatCalling) { showToast('⏳ AI กำลังตอบอยู่ รอสักครู่...'); return; }
  const input = document.getElementById('chat-input');
  if (input) input.value = msg;
  sendChat();
}

function appendChatMsg(text, role) {
  const chat = document.getElementById('chat-messages');
  if (!chat) return;
  const div = document.createElement('div');
  div.className = `chat-msg ${role}-msg`;
  div.innerHTML = `<div class="chat-bubble">${text.replace(/\n/g,'<br>')}</div>`;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

function showTyping() {
  const chat = document.getElementById('chat-messages');
  if (!chat) return null;
  const div = document.createElement('div');
  div.className = 'chat-msg ai-msg typing-indicator';
  div.innerHTML = '<div class="chat-bubble"><div class="chat-typing"><span></span><span></span><span></span></div></div>';
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
  return div;
}

async function callAI(userMsg) {
  const profile      = getProfile();
  const systemPrompt = buildSystemPrompt();
  const provider     = getProvider();
  const apiKey       = getActiveKey();

  if (!apiKey || apiKey.length < 10) {
    const typing = showTyping();
    const noKeyMsg = provider === 'gemini'
      ? '🔑 กรุณาใส่ Gemini API Key ในหน้าตั้งค่า\n(รับฟรีที่ aistudio.google.com)'
      : '🔑 กรุณาใส่ OpenAI API Key ในหน้าตั้งค่า\n(รับที่ platform.openai.com)';
    if (typing) typing.remove();
    appendChatMsg(noKeyMsg + '\n\n' + getFallbackResponse(userMsg, profile), 'ai');
    return;
  }

  const typing = showTyping();
  try {
    let reply = '';
    if (provider === 'gemini') {
      // [BUG-7 FIX] Gemini รับ prompt เดียว — รวม system+user ให้ชัดเจน
      const fullPrompt = systemPrompt + '\n\n---\nคำถาม: ' + userMsg;
      // [QUOTA-FIX] ลด maxTokens chat 600→400
      reply = await askGeminiRaw(fullPrompt, apiKey, 400);
    } else {
      reply = await askOpenAIRaw([
        { role:'system', content:systemPrompt },
        { role:'user',   content:userMsg }
      ], apiKey, 400);
    }
    if (typing) typing.remove();

    // [BUG-8 FIX] null = _geminiCalling block → fallback ที่เป็นมิตร
    if (!reply) {
      appendChatMsg('⏳ AI ยังไม่ว่าง กรุณารอสักครู่แล้วถามใหม่\n\n' + getFallbackResponse(userMsg, profile), 'ai');
      return;
    }
    appendChatMsg(reply, 'ai');
  } catch(err) {
    if (typing) typing.remove();
    // [BUG-10 FIX] quota error message ชัดเจนพร้อม hint
    const isQuota = err.message?.includes('quota') || err.message?.includes('429') || err.message?.includes('rate');
    const errMsg = isQuota
      ? '⚠️ Quota หมดแล้ว!\n💡 วิธีแก้:\n• รอ 1 นาทีแล้วลองใหม่\n• ลดความถี่การถาม\n• หรือเปลี่ยนไปใช้ OpenAI'
      : (provider === 'gemini'
          ? '⚠️ Gemini ตอบไม่ได้: ' + (err.message || 'network error')
          : '⚠️ OpenAI ตอบไม่ได้: '  + (err.message || 'network error'));
    appendChatMsg(errMsg + '\n\n' + getFallbackResponse(userMsg, profile), 'ai');
  }
}

function getFallbackResponse(msg, profile) {
  const lm  = msg.toLowerCase();
  const eq  = getEquipment();
  const hasBar = eq.some(e=>e.includes('บาร์'));
  if (lm.includes('pullup')||lm.includes('ดึงข้อ')) {
    if (hasBar) return '💪 มีบาร์โหนแล้ว เริ่มได้เลย!\n\n1. Dead Hang 3×30วิ\n2. Scapula Pullups 3×10\n3. Negative Pullups 3×5 (3วิลงช้า)\n4. GTG: ทุก 2 ชม. ทำ 40-50% ของ max';
    return '💪 ยังไม่มีบาร์โหน ทำแบบนี้ก่อน:\n\n1. Dead Hang บนขอบประตู/ท่อ\n2. Negative: หาอะไรปีนขึ้น แล้วลงช้า\n3. Scapula Pull: ยืดหัวไหล่ตอนแขวน\n4. เพิ่มบาร์โหนแล้วความก้าวหน้าจะเร็วมาก!';
  }
  if (lm.includes('โปรตีน')||lm.includes('protein')||lm.includes('กิน')) {
    const w = parseFloat(profile.weight)||90;
    return `🥩 น้ำหนัก ${w} กก. ต้องการโปรตีน:\n\n• ขั้นต่ำ: ${Math.round(w*1.6)} กรัม/วัน\n• เหมาะสม: ${Math.round(w*1.8)} กรัม/วัน\n• สูงสุด: ${Math.round(w*2.2)} กรัม/วัน\n\nแหล่งดี: ไข่ไก่ อกไก่ ปลาทูน่า กรีกโยเกิร์ต\nน้ำ: 3+ ลิตร/วัน`;
  }
  if (lm.includes('พัก')||lm.includes('rest')||lm.includes('เหนื่อย')) {
    return '😴 ควรพักเมื่อ:\n\n• ปวดกล้ามเนื้อ > 48 ชม.\n• นอนหลับยาก\n• ประสิทธิภาพลดลงติดต่อกัน 2-3 วัน\n\n💡 Recovery ดีที่สุด: เดินเบาๆ 20 นาที + Stretching';
  }
  if (lm.includes('ลดไขมัน')||lm.includes('ลดน้ำหนัก')||lm.includes('อ้วน')) {
    const w = parseFloat(profile.weight)||90;
    return `🔥 แผนลดไขมัน สำหรับ ${w} กก.:\n\n• Calorie deficit 300-500 kcal/วัน\n• โปรตีนสูง ${Math.round(w*1.8)} กรัม/วัน\n• Cardio 4-5 วัน/สัปดาห์\n• ลด Processed food, น้ำตาล\n• นอน 7-8 ชม. สำคัญมาก!`;
  }
  return `💪 สวัสดี ${profile.name}! ใส่ API Key ในหน้าตั้งค่าเพื่อใช้ AI จริง\n\nถามได้เลย: pullup · โปรตีน · พักดีไหม · ลดไขมัน`;
}

// ─────────────────────────────────────────────
// WORKOUT LOG
// ─────────────────────────────────────────────
function openWorkoutModal() {
  const modal = document.getElementById('workout-modal');
  if (!modal) { showToast('⚠️ Workout modal not found'); return; }
  modal.classList.remove('hidden');
  const dateEl    = document.getElementById('wk-date');
  const entriesEl = document.getElementById('exercise-entries');
  const notesEl   = document.getElementById('wk-notes');
  if (dateEl)    dateEl.value    = new Date().toISOString().split('T')[0];
  if (entriesEl) entriesEl.innerHTML = '';
  if (notesEl)   notesEl.value   = '';
  addExerciseEntry();
}

function closeWorkoutModal() {
  const modal = document.getElementById('workout-modal');
  if (modal) modal.classList.add('hidden');
}

function addExerciseEntry() {
  const container = document.getElementById('exercise-entries');
  if (!container) { console.error('Exercise entries container not found'); return; }
  const opts = EXERCISES.map(e=>`<option>${e}</option>`).join('');
  const div  = document.createElement('div');
  div.className = 'exercise-entry';
  div.innerHTML = `<div style="display:flex;gap:8px;margin-bottom:8px;align-items:center">
    <select style="flex:1">${opts}</select>
    <div class="entry-delete" onclick="this.closest('.exercise-entry')?.remove()">✕</div></div>
    <div class="entry-row">
      <div><div class="entry-label">เซต</div><input type="number" placeholder="3" min="1"></div>
      <div><div class="entry-label">ครั้ง/เวลา</div><input type="text" placeholder="10"></div>
      <div><div class="entry-label">ระยะ (กม.)</div><input type="number" placeholder="0" step="0.1"></div>
    </div>`;
  container.appendChild(div);
}

async function saveWorkout() {
  const dateEl  = document.getElementById('wk-date');
  const typeEl  = document.getElementById('wk-type');
  const notesEl = document.getElementById('wk-notes');
  const date    = dateEl?.value || '';
  const type    = typeEl?.value || 'fullbody';
  const notes   = notesEl?.value || '';
  const entries = [...document.querySelectorAll('.exercise-entry')];

  if (!date || !entries.length) { showToast('⚠️ กรุณากรอกข้อมูล'); return; }

  const exercises = entries.map(e => {
    const selects = e.querySelectorAll('select');
    const inputs  = e.querySelectorAll('input');
    const name    = selects[0]?.value || 'Exercise';
    const sets    = inputs[0]?.value  || '1';
    const reps    = inputs[1]?.value  || '10';
    const weight  = inputs[2]?.value  || '0';
    if (!validateWorkoutInput(sets, reps, weight)) {
      showToast('⚠️ ค่าไม่ถูกต้อง — exercise นี้จะถูกข้าม');
      return null; // FIX [High]: return null so it can be filtered out below
    }
    // FIX [Critical]: was mapping inputs[2] (weight/distance field) to 'distance' key only
    // Engine.logWorkout reads ex.weight for volume calc — must send both fields correctly
    const rawInput = inputs[2]?.value || '0';
    const isDistance = (name.toLowerCase().includes('วิ่ง') || name.toLowerCase().includes('run') ||
                        name.toLowerCase().includes('cycling') || name.toLowerCase().includes('walk'));
    return {
      name,
      sets:     Number(sets),
      reps:     Number(reps),
      weight:   isDistance ? 0 : Number(rawInput),
      distance: isDistance ? Number(rawInput) : 0,
    };
  });

  // FIX [High]: filter out null entries from invalid exercises
  const validExercises = exercises.filter(Boolean);
  if (!validExercises.length) { showToast('⚠️ ไม่มีข้อมูลการออกกำลังกายที่ถูกต้อง'); return; }

  try {
    await dbAdd('workouts', { date, type, exercises: validExercises, notes, timestamp:Date.now() });
  } catch (dbErr) {
    console.error('[saveWorkout] DB write failed:', dbErr);
    showToast('⚠️ บันทึก DB ไม่สำเร็จ กรุณาลองใหม่');
    return;
  }

  let xpGained = 10;
  if (window.OPERATOR_ENGINE && typeof OPERATOR_ENGINE.logWorkout === 'function') {
    try {
      const result = OPERATOR_ENGINE.logWorkout(validExercises.map(ex => ({
        ...ex,
        muscle: _guessMuscleFromWorkoutType(type),
        // FIX: weight is already correctly set from exercise map above; ex.distance is for cardio
        weight: ex.weight || 0,
      })));
      xpGained = result?.xpGained ?? 10;
      LS.set('xp', OPERATOR_ENGINE.state.xp ?? xpGained);
    } catch(e) {
      console.error('Engine logWorkout error:', e);
      addXP(xpGained);
    }
  } else {
    const result = completeWorkout(validExercises);
    xpGained = result?.xpGained ?? 10;
    addXP(xpGained);
  }

  const today     = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now()-86400000).toISOString().split('T')[0];
  if (window.OPERATOR_ENGINE && typeof OPERATOR_ENGINE.state?.streak === 'number') {
    LS.set('streak', OPERATOR_ENGINE.state.streak);
  } else {
    const last   = LS.get('lastWorkoutDate');
    let streak   = LS.get('streak', 0);
    if (last === yesterday) streak++;
    else if (last !== today) streak = 1;
    LS.set('streak', streak);
  }
  LS.set('lastWorkoutDate', today);
  const trained = LS.get('trainedDays', {});
  trained[today] = type;
  LS.set('trainedDays', trained);

  closeWorkoutModal?.();
  engineRenderReadinessBar?.();
  showToast(`✅ บันทึกการฝึกแล้ว! +${xpGained} XP`);
  renderWorkoutHistory?.();
  renderTopBar?.();
  renderWeekGrid?.();
}

async function renderWorkoutHistory() {
  const workouts  = await dbGetAll('workouts').catch(()=>[]);
  const sorted    = workouts.sort((a,b)=>b.timestamp-a.timestamp);
  const container = document.getElementById('workout-history');
  if (!container) return;
  if (!sorted.length) {
    container.innerHTML='<div style="text-align:center;padding:40px;color:#9a9a9a">ยังไม่มีการบันทึก<br>กด + เพิ่ม เพื่อเริ่ม</div>';
    return;
  }
  container.innerHTML = sorted.map(w=>`
    <div class="workout-card">
      <div class="workout-card-header">
        <div class="workout-type-tag">${WORKOUT_TYPES[w.type]||w.type}</div>
        <div class="workout-date">${w.date}</div></div>
      ${w.exercises.map(ex=>`<div class="exercise-row"><span class="exercise-name">${ex.name}</span> · ${ex.sets}×${ex.reps}${parseFloat(ex.distance)>0?' · '+ex.distance+' กม.':''}</div>`).join('')}
      ${w.notes?`<div class="workout-notes">"${w.notes}"</div>`:''}
    </div>`).join('');
}

// ─────────────────────────────────────────────
// WEIGHT
// ─────────────────────────────────────────────
async function logWeight() {
  const input = document.getElementById('weight-input');
  const val   = parseFloat(input?.value || '0');
  if (!val||val<30||val>300) { showToast('⚠️ กรุณากรอกน้ำหนักที่ถูกต้อง'); return; }
  await dbAdd('weights', { date:new Date().toISOString().split('T')[0], weight:val });
  if (input) input.value = '';
  showToast(`⚖️ บันทึก ${val} กก.`);
  renderProgress();
  renderDashboard();
}

async function renderProgress() {
  const weights = await dbGetAll('weights').catch(()=>[]);
  const sorted  = weights.sort((a,b)=>a.date.localeCompare(b.date));
  drawWeightChart(sorted);
  const pullupMax = LS.get('pullupMax',0);
  const pct       = Math.min(pullupMax/25*100,100);
  const pBar = document.getElementById('pullup-bar-fill');
  const pNum = document.getElementById('pullup-current-max');
  if (pBar) pBar.style.width = pct+'%';
  if (pNum) pNum.textContent = pullupMax;
  const stages = ['🎯 Stage 1: Dead Hang & Negatives','🎯 Stage 2: Band Assisted','💪 Stage 3: Strict Pullups – กำลังพัฒนา','⚡ Stage 4: Volume Building','🏆 Stage 5: Elite – เกือบถึง 25!'];
  const stageEl = document.getElementById('pullup-stage-info');
  if (stageEl) stageEl.textContent = pullupMax<1?stages[0]:pullupMax<3?stages[1]:pullupMax<10?stages[2]:pullupMax<20?stages[3]:stages[4];
  renderFitnessTestHistory();
}

function drawWeightChart(records) {
  const canvas = document.getElementById('weight-chart');
  if (!canvas||records.length<2) return;
  const dpr=window.devicePixelRatio||1;
  const W=canvas.offsetWidth*dpr||360, H=200*dpr;
  canvas.width=W; canvas.height=H;
  const ctx=canvas.getContext('2d');
  if (!ctx) return;
  const weights=records.map(r=>r.weight);
  const min=Math.min(...weights)-2, max=Math.max(...weights)+2;
  const pad={top:20*dpr,right:20*dpr,bottom:30*dpr,left:40*dpr};
  const cW=W-pad.left-pad.right, cH=H-pad.top-pad.bottom;
  ctx.clearRect(0,0,W,H);
  for(let i=0;i<=4;i++){
    const y=pad.top+(cH/4)*i;
    ctx.strokeStyle='#2a2a2e'; ctx.lineWidth=dpr;
    ctx.beginPath(); ctx.moveTo(pad.left,y); ctx.lineTo(W-pad.right,y); ctx.stroke();
    ctx.fillStyle='#5a5a60'; ctx.font=`${11*dpr}px sans-serif`;
    ctx.fillText((max-((max-min)/4)*i).toFixed(0),4,y+4*dpr);
  }
  const goalY=pad.top+((max-80)/(max-min))*cH;
  if(goalY>=pad.top&&goalY<=pad.top+cH){
    ctx.strokeStyle='#e0a030'; ctx.lineWidth=dpr; ctx.setLineDash([6*dpr,4*dpr]);
    ctx.beginPath(); ctx.moveTo(pad.left,goalY); ctx.lineTo(W-pad.right,goalY); ctx.stroke();
    ctx.setLineDash([]); ctx.fillStyle='#e0a030'; ctx.fillText('80',4,goalY);
  }
  if(records.length<2) return;
  const pts=records.map((r,i)=>({x:pad.left+(i/(records.length-1))*cW,y:pad.top+((max-r.weight)/(max-min))*cH}));
  const grad=ctx.createLinearGradient(0,pad.top,0,pad.top+cH);
  grad.addColorStop(0,'rgba(120,204,85,0.3)'); grad.addColorStop(1,'rgba(120,204,85,0)');
  ctx.beginPath(); ctx.moveTo(pts[0].x,pad.top+cH); pts.forEach(p=>ctx.lineTo(p.x,p.y)); ctx.lineTo(pts[pts.length-1].x,pad.top+cH); ctx.closePath();
  ctx.fillStyle=grad; ctx.fill();
  ctx.strokeStyle='#78cc55'; ctx.lineWidth=2*dpr; ctx.lineJoin='round';
  ctx.beginPath(); pts.forEach((p,i)=>i===0?ctx.moveTo(p.x,p.y):ctx.lineTo(p.x,p.y)); ctx.stroke();
  pts.forEach(p=>{ ctx.beginPath(); ctx.arc(p.x,p.y,4*dpr,0,Math.PI*2); ctx.fillStyle='#78cc55'; ctx.fill(); });
}

function drawMiniChart(weights) {
  const canvas=document.getElementById('weight-mini-chart');
  if(!canvas||weights.length<2) return;
  const dpr=window.devicePixelRatio||1;
  const W=canvas.offsetWidth*dpr||300, H=80*dpr;
  canvas.width=W; canvas.height=H;
  const ctx=canvas.getContext('2d');
  if (!ctx) return;
  const min=Math.min(...weights)-1, max=Math.max(...weights)+1;
  const pad={t:8*dpr,r:8*dpr,b:8*dpr,l:8*dpr};
  const cW=W-pad.l-pad.r, cH=H-pad.t-pad.b;
  ctx.clearRect(0,0,W,H);
  const pts=weights.map((w,i)=>({x:pad.l+(i/(weights.length-1))*cW,y:pad.t+((max-w)/(max-min))*cH}));
  ctx.strokeStyle='#78cc55'; ctx.lineWidth=2*dpr; ctx.lineJoin='round';
  ctx.beginPath(); pts.forEach((p,i)=>i===0?ctx.moveTo(p.x,p.y):ctx.lineTo(p.x,p.y)); ctx.stroke();
}

// ─────────────────────────────────────────────
// FITNESS TEST
// ─────────────────────────────────────────────
function openFitnessTest() {
  const modal = document.getElementById('fitness-modal');
  if (!modal) return;
  modal.classList.remove('hidden');
  const dateEl = document.getElementById('ft-date');
  if (dateEl) dateEl.value = new Date().toISOString().split('T')[0];
}

function closeFitnessTest() {
  const modal = document.getElementById('fitness-modal');
  if (modal) modal.classList.add('hidden');
}

async function saveFitnessTest() {
  const dateEl    = document.getElementById('ft-date');
  const pushupEl  = document.getElementById('ft-pushups');
  const situpsEl  = document.getElementById('ft-situps');
  const pullupsEl = document.getElementById('ft-pullups');
  const runEl     = document.getElementById('ft-run');
  const weightEl  = document.getElementById('ft-weight');
  const date    = dateEl?.value    || '';
  const pushups = parseInt(pushupEl?.value  || '0')||0;
  const situps  = parseInt(situpsEl?.value  || '0')||0;
  const pullups = parseInt(pullupsEl?.value || '0')||0;
  const run     = runEl?.value     || '--';
  const weight  = parseFloat(weightEl?.value || '0')||0;
  await dbAdd('tests',{date,pushups,situps,pullups,run,weight,timestamp:Date.now()});
  if(pullups>LS.get('pullupMax',0)) LS.set('pullupMax',pullups);
  if(weight>0) await dbAdd('weights',{date,weight});
  addXP(50);
  closeFitnessTest();
  showToast('🏆 บันทึกผลทดสอบ! +50 XP');
  renderProgress();
  renderStats();
}

async function renderFitnessTestHistory() {
  const tests  = await dbGetAll('tests').catch(()=>[]);
  const sorted = tests.sort((a,b)=>b.timestamp-a.timestamp);
  const container = document.getElementById('fitness-test-history');
  if(!container) return;
  if(!sorted.length){ container.innerHTML='<div style="color:#9a9a9a;font-size:13px;padding:12px 0">ยังไม่มีผลทดสอบ</div>'; return; }
  container.innerHTML=sorted.slice(0,5).map(t=>`
    <div class="test-card">
      <div class="test-card-date">📅 ${t.date}</div>
      <div class="test-stats">
        <div class="test-stat"><div class="test-stat-val">${t.pushups}</div><div class="test-stat-label">Pushups</div></div>
        <div class="test-stat"><div class="test-stat-val">${t.situps}</div><div class="test-stat-label">Situps</div></div>
        <div class="test-stat"><div class="test-stat-val">${t.pullups}</div><div class="test-stat-label">Pullups</div></div>
        <div class="test-stat"><div class="test-stat-val" style="font-size:18px">${t.run}</div><div class="test-stat-label">1.6กม.</div></div>
      </div>${t.weight?`<div style="font-size:12px;color:#9a9a9a;margin-top:8px">⚖️ ${t.weight} กก.</div>`:''}
    </div>`).join('');
}

// ─────────────────────────────────────────────
// STATS
// ─────────────────────────────────────────────
async function renderStats() {
  const workouts = await dbGetAll('workouts').catch(()=>[]);
  const tests    = await dbGetAll('tests').catch(()=>[]);
  const xp       = LS.get('xp',0);
  const streak   = LS.get('streak',0);
  const rank     = getRank(xp);
  const oeA      = window.OPERATOR_ENGINE ? OPERATOR_ENGINE.getAnalytics() : null;
  const displayRank   = oeA ? oeA.rank   : rank;
  const displayStreak = oeA ? oeA.streak : streak;
  const displayXP     = oeA ? oeA.xp     : xp;
  const displayVol    = oeA ? Math.round(oeA.totalVolume) : '--';
  const statsEl = document.getElementById('stats-grid');
  if (statsEl) {
    statsEl.innerHTML=`
    <div class="stat-card"><div class="stat-icon">⚡</div><div class="stat-val">${displayXP}</div><div class="stat-label">XP รวม</div></div>
    <div class="stat-card"><div class="stat-icon">🔥</div><div class="stat-val">${displayStreak}</div><div class="stat-label">Streak (วัน)</div></div>
    <div class="stat-card"><div class="stat-icon">💪</div><div class="stat-val">${workouts.length}</div><div class="stat-label">การฝึกรวม</div></div>
    <div class="stat-card"><div class="stat-icon">${displayRank.emoji||rank.emoji}</div><div class="stat-val" style="font-size:16px">${displayRank.name||rank.name}</div><div class="stat-label">ยศ (Performance)</div></div>
    ${oeA?`<div class="stat-card stat-card-wide"><div class="stat-icon">📊</div><div class="stat-val" style="font-size:16px">${displayVol.toLocaleString()}</div><div class="stat-label">Total Volume (กก.)</div></div>`:''}
    ${oeA?`<div class="stat-card stat-card-wide"><div class="stat-icon">${oeA.readinessLbl.split(' ')[0]}</div><div class="stat-val" style="font-size:16px">${oeA.readiness}</div><div class="stat-label">${oeA.readinessLbl}</div></div>`:''}`;
  }
  const latest    = tests.sort((a,b)=>b.timestamp-a.timestamp)[0];
  const container = document.getElementById('latest-test-stats');
  if(!container) return;
  if(!latest){ container.innerHTML='<div style="color:#9a9a9a;font-size:13px">ยังไม่มีผลทดสอบ</div>'; return; }
  const targets={pushups:100,situps:100,pullups:25};
  container.innerHTML=`<div class="test-card">
    <div class="test-card-date">ผลล่าสุด – ${latest.date}</div>
    <div class="test-stats">
      <div class="test-stat"><div class="test-stat-val">${latest.pushups}<small style="font-size:13px;color:#9a9a9a">/100</small></div><div class="test-stat-label">Pushups</div></div>
      <div class="test-stat"><div class="test-stat-val">${latest.situps}<small style="font-size:13px;color:#9a9a9a">/100</small></div><div class="test-stat-label">Situps</div></div>
      <div class="test-stat"><div class="test-stat-val">${latest.pullups}<small style="font-size:13px;color:#9a9a9a">/25</small></div><div class="test-stat-label">Pullups</div></div>
      <div class="test-stat"><div class="test-stat-val" style="font-size:17px">${latest.run}</div><div class="test-stat-label">1.6กม.</div></div>
    </div>
    <div style="margin-top:12px">
      ${['pushups','situps','pullups'].map(k=>{
        const pct=Math.min(latest[k]/targets[k]*100,100);
        const col=pct>=100?'#78cc55':pct>=60?'#e0a030':'#e05555';
        return `<div style="margin-bottom:8px">
          <div style="display:flex;justify-content:space-between;font-size:12px;color:#9a9a9a;margin-bottom:4px">
            <span>${k.charAt(0).toUpperCase()+k.slice(1)}</span><span>${latest[k]}/${targets[k]}</span></div>
          <div style="height:6px;background:#2a2a2e;border-radius:4px;overflow:hidden">
            <div style="height:100%;width:${pct}%;background:${col};border-radius:4px"></div></div></div>`;
      }).join('')}
    </div></div>`;
}

// ─────────────────────────────────────────────
// SETTINGS UI
// ─────────────────────────────────────────────
function loadSettingsUI() {
  const provider   = getProvider();
  const openaiKey  = getOpenAIKey();
  const geminiKey  = getGeminiKey();
  const customGoal = getCustomGoal();
  const oel = document.getElementById('api-key-openai');
  const gel = document.getElementById('api-key-gemini');
  if (oel) { oel.value = openaiKey; oel.style.borderColor = openaiKey.length > 10 ? 'var(--accent)' : ''; }
  if (gel) { gel.value = geminiKey; gel.style.borderColor = geminiKey.length > 10 ? '#4285f4' : ''; }
  switchProvider(provider, true);
  ['custom-goal-settings','custom-goal-input'].forEach(id=>{
    const el=document.getElementById(id);
    if(el&&customGoal) el.value=customGoal;
  });
  const loc = getTrainLocation();
  document.querySelectorAll('input[name="location"]').forEach(r=>{
    r.checked=(r.value===loc);
    r.closest('.loc-btn')?.classList.toggle('active',r.checked);
    r.onchange = () => {
      setTrainLocation(r.value);
      document.querySelectorAll('.loc-btn').forEach(b=>b.classList.remove('active'));
      r.closest('.loc-btn')?.classList.add('active');
      showToast('📍 '+r.value);
      updateEquipmentSummary();
    };
  });
  const saved = getEquipment();
  document.querySelectorAll('#equipment-grid input[type="checkbox"]').forEach(cb=>{
    cb.checked=saved.includes(cb.value);
    cb.closest('.eq-btn')?.classList.toggle('active',cb.checked);
    cb.onchange=()=>cb.closest('.eq-btn')?.classList.toggle('active',cb.checked);
  });
  renderSettingsProfile();
  updateEquipmentSummary();
  updateProviderBadge(provider);
}

function switchProvider(provider, silent=false) {
  setProvider(provider);
  document.querySelectorAll('.ai-tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.provider-panel').forEach(p=>p.classList.add('hidden'));
  document.getElementById('tab-'+provider)?.classList.add('active');
  document.getElementById('provider-'+provider)?.classList.remove('hidden');
  updateProviderBadge(provider);
}

function updateProviderBadge(provider) {
  const badge = document.getElementById('provider-badge');
  if (!badge) return;
  if (provider==='gemini') {
    badge.textContent='🔵 Gemini Flash';
    Object.assign(badge.style,{background:'rgba(66,133,244,0.15)',borderColor:'#4285f4',color:'#4285f4'});
  } else {
    badge.textContent='🟢 GPT-4o-mini';
    Object.assign(badge.style,{background:'rgba(120,204,85,0.12)',borderColor:'var(--accent)',color:'var(--accent)'});
  }
}

function saveApiKey() {
  const provider = getProvider();
  if (provider === 'gemini') {
    const keyEl = document.getElementById('api-key-gemini');
    const key   = keyEl?.value?.trim() || '';
    if (!key) { showToast('⚠️ กรุณากรอก Gemini Key ก่อน'); return; }
    ['gemini_api_key','gemini_key','geminiKey','gemini'].forEach(k=>localStorage.setItem(k,key));
    showToast('🔑 บันทึก Gemini Key แล้ว (' + key.slice(0,8) + '…)');
    updateProviderBadge('gemini');
  } else {
    const keyEl = document.getElementById('api-key-openai');
    const key   = keyEl?.value?.trim() || '';
    if (!key) { showToast('⚠️ กรุณากรอก OpenAI Key ก่อน'); return; }
    ['openai_api_key','openai_key','apiKey','openaiKey'].forEach(k=>localStorage.setItem(k,key));
    showToast('🔑 บันทึก OpenAI Key แล้ว (' + key.slice(0,8) + '…)');
    updateProviderBadge('openai');
  }
}

function saveCustomGoal() {
  const val = (document.getElementById('custom-goal-settings')?.value || document.getElementById('custom-goal-input')?.value || '').trim();
  setCustomGoal(val);
  ['custom-goal-settings','custom-goal-input'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=val; });
  showToast('🎯 บันทึกเป้าหมายแล้ว');
}

function setQuickGoal(text) {
  const el=document.getElementById('custom-goal-input');
  if(el) el.value=text;
  setCustomGoal(text);
  showToast('🎯 เลือกเป้าหมาย: '+text.slice(0,20)+'…');
}

function saveEquipment() {
  const checked = document.querySelectorAll('#equipment-grid input:checked');
  const arr     = [...checked].map(e=>e.value);
  setEquipment(arr);
  showToast('🛠️ บันทึกอุปกรณ์ '+arr.length+' รายการ');
  updateEquipmentSummary();
}

function updateEquipmentSummary() {
  const badge = document.getElementById('eq-summary-badge');
  if (!badge) return;
  const eq=getEquipment(), loc=getTrainLocation();
  badge.textContent = eq.length
    ? `📍 ${loc}  ·  🛠️ ${eq.join(' · ')}`
    : `📍 ${loc}  ·  🛠️ ยังไม่ได้เลือกอุปกรณ์ (ไปที่ตั้งค่า)`;
  badge.style.display='block';
}

function renderSettingsProfile() {
  const p=getProfile();
  const box=document.getElementById('profile-info-box');
  if(!box) return;
  box.innerHTML=`ชื่อ: <span>${p.name}</span><br>
    อายุ: <span>${p.age||'--'}</span> ปี · ส่วนสูง: <span>${p.height||'--'}</span> ซม.<br>
    น้ำหนักเริ่มต้น: <span>${p.startWeight||p.weight||'--'}</span> กก.<br>
    ระดับ: <span>${FITNESS_LABELS[p.fitness]||'--'}</span> · เป้าหมาย: <span>${GOAL_LABELS[p.goal]||'--'}</span>`;
}

function editProfile() {
  const main       = document.getElementById('main-app');
  const onboarding = document.getElementById('onboarding-screen');
  if (main)       main.classList.add('hidden');
  if (onboarding) onboarding.classList.remove('hidden');
}

// ─────────────────────────────────────────────
// NAVIGATION
// ─────────────────────────────────────────────
function goTo(tab) {
  document.querySelectorAll('.app-screen').forEach(s=>s.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));
  const screenEl = document.getElementById(`screen-${tab}`);
  const navEl    = document.querySelector(`[data-tab="${tab}"]`);
  if (screenEl) screenEl.classList.add('active');
  if (navEl)    navEl.classList.add('active');
  const refreshMap = {
    dashboard: renderDashboard,
    workout:   renderWorkoutHistory,
    program:   () => { restoreOrRenderProgram(); updateEquipmentSummary(); },
    missions:  renderMissions,
    progress:  renderProgress,
    stats:     renderStats,
    analyze:   renderAnalyzeScreen,
    coach:     () => {},
    settings:  loadSettingsUI,
  };
  refreshMap[tab]?.();
}

function renderAnalyzeScreen() {
  if (typeof FitnessEngine !== 'undefined' && FitnessEngine.renderFatigueWidget) {
    FitnessEngine.renderFatigueWidget('fatigue-grid');
  }
  renderMuscleRecoveryGrid();
}

// ─────────────────────────────────────────────
// DATA EXPORT / IMPORT / RESET
// ─────────────────────────────────────────────
async function exportData() {
  const [workouts,weights,tests] = await Promise.all([
    dbGetAll('workouts').catch(()=>[]),
    dbGetAll('weights').catch(()=>[]),
    dbGetAll('tests').catch(()=>[])
  ]);
  const data = {
    version:2, exportDate:new Date().toISOString(),
    profile:getProfile(), xp:LS.get('xp',0), streak:LS.get('streak',0),
    trainedDays:LS.get('trainedDays',{}), pullupMax:LS.get('pullupMax',0),
    custom_goal:getCustomGoal(), equipment:getEquipment(), train_location:getTrainLocation(),
    ai_provider:getProvider(), aiProgram:localStorage.getItem('weekly_program')||'',
    workouts, weights, tests
  };
  const blob = new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href=url; a.download=`operator-${new Date().toISOString().split('T')[0]}.json`; a.click();
  URL.revokeObjectURL(url);
  showToast('📤 ส่งออกข้อมูลแล้ว');
}

async function importData(event) {
  const file=event.target.files?.[0];
  if(!file) return;
  try {
    const data=JSON.parse(await file.text());
    if(data.profile)         LS.set('profile',data.profile);
    if(data.xp!=null)        LS.set('xp',data.xp);
    if(data.streak!=null)    LS.set('streak',data.streak);
    if(data.trainedDays)     LS.set('trainedDays',data.trainedDays);
    if(data.pullupMax!=null) LS.set('pullupMax',data.pullupMax);
    if(data.custom_goal)     setCustomGoal(data.custom_goal);
    if(data.equipment)       setEquipment(data.equipment);
    if(data.train_location)  setTrainLocation(data.train_location);
    if(data.ai_provider)     setProvider(data.ai_provider);
    if(data.aiProgram)       localStorage.setItem('weekly_program',data.aiProgram);
    for(const w of data.workouts||[]) { const{id,...r}=w; await dbAdd('workouts',r).catch(()=>{}); }
    for(const w of data.weights||[])  { const{id,...r}=w; await dbAdd('weights',r).catch(()=>{}); }
    for(const t of data.tests||[])    { const{id,...r}=t; await dbAdd('tests',r).catch(()=>{}); }
    showToast('📥 นำเข้าข้อมูลสำเร็จ');
    loadApp();
  } catch { showToast('❌ ไฟล์ไม่ถูกต้อง'); }
}

function resetAll() {
  const profileCount = (typeof StorageEngine !== 'undefined')
    ? Object.keys(StorageEngine.loadAllProfiles()).length : 1;
  const msg = profileCount > 1
    ? `⚠️ รีเซ็ตข้อมูลทั้งหมด?\nจะลบโปรไฟล์ทั้ง ${profileCount} โปรไฟล์และข้อมูลทั้งหมด\nไม่สามารถกู้คืนได้`
    : '⚠️ รีเซ็ตข้อมูลทั้งหมด? ไม่สามารถกู้คืนได้';
  if (!confirm(msg)) return;
  if (!confirm('ยืนยันอีกครั้ง — ข้อมูลจะหายถาวร')) return;
  localStorage.clear();
  indexedDB.deleteDatabase(DB_NAME).onsuccess = () => location.reload();
}

// ─────────────────────────────────────────────
// TOAST
// ─────────────────────────────────────────────
let toastTimer;
function showToast(msg) {
  const t=document.getElementById('toast');
  if (!t) return;
  t.textContent=msg;
  t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>t.classList.add('hidden'),3000);
}

// ─────────────────────────────────────────────
// [HF-1] OBSERVER — Settings tab (FIXED v4)
// ปัญหาเดิม: loadSettingsUI() → แก้ classList → observer fire อีก → loop
// แก้ด้วย: state guard (_lastSettingsActive) + debounce 80ms
//           เรียก loadSettingsUI เฉพาะตอน inactive→active เท่านั้น
// ─────────────────────────────────────────────
(function setupSettingsObserver() {
  let _lastSettingsActive = false;
  let _debounceTimer = null;

  const observer = new MutationObserver(() => {
    const isActive = !!document.getElementById('screen-settings')
      ?.classList.contains('active');

    // เรียกเฉพาะตอนเปลี่ยน inactive → active
    if (isActive && !_lastSettingsActive) {
      _lastSettingsActive = true;
      clearTimeout(_debounceTimer);
      _debounceTimer = setTimeout(() => {
        try { loadSettingsUI(); } catch(e) { console.error('[Observer] loadSettingsUI error:', e); }
      }, 80);
    } else if (!isActive) {
      _lastSettingsActive = false;
    }
  });

  const target = document.getElementById('screens') || document.body;
  observer.observe(target, { subtree:true, attributes:true, attributeFilter:['class'] });
})();

// ─────────────────────────────────────────────
// AI ANALYSIS — Fatigue
// [QUOTA-FIX] aiAdjustBeforeGenerate ถูกนิยามใน engine.js และ window.aiAdjustBeforeGenerate = ...
//             ลบออกจากที่นี่เพื่อไม่ให้ซ้ำกัน — ใช้ engine.js version เดียว
// ─────────────────────────────────────────────

// ─────────────────────────────────────────────
// STUB FUNCTIONS
// ─────────────────────────────────────────────
function renderMuscleGrid()  { renderMuscleRecoveryGrid(); }
function renderReadiness()   { engineRenderReadinessBar?.(); }
function renderRank()        { renderTopBar(); }
function renderFatigueGrid() {
  if (typeof OPERATOR_ENGINE !== 'undefined' && typeof OPERATOR_ENGINE.renderFatigueWidget === 'function') {
    try { OPERATOR_ENGINE.renderFatigueWidget('fatigue-grid'); } catch (e) { console.error('renderFatigueGrid error:', e); }
  }
}

// ─────────────────────────────────────────────
// WORKOUT GENERATION
// ─────────────────────────────────────────────
function generateWorkoutFromDB(dayType) {
  try {
    if (typeof OPERATOR_ENGINE !== 'undefined' && typeof OPERATOR_ENGINE.generateWorkout === 'function') {
      const result = OPERATOR_ENGINE.generateWorkout(dayType || 'fullbody');
      if (Array.isArray(result) && result.length > 0) return result;
    }
    const program = LS.get('program');
    if (!program || !program.days) return [];
    const today   = new Date().getDay();
    const dayInfo = program.days[today];
    return dayInfo?.exercises || [];
  } catch (e) {
    console.error('generateWorkoutFromDB error:', e);
    return [];
  }
}

// ─────────────────────────────────────────────
// [FIX-1] HELPER
// ─────────────────────────────────────────────
function _guessMuscleFromWorkoutType(type) {
  const map = {
    push:'chest',     pull:'back',    legs:'legs',   core:'core',
    fullbody:'chest', cardio:'cardio',recovery:'core',
    shoulder:'shoulders', shoulders:'shoulders', arms:'arms',
    run:'cardio',     hiit:'cardio',  stretch:'core',
  };
  return map[(type||'').toLowerCase()] || 'chest';
}
window._guessMusclFromWorkoutType  = _guessMuscleFromWorkoutType;
window._guessMuscleFromWorkoutType = _guessMuscleFromWorkoutType;

// ─────────────────────────────────────────────
// ENGINE HELPERS
// ─────────────────────────────────────────────
function renderMuscleRecoveryGrid() {
  const OE   = window.OPERATOR_ENGINE;
  const grid = document.getElementById('muscle-grid');
  if (!grid || !OE) return;
  const muscles = OE.state.muscles || {};
  const labels  = { chest:'💪 Chest', back:'🔝 Back', legs:'🦵 Legs',
                    shoulders:'💥 Shoulders', arms:'💪 Arms', core:'🎯 Core', cardio:'🏃 Cardio' };
  grid.innerHTML = Object.entries(muscles).map(([m, v]) => {
    const ready = Math.round(100 - (v.fatigue || 0));
    const col   = ready >= 80 ? '#78cc55' : ready >= 50 ? '#e0a030' : '#e05555';
    const eta   = ready < 80 ? Math.ceil((100 - ready) / 100 * (m==='legs'?72:m==='back'?48:36)) : 0;
    return `<div class="muscle-card" style="border-color:${col}40">
      <div class="muscle-card-name">${labels[m]||m}</div>
      <div class="muscle-card-bar"><div style="width:${ready}%;background:${col};height:100%;border-radius:3px;transition:width .4s"></div></div>
      <div class="muscle-card-pct" style="color:${col}">${ready}%${eta>0?` · พัก ~${eta}ชม.`:' ✅'}</div>
    </div>`;
  }).join('');
}

function engineRenderReadinessBar() {
  const OE    = window.OPERATOR_ENGINE;
  const score = OE ? OE.getReadiness() : 100;

  // [FIX] getReadinessLabel() คืน object {label, color, advice} ไม่ใช่ string
  //       ดึง .label ออกมาก่อน — ป้องกัน [object Object] แสดงใน UI
  const rlObj = OE ? OE.getReadinessLabel() : null;
  const label = rlObj?.label ?? '🟢 พร้อมเต็มที่';
  const color = rlObj?.color ?? '#78cc55';

  const fill  = document.getElementById('readiness-fill');
  const lbl   = document.getElementById('readiness-label');
  const num   = document.getElementById('readiness-score');
  if (fill) {
    fill.style.width      = score + '%';
    fill.style.background = color;
  }
  if (lbl) lbl.textContent = label;
  if (num) num.textContent  = score;
  renderMuscleRecoveryGrid();
}

function initEngine() {
  if (typeof FitnessEngine === 'undefined') return;
  const profile = getProfile();
  FitnessEngine.init(profile);
  FitnessEngine.dailyRecovery();
  engineRenderReadinessBar?.();
}

// ─────────────────────────────────────────────
// START — guarded: ProfileManager flow calls init() via window.load
// ─────────────────────────────────────────────
if (typeof ProfileManager === 'undefined') {
  // Legacy single-profile mode only
  init();
}
// Multi-profile mode: window.load handler in index.html calls loadApp()/init()

// ======================================================
// ⚔ OPERATOR COMBAT SESSION (Hybrid Mode)
// Production-ready · RPG Layer · Tactical Theme
// ======================================================

const CombatSession = {
  active: false,
  exercises: [],
  index: 0,
  set: 1,
  timer: null,
  restLeft: 0,
  startedAt: null,
  totalVolume: 0,
};

// ── Helper: แปลง rest string → วินาที ──────────────────
function parseRest(rest) {
  if (!rest) return 60;
  if (typeof rest === 'number') return rest;
  const s = String(rest).toLowerCase();
  const m = s.match(/(\d+)\s*m/);
  const sec = s.match(/(\d+)\s*s/);
  const plain = s.match(/^(\d+)$/);
  if (m) return parseInt(m[1]) * 60;
  if (sec) return parseInt(sec[1]);
  if (plain) return parseInt(plain[1]);
  return 60;
}

// ── Helper: getTodayProgram ──────────────────────────────
function getTodayProgram() {
  try {
    if (window.OPERATOR_ENGINE) {
      const dayType = LS.get('todayDayType') || 'fullbody';
      const result = OPERATOR_ENGINE.generateWorkout(dayType);
      if (Array.isArray(result) && result.length > 0) return result;
    }
    const program = LS.get('program');
    if (!program || !program.days) return [];
    const today = new Date().getDay();
    const dayInfo = program.days[today];
    return dayInfo?.exercises || [];
  } catch (e) { return []; }
}

// ── เริ่ม Combat Session ────────────────────────────────
function startCombatSession(plan) {
  const exercises = plan || getTodayProgram();
  if (!exercises || !exercises.length) {
    showToast('ไม่มีโปรแกรมวันนี้');
    return;
  }
  CombatSession.active    = true;
  CombatSession.exercises = exercises;
  CombatSession.index     = 0;
  CombatSession.set       = 1;
  CombatSession.startedAt = Date.now();
  CombatSession.totalVolume = 0;

  const overlay = document.getElementById('combat-overlay');
  if (overlay) overlay.classList.remove('hidden');

  renderCombat();
  Haptic?.heavy?.();
}
window.startCombatSession = startCombatSession;

// ── ปุ่ม "เริ่มฝึกวันนี้" เชื่อม Combat ─────────────────
function startWorkoutSession() {
  const plan = getTodayProgram();
  startCombatSession(plan);
}
window.startWorkoutSession = startWorkoutSession;

// ── Render ท่าปัจจุบัน + RPG ───────────────────────────
function renderCombat() {
  const ex = CombatSession.exercises[CombatSession.index];
  if (!ex) return;

  const nameEl  = document.getElementById('combat-exercise');
  const setEl   = document.getElementById('combat-set');
  const progEl  = document.getElementById('combat-progression');
  const readEl  = document.getElementById('combat-readiness');
  const totalEl = document.getElementById('combat-total');

  if (nameEl) nameEl.textContent = ex.name || ex.exercise || 'Exercise';
  if (setEl)  setEl.textContent  = `SET ${CombatSession.set} / ${ex.sets || 3}`;

  if (totalEl) {
    const total = CombatSession.exercises.length;
    const done  = CombatSession.index;
    totalEl.textContent = `${done}/${total} ท่า`;
  }

  if (window.OPERATOR_ENGINE) {
    if (progEl) {
      try {
        const prog = OPERATOR_ENGINE.getProgression(ex.name || ex.exercise || '');
        const sug  = prog?.suggestion || prog?.advice || '';
        progEl.textContent = sug;
        progEl.style.color = sug.includes('⬆') ? '#2ecc71' : '#aaa';
      } catch(e) { progEl.textContent = ''; }
    }
    if (readEl) {
      try {
        const r = OPERATOR_ENGINE.getReadinessLabel();
        readEl.textContent = r?.label || '';
        readEl.style.color = r?.color || '#aaa';
      } catch(e) {}
    }
  }

  // Fatigue Color System
  try {
    if (window.OPERATOR_ENGINE) {
      const state = OPERATOR_ENGINE.state || {};
      const fatigue = state.fatigue || state.overallFatigue || 0;
      const _co = document.getElementById('combat-overlay'); if (_co) _co.style.filter =
        fatigue > 70 ? 'contrast(1.1) hue-rotate(-10deg)' : '';
    }
  } catch(e) {}
}

// ── จบเซ็ต ──────────────────────────────────────────────
function combatFinishSet() {
  const ex = CombatSession.exercises[CombatSession.index];
  if (!ex) return;

  // สะสม volume
  const reps   = parseInt(ex.reps) || 10;
  const weight = parseFloat(ex.weight) || 0;
  CombatSession.totalVolume += reps * (weight || 1);

  const totalSets = parseInt(ex.sets) || 3;

  if (CombatSession.set < totalSets) {
    CombatSession.set++;
    startCombatRest(parseRest(ex.rest));
  } else {
    combatNext();
  }

  renderCombat();
  Haptic?.medium?.();
}
window.combatFinishSet = combatFinishSet;

// ── Timer พัก ───────────────────────────────────────────
function startCombatRest(seconds) {
  CombatSession.restLeft = seconds;
  const el = document.getElementById('combat-timer');
  const barEl = document.getElementById('combat-rest-bar');

  clearInterval(CombatSession.timer);

  CombatSession.timer = setInterval(() => {
    CombatSession.restLeft--;
    if (el) el.textContent = CombatSession.restLeft;
    if (barEl) {
      const pct = (CombatSession.restLeft / seconds) * 100;
      barEl.style.width = pct + '%';
      barEl.style.background = pct > 50 ? '#2ecc71' : pct > 20 ? '#f39c12' : '#e74c3c';
    }
    if (CombatSession.restLeft <= 0) {
      clearInterval(CombatSession.timer);
      navigator.vibrate?.(200);
      showToast('🔥 พร้อมลุยต่อ!', 'success');
      Haptic?.success?.();
    }
  }, 1000);
}

// ── ข้ามท่า ─────────────────────────────────────────────
function combatSkip() {
  clearInterval(CombatSession.timer);
  combatNext();
  Haptic?.light?.();
}
window.combatSkip = combatSkip;

// ── ไปท่าถัดไป ──────────────────────────────────────────
function combatNext() {
  CombatSession.index++;
  if (CombatSession.index >= CombatSession.exercises.length) {
    combatEnd();
    return;
  }
  CombatSession.set = 1;
  clearInterval(CombatSession.timer);
  const _ct = document.getElementById('combat-timer'); if (_ct) _ct.textContent = '0';
  renderCombat();
}
window.combatNext = combatNext;

// ── จบ Session ──────────────────────────────────────────
function combatEnd() {
  clearInterval(CombatSession.timer);
  let xpGained = 0;

  if (window.OPERATOR_ENGINE) {
    try {
      const result = OPERATOR_ENGINE.logWorkout(CombatSession.exercises);
      xpGained = result?.xpGained || result?.xp || 0;
      LS.set('xp', OPERATOR_ENGINE.state?.xp || 0);
    } catch(e) {}
  }

  const overlay = document.getElementById('combat-overlay');
  if (overlay) overlay.classList.add('hidden');

  CombatSession.active = false;

  // Mission Summary
  const duration = Math.round((Date.now() - CombatSession.startedAt) / 60000);
  showCombatSummary({
    volume: CombatSession.totalVolume,
    xp: xpGained,
    duration,
    exercises: CombatSession.exercises.length,
  });

  renderTopBar?.();
  renderDashboardSafe?.();
}
window.combatEnd = combatEnd;

// ── Mission Summary Popup ───────────────────────────────
function showCombatSummary({ volume, xp, duration, exercises }) {
  const existing = document.getElementById('combat-summary');
  if (existing) existing.remove();

  const el = document.createElement('div');
  el.id = 'combat-summary';
  el.innerHTML = `
    <div class="combat-summary-box">
      <div class="cs-title">⚔ MISSION COMPLETE</div>
      <div class="cs-rows">
        <div class="cs-row"><span>Session Volume</span><span>${volume.toLocaleString()}</span></div>
        <div class="cs-row"><span>XP Gained</span><span class="cs-xp">+${xp}</span></div>
        <div class="cs-row"><span>Duration</span><span>${duration} min</span></div>
        <div class="cs-row"><span>Exercises</span><span>${exercises} ท่า</span></div>
      </div>
      <button onclick="document.getElementById('combat-summary').remove()" class="cs-close">CLOSE</button>
    </div>
  `;
  document.body.appendChild(el);
  Haptic?.success?.();
}


/* ================================================================
   MISSING FUNCTIONS — referenced in index.html but not defined
   Added: analyzeAndAdjustProgram, aiAnalyzeFatigue,
          aiAnalyzeProgress, aiSuggestNextWeek, generateYearProgram
   ================================================================ */

function analyzeAndAdjustProgram() {
  if (_chatCalling) { showToast('⏳ AI กำลังตอบอยู่...'); return; }
  const log     = LS.get('workoutLog') || [];
  const recent  = log.slice(-7);
  const oe      = window.OPERATOR_ENGINE;
  const fatigue = oe ? JSON.stringify(oe.state.fatigue || {}) : '{}';
  const plan    = LS.get('currentProgram') || 'ไม่มีโปรแกรม';
  const prompt  = `วิเคราะห์ Training Log 7 วันล่าสุดนี้:\n${JSON.stringify(recent, null, 2)}\n\nFatigue ปัจจุบัน: ${fatigue}\nโปรแกรมปัจจุบัน: ${JSON.stringify(plan)}\n\nช่วยวิเคราะห์และแนะนำการปรับโปรแกรมที่เหมาะสมกับสภาพจริง เน้นภาษาไทย กระชับ`;
  const input = document.getElementById('chat-input');
  if (input) input.value = prompt;
  sendChat();
}

function aiAnalyzeFatigue() {
  if (_chatCalling) { showToast('⏳ AI กำลังตอบอยู่...'); return; }
  const oe      = window.OPERATOR_ENGINE;
  const fatigue = oe ? oe.state.fatigue : LS.get('fatigue') || {};
  const readiness = oe ? Math.round(oe.state.readiness || 80) : LS.get('readiness') || 80;
  let cfiInfo = '';
  if (window.CFIEngine) {
    const cfi = CFIEngine.calculate();
    cfiInfo = `\nChronic Fatigue Index: ${cfi.cfi} (${cfi.trend}), Readiness Cap: ${cfi.readinessCap}`;
  }
  let acwrInfo = '';
  if (window.ACWREngine) {
    const acwr = ACWREngine.calculate();
    acwrInfo = `\nACWR: ${acwr.ratio?.toFixed(2)} (${acwr.zone})`;
  }
  const prompt = `วิเคราะห์ความล้าของฉัน:\nFatigue per muscle: ${JSON.stringify(fatigue)}\nReadiness: ${readiness}%${cfiInfo}${acwrInfo}\n\nอธิบายสถานะความล้าแต่ละกล้ามเนื้อ และแนะนำว่าควรฝึกหรือพักอะไรบ้าง ภาษาไทย`;
  const input = document.getElementById('chat-input');
  if (input) input.value = prompt;
  sendChat();
}

function aiAnalyzeProgress() {
  if (_chatCalling) { showToast('⏳ AI กำลังตอบอยู่...'); return; }
  const oe    = window.OPERATOR_ENGINE;
  const xp    = LS.get('xp') || 0;
  const level = LS.get('level') || 1;
  const streak = LS.get('streak') || 0;
  let strengthInfo = '';
  if (window.StrengthCurve) {
    try {
      const curves = StrengthCurve.modelAll().slice(0, 5);
      strengthInfo = `\nStrength Curves: ${JSON.stringify(curves.map(c => ({ name: c.name, slope: c.slope?.toFixed(3), velocity: c.velocity })))}`;
    } catch(e) {}
  }
  let hyp = '';
  if (window.HypertrophyEngine) {
    const muscles = ['chest','back','legs','shoulders','arms','core'];
    hyp = `\nHypertrophy: ${JSON.stringify(muscles.map(m => ({ muscle: m, ...HypertrophyEngine.getStatus(m) })))}`;
  }
  const prompt = `วิเคราะห์ความก้าวหน้าการฝึกของฉัน:\nLevel: ${level}, XP: ${xp}, Streak: ${streak} วัน${strengthInfo}${hyp}\n\nสรุป progress ที่เห็นได้ชัด จุดแข็ง จุดที่ต้องพัฒนา และเป้าหมาย 4 สัปดาห์ถัดไป ภาษาไทย`;
  const input = document.getElementById('chat-input');
  if (input) input.value = prompt;
  sendChat();
}

function aiSuggestNextWeek() {
  if (_chatCalling) { showToast('⏳ AI กำลังตอบอยู่...'); return; }
  let planInfo = { block: 'BALANCED', rationale: [] };
  if (window.WeeklyPlanner) {
    try { planInfo = WeeklyPlanner.plan(); } catch(e) {}
  }
  const readiness = window.OPERATOR_ENGINE ? Math.round(OPERATOR_ENGINE.state.readiness || 80) : 80;
  const prompt    = `วางแผนการฝึกสัปดาห์หน้า:\nAI แนะนำ Block: ${planInfo.block}\nเหตุผล: ${(planInfo.rationale || []).join(', ')}\nReadiness ปัจจุบัน: ${readiness}%\nVolume Mod: ${planInfo.volumeMod || 1}, Intensity Mod: ${planInfo.intensityMod || 0.8}\nRPE Target: ${planInfo.rpeTarget || '7-8'}, วัน/สัปดาห์: ${planInfo.daysPerWeek || 4}\n\nสร้างตารางฝึกสัปดาห์หน้าที่เหมาะกับสถานะนี้ แบบละเอียด ภาษาไทย`;
  const input = document.getElementById('chat-input');
  if (input) input.value = prompt;
  sendChat();
}

function generateYearProgram() {
  if (_chatCalling) { showToast('⏳ AI กำลังตอบอยู่...'); return; }
  const goal    = LS.get('goal') || 'general fitness';
  const level   = LS.get('level') || 1;
  const equip   = LS.get('equipment') || [];
  let roadmap   = '';
  // Use 12-month roadmap phases from blueprint
  const phases = [
    'Phase 1 (เดือน 1–3): Calibration — เรียนรู้ baseline, MEV, unlock Tier 2',
    'Phase 2 (เดือน 4–6): Volume Experimentation — progressive overload, first cert attempt',
    'Phase 3 (เดือน 7–9): Peak Specialization — intensity blocks, injury-free consistency',
    'Phase 4 (เดือน 10–12): Performance Peak — certification, optimize TPS+',
  ];
  roadmap = phases.join('\n');
  const prompt = `สร้างโปรแกรมฝึก 12 เดือน สำหรับ:\nเป้าหมาย: ${goal}\nLevel ปัจจุบัน: ${level}\nอุปกรณ์: ${Array.isArray(equip) ? equip.join(', ') : equip}\n\nกรอบ Roadmap:\n${roadmap}\n\nสร้าง overview แต่ละ phase พร้อม focus, volume, intensity และ milestone ที่วัดได้ ภาษาไทย`;
  const input = document.getElementById('chat-input');
  if (input) input.value = prompt;
  sendChat();
}
