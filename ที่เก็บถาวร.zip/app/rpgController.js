/* ================================================================
   RPG CONTROLLER — rpgController.js
   Operator Military RPG — UI + Integration Layer

   Ties together:
   - ConversionEngine (physical → stat deltas)
   - AttributeEngine (stat storage + levels)
   - RankSystem (military rank progression)
   - MedalSystem (achievements)

   Hooks into existing saveWorkout() flow.
   Renders Character Sheet UI.
   ================================================================ */
'use strict';

const RPGController = (() => {

  /* ----------------------------------------------------------
     PROCESS SESSION — called after saveWorkout()
  ---------------------------------------------------------- */
  function processSession(exercises = [], workoutType = 'fullbody', formScore = null) {
    if (!window.ConversionEngine || !window.AttributeEngine || !window.RankSystem || !window.MedalSystem) {
      console.warn('[RPGController] Engines not loaded yet');
      return null;
    }

    // 1. Convert physical → stat deltas
    const { deltas, report, flagged } = ConversionEngine.sessionToStats(exercises, workoutType, formScore);

    // 2. Apply deltas to attribute storage
    const { stats, changes } = AttributeEngine.applyDeltas(deltas);

    // 3. Streak → Discipline
    const streak = parseInt(localStorage.getItem('streak') || '0', 10);
    AttributeEngine.applyStreakDisc(streak);

    // 4. Get readiness data for Stamina calc
    try {
      if (window.OPERATOR_ENGINE) {
        const engineState = OPERATOR_ENGINE.state;
        const staDelta = ConversionEngine.recoveryToSta(
          engineState.readiness || 80,
          engineState.fatigue || 20
        );
        AttributeEngine.applyDeltas({ STA: staDelta });
      }
    } catch(e) {}

    // 5. Combat Power → Rank
    const cp = AttributeEngine.getCombatPower();
    const currentStats = AttributeEngine.getStats();
    const totalSessions = RankSystem.incrementSessions();
    const rankResult = RankSystem.evaluateRank(cp, currentStats, streak, totalSessions);

    // 6. Check missions
    const newMissions = RankSystem.checkMissions(currentStats, streak, totalSessions, cp);

    // 7. Update medals
    const rankData = RankSystem.getRankData();
    const { newMedals } = MedalSystem.updateCareer({
      exercises,
      streak,
      combatPower: cp,
      sfAchieved: rankData.sfAchieved || [],
    });

    // 8. Show notifications
    if (rankResult.promoted) {
      _showPromotion(rankResult.currentRank);
    }
    newMedals.forEach(medal => _showMedalToast(medal));
    newMissions.forEach(mission => _showMissionToast(mission));

    // 9. Build mission report (military theme)
    const reportSummary = _buildMissionReport(exercises, deltas, changes, flagged);

    // 10. Refresh character screen if visible
    setTimeout(() => renderCharacterScreen(), 300);

    return {
      deltas, changes, cp,
      rank: rankResult.currentRank,
      promoted: rankResult.promoted,
      newMedals, newMissions,
      report: reportSummary,
    };
  }

  /* ----------------------------------------------------------
     MISSION REPORT — military-themed session summary
  ---------------------------------------------------------- */
  function _buildMissionReport(exercises, deltas, changes, flagged) {
    const lines = ['━━━━ MISSION REPORT ━━━━'];
    exercises.forEach(ex => {
      const parts = [];
      if (ex.sets && ex.reps) parts.push(`${ex.sets}×${ex.reps}`);
      if (ex.weight) parts.push(`${ex.weight}kg`);
      if (ex.distance) parts.push(`${ex.distance}km`);
      if (ex.duration) parts.push(`${ex.duration}min`);
      lines.push(`  ${ex.name || 'Exercise'}: ${parts.join(' ')}`);
    });
    if (flagged > 0) lines.push(`  ⚠️ ${flagged} exercise(s) flagged (reduced XP)`);
    lines.push('');
    lines.push('STAT GAINS:');

    const statMeta = ConversionEngine.STAT_META;
    Object.entries(deltas).forEach(([k, v]) => {
      if (v > 0) {
        const meta = statMeta[k];
        lines.push(`  ${meta.icon} ${meta.label}: +${v.toFixed(1)} pts`);
      }
    });

    lines.push('');
    lines.push(`CP: ${AttributeEngine.getCombatPower().toLocaleString()}`);
    lines.push('━━━━━━━━━━━━━━━━━━━━━━━━');
    return lines.join('\n');
  }

  /* ----------------------------------------------------------
     RENDER CHARACTER SCREEN
  ---------------------------------------------------------- */
  function renderCharacterScreen() {
    if (!window.ConversionEngine || !window.AttributeEngine || !window.RankSystem) return;

    const display  = AttributeEngine.getDisplay();
    const cp       = AttributeEngine.getCombatPower();
    const streak   = parseInt(localStorage.getItem('streak') || '0', 10);
    const rankState= RankSystem.getState();
    const medals   = MedalSystem.getMedalDisplay();
    const rank     = rankState.currentRank;
    const nextRank = rankState.allRanks[Math.min(rank.id + 1, rankState.allRanks.length - 1)];

    // Rank banner
    _el('char-rank-emoji').textContent  = rank.emoji || '👤';
    _el('char-rank-name').textContent   = rank.nameThai;
    _el('char-rank-nato').textContent   = rank.nameNato;
    _el('char-cp-value').textContent    = cp.toLocaleString();

    // Rank progress bar
    if (nextRank && nextRank.cpRequired > rank.cpRequired) {
      const pct = Math.min(100, Math.round(
        ((cp - rank.cpRequired) / (nextRank.cpRequired - rank.cpRequired)) * 100
      ));
      _elStyle('char-rank-fill').width = pct + '%';
      const needed = Math.max(0, nextRank.cpRequired - cp);
      _el('char-rank-next').textContent = `ต้องการ ${needed.toLocaleString()} CP → ${nextRank.nameThai}`;
    } else {
      _elStyle('char-rank-fill').width = '100%';
      _el('char-rank-next').textContent = '🌟 ยศสูงสุด';
    }

    // Stat list
    _renderStatList(display);

    // Radar chart
    _renderRadarChart(display);

    // Readiness
    _renderReadiness();

    // Streak
    _el('char-streak-count').textContent = streak;

    // Daily quests (pull from existing missions)
    _renderDailyQuests();

    // Medals
    _renderMedals(medals);

    // SF Tiers
    _renderSFTiers(rankState.sfTiers);
  }

  /* ----------------------------------------------------------
     STAT LIST — Lv.12 · 847 pts format
  ---------------------------------------------------------- */
  function _renderStatList(display) {
    const container = _el('char-stat-list');
    if (!container) return;

    container.innerHTML = Object.values(display).map(s => `
      <div class="char-stat-row">
        <span class="char-stat-icon">${s.icon}</span>
        <span class="char-stat-label">${s.label}</span>
        <div class="char-stat-bar-wrap">
          <div class="char-stat-bar-fill" style="width:${s.pct}%;background:${s.color}"></div>
        </div>
        <span class="char-stat-value">${s.displayText}</span>
      </div>
    `).join('');
  }

  /* ----------------------------------------------------------
     RADAR CHART — Canvas-based hexagon
  ---------------------------------------------------------- */
  function _renderRadarChart(display) {
    const canvas = document.getElementById('char-radar-chart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const keys = ['STR', 'END', 'SPD', 'POW', 'DISC', 'PRC', 'STA'];
    const W = canvas.width, H = canvas.height;
    const cx = W / 2, cy = H / 2;
    const maxR = Math.min(W, H) / 2 - 24;

    ctx.clearRect(0, 0, W, H);

    // Background grid
    const levels = 5;
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let l = 1; l <= levels; l++) {
      ctx.beginPath();
      keys.forEach((_, i) => {
        const angle = (Math.PI * 2 * i / keys.length) - Math.PI / 2;
        const r = (maxR * l) / levels;
        const x = cx + r * Math.cos(angle);
        const y = cy + r * Math.sin(angle);
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      });
      ctx.closePath();
      ctx.stroke();
    }

    // Spokes
    ctx.strokeStyle = '#334155';
    keys.forEach((_, i) => {
      const angle = (Math.PI * 2 * i / keys.length) - Math.PI / 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + maxR * Math.cos(angle), cy + maxR * Math.sin(angle));
      ctx.stroke();
    });

    // Data polygon
    const maxLevel = 30; // visual max level for chart
    ctx.beginPath();
    keys.forEach((k, i) => {
      const lv = Math.min(display[k]?.level || 1, maxLevel);
      const r = (maxR * lv) / maxLevel;
      const angle = (Math.PI * 2 * i / keys.length) - Math.PI / 2;
      const x = cx + r * Math.cos(angle);
      const y = cy + r * Math.sin(angle);
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.fillStyle = 'rgba(239,68,68,0.15)';
    ctx.fill();
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Labels
    ctx.font = 'bold 11px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    keys.forEach((k, i) => {
      const angle = (Math.PI * 2 * i / keys.length) - Math.PI / 2;
      const r = maxR + 16;
      const x = cx + r * Math.cos(angle);
      const y = cy + r * Math.sin(angle);
      const meta = ConversionEngine.STAT_META[k];
      ctx.fillStyle = meta?.color || '#fff';
      ctx.fillText(meta?.icon || k, x, y);
    });
  }

  /* ----------------------------------------------------------
     READINESS RING
  ---------------------------------------------------------- */
  function _renderReadiness() {
    let readiness = 100;
    try {
      if (window.OPERATOR_ENGINE) readiness = Math.round(OPERATOR_ENGINE.state.readiness || 100);
    } catch {}

    const valEl = _el('char-readiness-val');
    const arcEl = document.getElementById('char-readiness-arc');
    const advEl = _el('char-readiness-advice');
    if (!valEl || !arcEl) return;

    valEl.textContent = readiness;
    const circumference = 201;
    const offset = circumference - (circumference * readiness / 100);
    arcEl.style.strokeDashoffset = offset;
    arcEl.style.stroke = readiness >= 70 ? '#2ecc71' : readiness >= 40 ? '#f59e0b' : '#ef4444';

    if (advEl) {
      advEl.textContent = readiness >= 80 ? 'พร้อมเต็มที่' :
                          readiness >= 60 ? 'ฝึกได้ปกติ' :
                          readiness >= 40 ? 'ฝึกเบา' : 'พักก่อน';
    }
  }

  /* ----------------------------------------------------------
     DAILY QUESTS (compact)
  ---------------------------------------------------------- */
  function _renderDailyQuests() {
    const container = _el('char-daily-quests');
    if (!container) return;

    const quests = [
      { label: 'บันทึก session วันนี้', done: _workoutTodayDone() },
      { label: 'รักษา streak', done: (parseInt(localStorage.getItem('streak') || '0') > 0) },
      { label: 'อัปเดตน้ำหนัก', done: false },
    ];

    container.innerHTML = quests.map(q => `
      <div class="char-quest-row ${q.done ? 'done' : ''}">
        <span class="char-quest-check">${q.done ? '✅' : '⬜'}</span>
        <span>${q.label}</span>
      </div>
    `).join('');
  }

  function _workoutTodayDone() {
    const lastDate = localStorage.getItem('lastWorkoutDate');
    const today = new Date().toISOString().split('T')[0];
    return lastDate === today;
  }

  /* ----------------------------------------------------------
     MEDALS
  ---------------------------------------------------------- */
  function _renderMedals(medals) {
    const container = _el('char-medals');
    if (!container) return;

    container.innerHTML = medals.map(m => `
      <div class="char-medal ${m.earned ? 'earned' : 'locked'}" title="${m.desc}">
        <div class="char-medal-icon" style="opacity:${m.earned ? 1 : 0.25}">${m.icon}</div>
        <div class="char-medal-label">${m.labelThai || m.label}</div>
        ${m.earned ? `<div class="char-medal-date">${m.earnedDate ? new Date(m.earnedDate).toLocaleDateString('th-TH') : ''}</div>` : ''}
      </div>
    `).join('');
  }

  /* ----------------------------------------------------------
     SF TIERS
  ---------------------------------------------------------- */
  function _renderSFTiers(sfTiers) {
    const container = _el('char-sf-tiers');
    if (!container) return;

    container.innerHTML = sfTiers.map(tier => `
      <div class="char-sf-tier ${tier.achieved ? 'achieved' : ''}">
        <div class="char-sf-header">
          <span class="char-sf-flag">${tier.flag}</span>
          <div>
            <div class="char-sf-name" style="color:${tier.color}">${tier.labelThai}</div>
            <div class="char-sf-progress-text">${tier.progress} ผ่าน</div>
          </div>
          ${tier.achieved ? '<span class="char-sf-badge">✅ ผ่านแล้ว</span>' : ''}
        </div>
        <div class="char-sf-checks">
          ${Object.values(tier.checkResults).map(c => `
            <div class="char-sf-check ${c.passed ? 'pass' : 'fail'}">
              ${c.passed ? '✅' : '⬜'} ${c.label}
              ${c.value !== undefined ? `<span class="char-sf-val">(${c.value})</span>` : ''}
            </div>
          `).join('')}
        </div>
      </div>
    `).join('');
  }

  /* ----------------------------------------------------------
     SUBMIT PHYSICAL TEST (called from HTML)
  ---------------------------------------------------------- */
  window.submitPhysicalTest = function() {
    if (!window.RankSystem) return;
    const tests = [
      { key: 'pushup_max',  id: 'test-pushup',  label: 'Push-up' },
      { key: 'pullup_max',  id: 'test-pullup',  label: 'Pull-up' },
      { key: 'run_2km_min', id: 'test-run2km',  label: 'วิ่ง 2.4km' },
      { key: 'run_5km_min', id: 'test-run5km',  label: 'วิ่ง 5km' },
      { key: 'plank_min',   id: 'test-plank',   label: 'Plank' },
    ];

    let updated = 0;
    tests.forEach(t => {
      const el = document.getElementById(t.id);
      const val = parseFloat(el?.value);
      if (!isNaN(val) && val > 0) {
        RankSystem.recordPhysicalTest(t.key, val);
        updated++;
      }
    });

    if (updated > 0) {
      if (typeof showToast === 'function') showToast(`✅ บันทึกผลทดสอบ ${updated} รายการ`);
      renderCharacterScreen();
      // Clear inputs
      tests.forEach(t => {
        const el = document.getElementById(t.id);
        if (el) el.value = '';
      });
    } else {
      if (typeof showToast === 'function') showToast('⚠️ กรุณากรอกผลทดสอบอย่างน้อย 1 รายการ');
    }
  };

  /* ----------------------------------------------------------
     NOTIFICATION HELPERS
  ---------------------------------------------------------- */
  function _showPromotion(rank) {
    const msg = `🎖️ เลื่อนยศ! ${rank.nameThai} (${rank.nameNato})`;
    if (typeof showToast === 'function') showToast(msg);
    console.log('[RPG] Rank promotion:', msg);
  }

  function _showMedalToast(medal) {
    if (typeof showToast === 'function') showToast(`${medal.icon} เหรียญ: ${medal.labelThai || medal.label}`);
  }

  function _showMissionToast(mission) {
    if (typeof showToast === 'function') showToast(`✅ ภารกิจ: ${mission.label}`);
  }

  /* ----------------------------------------------------------
     HELPERS
  ---------------------------------------------------------- */
  function _el(id) { return document.getElementById(id); }
  function _elStyle(id) { const el = _el(id); return el ? el.style : {}; }

  /* ----------------------------------------------------------
     HOOK INTO EXISTING saveWorkout
     Patch after DOM + engines ready
  ---------------------------------------------------------- */
  function hookIntoSaveWorkout() {
    if (typeof window.saveWorkout !== 'function') {
      setTimeout(hookIntoSaveWorkout, 500);
      return;
    }

    const originalSaveWorkout = window.saveWorkout;
    window.saveWorkout = async function(...args) {
      const result = await originalSaveWorkout.apply(this, args);

      // Extract exercises from current form
      try {
        const entries = [...document.querySelectorAll('.exercise-entry')];
        const typeEl  = document.getElementById('wk-type');
        const workoutType = typeEl?.value || 'fullbody';

        const exercises = entries.map(e => {
          const selects = e.querySelectorAll('select');
          const inputs  = e.querySelectorAll('input');
          return {
            name:     selects[0]?.value || 'Exercise',
            sets:     Number(inputs[0]?.value || 1),
            reps:     Number(inputs[1]?.value || 10),
            weight:   Number(inputs[2]?.value || 0),
            distance: 0,
            duration: 0,
          };
        });

        // Ask form score if cardio/flexibility
        const formScore = null; // Can add prompt later

        setTimeout(() => {
          RPGController.processSession(exercises, workoutType, formScore);
        }, 200);

      } catch(e) {
        console.warn('[RPGController] Hook error:', e);
      }

      return result;
    };

    console.log('[RPGController] ✅ saveWorkout hooked');
  }

  /* ----------------------------------------------------------
     INIT
  ---------------------------------------------------------- */
  function init() {
    // Hook saveWorkout after page loads
    if (document.readyState === 'complete') {
      setTimeout(hookIntoSaveWorkout, 1000);
    } else {
      window.addEventListener('load', () => setTimeout(hookIntoSaveWorkout, 1000));
    }

    // Initial render of character screen
    window.addEventListener('load', () => {
      setTimeout(renderCharacterScreen, 1500);
    });

    // Render when tab is switched to character
    const origGoTo = window.goTo;
    if (typeof origGoTo === 'function') {
      window.goTo = function(tab, ...args) {
        origGoTo.call(this, tab, ...args);
        if (tab === 'character') setTimeout(renderCharacterScreen, 100);
      };
    } else {
      // Fallback: patch after load
      window.addEventListener('load', () => {
        setTimeout(() => {
          const origGoTo2 = window.goTo;
          if (typeof origGoTo2 === 'function') {
            window.goTo = function(tab, ...args) {
              origGoTo2.call(this, tab, ...args);
              if (tab === 'character') setTimeout(renderCharacterScreen, 100);
            };
          }
        }, 2000);
      });
    }
  }

  init();

  /* ----------------------------------------------------------
     PUBLIC API
  ---------------------------------------------------------- */
  return {
    processSession,
    renderCharacterScreen,
  };

})();

if (typeof module !== 'undefined') module.exports = RPGController;
