/* ==========================================================
   OPERATOR PRODUCTION ENGINE FINAL  —  engine.js
   Architecture: Central Store + Exponential Recovery
                 + Volume Tracking + Periodization
                 + Non-linear XP + Performance Rank
                 + Debug Mode + Clean Modular Structure

   ✅ PATCHED v1.2 (hotfix)
   FIX 1: addXP() — while (multi-level-up support)
   FIX 2: aiAdjustBeforeGenerate() — null-safe API key
   FIX 3: weeklyAdjust() — removed duplicate volume reset
   HF-4:  applyTimeRecovery() — cap hours ≤ 240 ป้องกัน exponent ขนาดใหญ่
   HF-2:  _engineTick — guard ซ้ำซ้อน (clearInterval ก่อนสร้างทุกครั้ง)
   ========================================================== */
'use strict';

/* ============================================================
   CENTRAL DATA STORE
   ============================================================ */

const Store = {

  _BASE_KEY: 'operator_production_v1',

  get KEY() {
    const id = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
             || localStorage.getItem('operator_active_profile');
    return id ? `operator_production_${id}` : this._BASE_KEY;
  },

  load() {
    try {
      const raw = localStorage.getItem(this.KEY);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  },

  save(data) {
    try {
      data.lastUpdate = Date.now();
      localStorage.setItem(this.KEY, JSON.stringify(data));
    } catch (e) {
      // FIX [High]: log save failures instead of silent catch
      if (typeof Logger !== 'undefined') Logger.saveFail('Store', e);
      else console.warn('[Store] Save failed:', e?.message);
    }
  },

  update(fn) {
    let current = this.load();

    // Fix 2.1: validate loaded state — {} is truthy but may be empty/corrupted
    if (current !== null && typeof current === 'object') {
      if (typeof SafeNumber !== 'undefined') {
        const { state: sanitized, repaired } = SafeNumber.sanitizeEngineState(current);
        if (repaired.length > 0 && typeof Logger !== 'undefined') {
          Logger.warn('Store', 'State repaired on load:', repaired);
        }
        current = sanitized || current;
      }
      // Check has required fields — if not, treat as missing
      // FIX [CRITICAL]: operator precedence bug — !current.xp === undefined is always false
      // Original: (!current.xp === undefined) evaluates (!current.xp) first then compares to undefined
      // Correct check: treat missing required fields as invalid state
      if (current.xp === undefined || current.level === undefined) {
        current = null;
      }
    }

    const state = current || Engine.initState();
    // FIX [High]: deep clone before passing to fn() to prevent unintended reference mutation
    const stateCopy = (typeof structuredClone === 'function')
      ? structuredClone(state)
      : JSON.parse(JSON.stringify(state));
    const next  = fn(stateCopy);
    this.save(next);
    return next;
  },

  migrate() {
    if (this.load()) return;

    const legacyKeys = ['engine_v3', 'operator_engine_v2'];
    for (const k of legacyKeys) {
      try {
        const raw = localStorage.getItem(k);
        if (raw) {
          const old = JSON.parse(raw);
          const migrated = Engine.initState();
          migrated.xp               = old.xp               || 0;
          migrated.totalVolume      = old.totalVolume       || 0;
          migrated.streak           = old.streak            || 0;
          migrated.workoutsCompleted= old.workoutsCompleted || 0;
          migrated.lastWorkoutDate  = old.lastWorkoutDate   || null;
          migrated.weekNumber       = old.weekNumber        || 1;
          if (old.fatigue) Object.assign(migrated.fatigue, old.fatigue);
          this.save(migrated);
          console.log(`[Store] Migrated from legacy key: ${k}`);
          return;
        }
      } catch {}
    }
  },
};

/* ============================================================
   PRODUCTION ENGINE
   ============================================================ */

class ProductionEngine {

  constructor() {
    Store.migrate();
    let loaded = Store.load();

    // Fix 1.1: validate + repair corrupted state on load
    if (loaded) {
      if (typeof SafeNumber !== 'undefined') {
        const { state: sanitized, repaired } = SafeNumber.sanitizeEngineState(loaded);
        if (repaired.length > 0) {
          if (typeof Logger !== 'undefined') {
            Logger.warn('ProductionEngine', 'State repaired:', repaired);
          }
        }
        loaded = sanitized || loaded;
      }
      // Check minimum viable state
      if (typeof loaded.xp === 'undefined' || typeof loaded.level === 'undefined') {
        loaded = null;
      }
    }

    this.state = loaded || this.initState();
    this.applyTimeRecovery();
  }

  /* ----------------------------------------------------------
     STATE SCHEMA
     ---------------------------------------------------------- */
  initState() {
    const muscles = ['chest', 'back', 'legs', 'shoulders', 'arms', 'core'];
    const fatigue      = {};
    const weeklyVolume = {};
    const exerciseHistory = {};

    muscles.forEach(m => {
      fatigue[m]      = 0;
      weeklyVolume[m] = 0;
    });

    return {
      xp:                0,
      level:             1,
      totalVolume:       0,
      weeklyVolume,
      fatigue,
      readiness:         100,
      streak:            0,
      workoutsCompleted: 0,
      lastWorkoutDate:   null,
      weekNumber:        1,
      phaseIndex:        0,
      exerciseHistory,
      lastUpdate:        Date.now(),
    };
  }

  /* ----------------------------------------------------------
     RECOVERY MODEL  —  Exponential Decay
     [HF-4] เพิ่ม cap hours ≤ 240 ป้องกัน Math.pow ค่ามหาศาล
            เมื่อ lastUpdate เสียหายหรือ app ไม่ได้เปิดนาน
     ---------------------------------------------------------- */
  applyTimeRecovery() {
    const now = Date.now();

    // [HF-4] cap rawHours สูงสุด 240 ชั่วโมง (10 วัน)
    //        Math.pow(0.95, 5000) ≈ 0 แต่ยังกิน CPU ระหว่างคำนวณ
    //        ถ้า lastUpdate เสียหาย hours จะเป็น NaN/Infinity → ป้องกันทั้งหมด
    const rawHours = (now - (this.state.lastUpdate || now)) / 3_600_000;
    const hours    = Math.min(Math.max(0, isFinite(rawHours) ? rawHours : 0), 240);

    if (hours < 0.05) return;

    const DECAY_RATE = 0.05;

    Object.keys(this.state.fatigue).forEach(m => {
      const decay = this.state.fatigue[m] * (1 - Math.pow(1 - DECAY_RATE, hours));
      this.state.fatigue[m] = Math.max(0, this.state.fatigue[m] - decay);
    });

    this.calculateReadiness();
    this.state.lastUpdate = now;
    Store.save(this.state);
  }

  triggerRecovery() { this.applyTimeRecovery(); }

  /* ----------------------------------------------------------
     READINESS
     ---------------------------------------------------------- */
  calculateReadiness() {
    const values = Object.values(this.state.fatigue);
    // FIX [Critical]: guard division by zero when fatigue object is empty → NaN cascade
    if (!values.length) { this.state.readiness = 100; return; }
    const sum = values.reduce((a, b) => {
      const bSafe = (isFinite(b) && !isNaN(b)) ? b : 0;
      return a + bSafe;
    }, 0);
    const avg = sum / values.length;
    this.state.readiness = Math.max(0, Math.min(100, 100 - avg));
  }

  getReadiness() { return Math.round(this.state.readiness); }

  getReadinessLabel() {
    const r = this.state.readiness;
    if (r >= 80) return { label: '🟢 พร้อมเต็มที่',    color: '#2ecc71', advice: 'ฝึกหนักได้เต็มที่เลย!' };
    if (r >= 60) return { label: '🟡 พร้อมปานกลาง',   color: '#f1c40f', advice: 'ฝึกได้ปกติ อย่าหักโหม' };
    if (r >= 40) return { label: '🟠 เหนื่อยสะสม',    color: '#e67e22', advice: 'ลด Volume 20% วันนี้' };
    return               { label: '🔴 ล้ามาก — พัก!', color: '#e74c3c', advice: 'Active Recovery เท่านั้น' };
  }

  /* ----------------------------------------------------------
     WORKOUT LOGGING + VOLUME TRACKING
     ---------------------------------------------------------- */
  logWorkout(exercises) {
    if (!exercises || !exercises.length) return { xpGained: 0, rank: this.getRank() };

    let sessionVolume = 0;

    exercises.forEach(ex => {
      if (!this.validate(ex)) return;

      const sets   = Number(ex.sets)   || 0;
      const reps   = Number(ex.reps)   || 0;
      const weight = Number(ex.weight) > 0 ? Number(ex.weight) : 1;
      const vol    = sets * reps * weight;

      if (!isFinite(vol) || isNaN(vol)) return;

      sessionVolume            += vol;
      this.state.totalVolume   += vol;

      const muscle = ex.muscle || 'core';
      if (this.state.weeklyVolume[muscle] !== undefined)
        this.state.weeklyVolume[muscle] += vol;

      if (this.state.fatigue[muscle] !== undefined)
        this.state.fatigue[muscle] = Math.min(100, this.state.fatigue[muscle] + vol * 0.001);

      const name = (ex.name || 'unknown').toLowerCase().trim();
      if (!this.state.exerciseHistory[name]) this.state.exerciseHistory[name] = [];
      this.state.exerciseHistory[name].push({
        date: new Date().toISOString().split('T')[0], sets, reps, weight,
      });
      if (this.state.exerciseHistory[name].length > 20)
        this.state.exerciseHistory[name] = this.state.exerciseHistory[name].slice(-20);
    });

    this.state.workoutsCompleted++;
    this._updateStreak();
    const xpGained = this.addXP(sessionVolume);
    this.calculateReadiness();
    this.checkDeload();

    Store.save(this.state);
    return { sessionVolume, xpGained, rank: this.getRank() };
  }

  /* ----------------------------------------------------------
     VALIDATION
     ---------------------------------------------------------- */
  validate(ex) {
    const sets   = Number(ex.sets);
    const reps   = Number(ex.reps);
    const weight = Number(ex.weight);
    if (!isFinite(sets)   || sets   < 1 || sets   > 40)  return false;
    if (!isFinite(reps)   || reps   < 1 || reps   > 200) return false;
    if (!isFinite(weight) || weight < 0 || weight > 500)  return false;
    return true;
  }

  /* ----------------------------------------------------------
     PROGRESSIVE OVERLOAD SUGGESTION
     ---------------------------------------------------------- */
  suggestLoad(baseWeight, muscle) {
    const f = this.state.fatigue[muscle] || 0;
    const w = Number(baseWeight) || 0;
    if (f > 70) return +(w * 0.85).toFixed(1);
    if (f < 25) return +(w * 1.05).toFixed(1);
    return w;
  }

  getProgression(exerciseName) {
    const history = this.state.exerciseHistory[(exerciseName || '').toLowerCase()] || [];
    if (!history.length) return { sets: 3, reps: 10, weight: 0, suggestion: 'เริ่ม 3×10' };

    const last = history[history.length - 1];
    const prev = history.length >= 2 ? history[history.length - 2] : null;
    let suggestion = '';

    if (prev) {
      if (last.reps >= prev.reps + 2 && last.weight === prev.weight) {
        suggestion = `⬆️ เพิ่มน้ำหนักเป็น ${+(last.weight * 1.025).toFixed(1)} กก.`;
      } else if (last.reps < prev.reps - 1) {
        suggestion = '⬇️ ลดน้ำหนัก 10%';
      } else {
        suggestion = '📈 เพิ่ม 1 rep';
      }
    }
    return { sets: last.sets, reps: last.reps, weight: last.weight, suggestion };
  }

  /* ----------------------------------------------------------
     PERIODIZATION
     ---------------------------------------------------------- */
  getPhases() {
    return [
      { id: 1, name: 'Foundation',  nameTH: 'สร้างพื้นฐาน',     intensity: 0.65, sets: 3, reps: '12-15', restTime: '60s',  desc: 'Volume สูง Intensity ต่ำ สร้างฐานให้แข็งแรง' },
      { id: 2, name: 'Hypertrophy', nameTH: 'เพิ่มมวลกล้าม',    intensity: 0.75, sets: 4, reps: '8-12',  restTime: '90s',  desc: 'Volume สูงสุด Intensity ปานกลาง เน้นกล้ามโต' },
      { id: 3, name: 'Strength',    nameTH: 'เพิ่มความแข็งแรง', intensity: 0.85, sets: 5, reps: '4-6',   restTime: '180s', desc: 'Volume ลด Intensity สูง น้ำหนักหนักขึ้น' },
      { id: 4, name: 'Peak',        nameTH: 'Peak & Recomp',      intensity: 0.90, sets: 5, reps: '2-4',   restTime: '240s', desc: 'Intensity สูงสุด เตรียมทดสอบ' },
    ];
  }

  getCurrentPhase() {
    const phases = this.getPhases();
    return phases[this.state.phaseIndex % phases.length];
  }

  /* ----------------------------------------------------------
     AUTO WEEKLY ADJUSTMENT
     ---------------------------------------------------------- */
  advanceWeek() {
    this.state.weekNumber++;

    if (this.state.weekNumber % 4 === 0) this.deload();

    if (this.state.weekNumber % 12 === 0) {
      this.state.phaseIndex++;
      Object.keys(this.state.weeklyVolume).forEach(m => { this.state.weeklyVolume[m] = 0; });
    }

    Store.save(this.state);
    return {
      weekNumber:  this.state.weekNumber,
      isDeload:    this.state.weekNumber % 4 === 0,
      phase:       this.getCurrentPhase(),
      phaseTH:     this.getCurrentPhase().nameTH,
    };
  }

  checkDeload() {
    if (this.state.readiness < 40) this.deload();
  }

  deload() {
    Object.keys(this.state.weeklyVolume).forEach(m => { this.state.weeklyVolume[m] *= 0.6; });
    Object.keys(this.state.fatigue).forEach(m => { this.state.fatigue[m] *= 0.7; });
    this.calculateReadiness();
  }

  /* ----------------------------------------------------------
     Volume Modifier
     ---------------------------------------------------------- */
  getVolumeModifier() {
    const r = this.state.readiness;
    if (r >= 80) return 1.00;
    if (r >= 60) return 0.85;
    if (r >= 40) return 0.70;
    return 0.50;
  }

  /* ----------------------------------------------------------
     XP + LEVEL  (FIX 1: while แทน if)
     ---------------------------------------------------------- */
  addXP(volume) {
    // Fix 3.1: guard against NaN volume
    const safeVol = (typeof SafeNumber !== 'undefined')
      ? SafeNumber.volume(volume)
      : Math.max(0, isFinite(volume) ? volume : 0);

    const gained  = Math.max(1, Math.floor(safeVol / 50));
    this.state.xp += gained;

    // Fix 3.1: MAX_LEVEL guard prevents infinite while loop
    const MAX_LEVEL = 1000;
    let loopGuard = 0;
    while (this.state.xp >= this.xpToNextLevel() && this.state.level < MAX_LEVEL) {
      const needed = this.xpToNextLevel();
      if (needed <= 0) break; // extra safety: prevent divide-by-zero / negative threshold
      this.state.xp -= needed;
      this.state.level++;
      if (++loopGuard > 500) {
        if (typeof Logger !== 'undefined') Logger.error('Engine', 'addXP loop guard triggered');
        break;
      }
    }

    // Cap at MAX_LEVEL
    if (this.state.level >= MAX_LEVEL) {
      this.state.level = MAX_LEVEL;
      this.state.xp    = 0;
    }

    return gained;
  }

  xpToNextLevel() {
    // Fix 1.1: guard level=0 → 300*pow(0,1.5)=0 → infinite loop
    const lvl = Math.max(1, Number(this.state.level) || 1);
    return Math.max(1, Math.floor(300 * Math.pow(lvl, 1.5)));
  }

  xpPercent() {
    // Fix 1.2: division by zero when xpToNextLevel()=0
    const next = this.xpToNextLevel();
    if (next <= 0) return 0;
    return Math.min(100, Math.round((Number(this.state.xp) || 0) / next * 100));
  }

  /* ----------------------------------------------------------
     RANK
     ---------------------------------------------------------- */
  getRank() {
    // Fix 2: totalVolume may be undefined/NaN after state corruption
    const vol = Number(this.state.totalVolume) || 0;
    if (vol <  50_000) return { name: 'Recruit',                emoji: '🪖', tier: 0 };
    if (vol < 150_000) return { name: 'Operator Trainee',       emoji: '🎖️', tier: 1 };
    if (vol < 300_000) return { name: 'Operator',               emoji: '⚔️', tier: 2 };
    if (vol < 600_000) return { name: 'Advanced Operator',      emoji: '🛡️', tier: 3 };
    return               { name: 'Special Forces Candidate',    emoji: '⭐', tier: 4 };
  }

  /* ----------------------------------------------------------
     STREAK — Fix 3: UTC-based day comparison to prevent timezone drift + exploit
     toDateString() depends on local timezone → wrong on timezone change / clock manipulation
     Solution: compare ISO date strings (UTC) with 24h window tolerance
  ---------------------------------------------------------- */
  _updateStreak() {
    const nowMs    = Date.now();
    const todayUTC = new Date(nowMs).toISOString().split('T')[0]; // "2026-03-09"

    // Clamp: reject future dates (exploit guard)
    if (this.state.lastWorkoutDate > todayUTC) {
      if (typeof Logger !== 'undefined') Logger.warn('Engine', 'Streak: future lastWorkoutDate clamped');
      this.state.lastWorkoutDate = todayUTC;
      this.state.streak = 1;
      return;
    }

    if (this.state.lastWorkoutDate === todayUTC) return; // already logged today

    // yesterdayUTC: subtract 24h
    const yesterdayUTC = new Date(nowMs - 86_400_000).toISOString().split('T')[0];

    this.state.streak = (this.state.lastWorkoutDate === yesterdayUTC)
      ? (Number(this.state.streak) || 0) + 1
      : 1;

    this.state.lastWorkoutDate = todayUTC;
  }

  /* ----------------------------------------------------------
     ANALYTICS SUMMARY
     ---------------------------------------------------------- */
  getAnalytics() {
    const rank = this.getRank();
    const rl   = this.getReadinessLabel();

    // Fix 4: fatigue may be null after corruption
    const fatigue = (this.state.fatigue && typeof this.state.fatigue === 'object')
      ? this.state.fatigue : {};

    const muscles = {};
    Object.entries(fatigue).forEach(([m, f]) => {
      // Fix 7.3: NaN fatigue value guard
      const safeF = isFinite(+f) && !isNaN(+f) ? +f : 0;
      muscles[m] = { fatigue: safeF, recovery: Math.max(0, 100 - safeF) };
    });

    // Fix 7.3: normalize to Number before sort to prevent unstable NaN sort
    const sortedByFatigue = Object.entries(fatigue)
      .map(([m, f]) => [m, isFinite(+f) ? +f : 0])
      .sort((a, b) => b[1] - a[1]);

    return {
      readiness:    Math.round(this.state.readiness || 0),
      readinessLbl: rl.label,
      rank,
      xp:           this.state.xp || 0,
      level:        this.state.level || 1,
      xpPercent:    this.xpPercent(),
      xpToNext:     this.xpToNextLevel(),
      streak:       this.state.streak || 0,
      workouts:     this.state.workoutsCompleted || 0,
      totalVolume:  this.state.totalVolume || 0,
      weeklyVolume: this.state.weeklyVolume || {},
      muscles,
      mostFatigued:  sortedByFatigue[0]?.[0] || '–',
      leastFatigued: sortedByFatigue[sortedByFatigue.length - 1]?.[0] || '–',
      phase:         this.getCurrentPhase(),
      weekNumber:    this.state.weekNumber || 1,
      trend:         'stable',
    };
  }

  /* ----------------------------------------------------------
     DEBUG
     ---------------------------------------------------------- */
  debug() {
    const a = this.getAnalytics();
    console.group('%c[ProductionEngine] Debug', 'color:#78cc55;font-weight:bold');
    console.table({
      Rank:        a.rank.emoji + ' ' + a.rank.name,
      Readiness:   Math.round(this.state.readiness) + '% — ' + a.readinessLbl,
      Level:       this.state.level + ' (XP: ' + this.state.xp + '/' + this.xpToNextLevel() + ')',
      TotalVolume: Math.round(this.state.totalVolume).toLocaleString() + ' kg',
      Workouts:    this.state.workoutsCompleted,
      Streak:      this.state.streak + ' วัน',
      Week:        this.state.weekNumber,
      Phase:       this.getCurrentPhase().nameTH,
    });
    console.log('Fatigue per muscle:', JSON.stringify(
      Object.fromEntries(Object.entries(this.state.fatigue).map(([m, f]) => [m, Math.round(f) + '%'])),
    null, 2));
    console.groupEnd();
    return this.state;
  }

  reset() {
    this.state = this.initState();
    Store.save(this.state);
  }
}

/* ============================================================
   SINGLETON
   ============================================================ */
window.Engine          = new ProductionEngine();
window.OPERATOR_ENGINE = window.Engine;
window.OE              = window.Engine;

/* ============================================================
   VALIDATE WORKOUT INPUT
   ============================================================ */
window.validateWorkoutInput = (sets, reps, weight) => {
  return window.Engine.validate({ sets, reps, weight });
};

/* ============================================================
   completeWorkout
   ============================================================ */
function completeWorkout(workout) {
  const result = Engine.logWorkout(workout);
  renderReadiness();
  renderMuscleGrid();
  renderRank();
  return result;
}
window.completeWorkout = completeWorkout;

/* ============================================================
   SECURITY UTILITIES — escapeHTML, safeColor, fisherYates
   Fix 5: CSS color injection  Fix 6: XSS via muscle name
   Fix 7.1: Fisher-Yates shuffle
   ============================================================ */

// Fix 6: escapeHTML — prevent DOM injection via state values
function escapeHTML(str) {
  if (typeof str !== 'string') str = String(str ?? '');
  return str
    .replace(/&/g,  '&amp;')
    .replace(/</g,  '&lt;')
    .replace(/>/g,  '&gt;')
    .replace(/"/g,  '&quot;')
    .replace(/'/g,  '&#x27;');
}

// Fix 5: safeColor — whitelist CSS color values (hex, named, safe rgb)
const _SAFE_COLORS = new Set([
  '#2ecc71','#f1c40f','#e74c3c','#e67e22','#3498db','#9b59b6',
  '#78cc55','#1abc9c','#34495e','#7f8c8d','#bdc3c7','#ecf0f1',
]);
const _HEX_RE  = /^#[0-9a-fA-F]{3,8}$/;
const _RGB_RE  = /^rgba?\(\s*\d{1,3},\s*\d{1,3},\s*\d{1,3}(?:,\s*[\d.]+)?\s*\)$/;

function safeColor(color, fallback = '#78cc55') {
  if (typeof color !== 'string') return fallback;
  const c = color.trim();
  if (_SAFE_COLORS.has(c)) return c;
  if (_HEX_RE.test(c))     return c;
  if (_RGB_RE.test(c))     return c;
  if (typeof Logger !== 'undefined') Logger.warn('safeColor', 'Rejected unsafe color:', c);
  return fallback;
}

// Fix 7.1: Fisher-Yates unbiased shuffle
function fisherYates(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ============================================================
   READINESS UI
   ============================================================ */

// Fix 5: CSS color whitelist — prevent injection of arbitrary CSS values from tampered state
function _safeColor(color) {
  // Only allow hex colors: #rgb, #rrggbb, #rrggbbaa
  if (/^#[0-9a-fA-F]{3,8}$/.test(color)) return color;
  return '#888888'; // safe fallback
}

function renderReadiness() {
  // Fix 13: Engine may not be ready on DOMContentLoaded — guard state
  if (!window.Engine || !Engine.state) return;

  const r  = Math.round(Number(Engine.state.readiness) || 0);
  const lb = Engine.getReadinessLabel();
  const col = _safeColor(lb.color); // Fix 5: sanitized color

  const labelEl  = document.getElementById('readiness-label');
  const fillEl   = document.getElementById('readiness-fill');
  const adviceEl = document.getElementById('readiness-advice');
  if (labelEl)  labelEl.textContent          = 'Readiness: ' + r + '%  ' + lb.label;
  if (fillEl)  { fillEl.style.width          = r + '%'; fillEl.style.background = col; }
  if (adviceEl){ adviceEl.textContent        = lb.advice; adviceEl.style.color  = col; }

  const scoreEl = document.getElementById('readiness-score');
  const barEl   = document.getElementById('readiness-bar-fill');
  if (scoreEl) scoreEl.textContent = r;
  if (barEl)  { barEl.style.width = r + '%'; barEl.style.background = `linear-gradient(90deg,${col}88,${col})`; }

  const xpCurEl  = document.getElementById('xp-current');
  const xpNxtEl  = document.getElementById('xp-next');
  const xpBarEl  = document.getElementById('xp-bar-fill');
  if (xpCurEl) xpCurEl.textContent = Engine.state.xp || 0;
  if (xpNxtEl) xpNxtEl.textContent = Engine.xpToNextLevel();
  if (xpBarEl) xpBarEl.style.width = Engine.xpPercent() + '%';

  const wEl = document.getElementById('readiness-widget-container');
  if (wEl) {
    const phase = Engine.getCurrentPhase();
    // Fix 5+6: sanitized color + escapeHTML on all text injected into innerHTML
    wEl.innerHTML = `
      <div class="readiness-widget">
        <div class="readiness-ring" style="--pct:${r};--col:${col}">
          <div class="readiness-score">${r}<small>%</small></div>
        </div>
        <div class="readiness-info">
          <div style="font-weight:700;color:${col};margin-bottom:4px">${escapeHTML(lb.label)}</div>
          <div style="font-size:12px;color:#bbb;margin-bottom:6px">${escapeHTML(lb.advice)}</div>
          <div style="font-size:11px;color:#888">
            ${escapeHTML(phase.nameTH)} · Week <strong style="color:#ccc">${Number(Engine.state.weekNumber) || 1}</strong>
            · Lv <strong style="color:#ccc">${Number(Engine.state.level) || 1}</strong>
            · Vol <strong style="color:#ccc">${Math.round(Number(Engine.state.totalVolume) || 0).toLocaleString()}</strong> kg
          </div>
          <div style="font-size:11px;color:#888;margin-top:3px">
            Volume Modifier: <strong style="color:#ccc">${(Engine.getVolumeModifier() * 100).toFixed(0)}%</strong>
          </div>
        </div>
      </div>`;
  }
}
window.renderReadiness = renderReadiness;

/* ============================================================
   RENDER RANK
   ============================================================ */
function renderRank() {
  const rank = Engine.getRank();
  const el   = document.getElementById('top-rank');
  if (el) el.textContent = rank.emoji + ' ' + rank.name;
  const badge = document.getElementById('rank-badge');
  if (badge) badge.textContent = rank.emoji;
}
window.renderRank = renderRank;

/* ============================================================
   MUSCLE RECOVERY GRID
   ============================================================ */

// Fix 6: HTML escape — prevents XSS if state.fatigue keys are tampered via DevTools
function _escHTML(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
}

function renderMuscleGrid() {
  // Fix 13: Engine guard
  if (!window.Engine || !Engine.state) return;

  const CONTAINERS = ['muscle-grid', 'muscle-grid-analyze'];
  const EMOJI = { chest:'💪', back:'🔝', legs:'🦵', shoulders:'💥', arms:'💪', core:'🎯' };

  // Fix 6: fatigue null guard + only render known muscles (whitelist)
  const KNOWN_MUSCLES = ['chest', 'back', 'legs', 'shoulders', 'arms', 'core'];
  const fatigue = Engine.state.fatigue || {};
  const weeklyVolume = Engine.state.weeklyVolume || {};

  const html = KNOWN_MUSCLES.map(muscle => {
    const rawF   = fatigue[muscle];
    const f      = (isFinite(rawF) && !isNaN(rawF)) ? rawF : 0;
    const ready  = Math.max(0, Math.min(100, 100 - f));
    const pct    = Math.round(ready);
    // Fix 5: color is from our own logic — no external input, but sanitize anyway
    const col    = _safeColor(pct >= 70 ? '#2ecc71' : pct >= 40 ? '#f1c40f' : '#e74c3c');
    const status = pct >= 70 ? '✅ พร้อม' : pct >= 40 ? '⚡ ปานกลาง' : '😴 พัก';
    // Fix 6: escape muscle name before DOM injection (even though it's from our whitelist)
    const muscleSafe = _escHTML(muscle);
    const vol    = Math.round(Number(weeklyVolume[muscle]) || 0).toLocaleString();
    return `
      <div class="muscle-card">
        <div class="muscle-card-icon">${EMOJI[muscle] || '💪'}</div>
        <div class="muscle-card-name">${muscleSafe}</div>
        <div class="muscle-card-bar-wrap">
          <div class="muscle-card-bar-fill" style="width:${pct}%;background:${col}"></div>
        </div>
        <div class="muscle-card-pct" style="color:${col}">${status} ${pct}%</div>
        <div style="font-size:10px;color:#5a5a60;margin-top:2px">vol: ${vol} kg/wk</div>
      </div>`;
  }).join('');

  CONTAINERS.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = html;
  });
}
window.renderMuscleGrid = renderMuscleGrid;

/* ============================================================
   FATIGUE GRID
   ============================================================ */
function renderFatigueGrid() {
  const el = document.getElementById('fatigue-grid');
  if (!el || !window.Engine || !Engine.state) return;
  const EMOJI      = { chest:'💪', back:'🔝', legs:'🦵', shoulders:'💥', arms:'💪', core:'🎯' };
  const KNOWN      = ['chest', 'back', 'legs', 'shoulders', 'arms', 'core'];
  const fatigue    = Engine.state.fatigue || {};

  el.innerHTML = KNOWN.map(m => {
    const rawF  = fatigue[m];
    const f     = (isFinite(rawF) && !isNaN(rawF)) ? Math.max(0, rawF) : 0;
    const pct   = Math.min(Math.round(f), 100);
    const col   = _safeColor(pct >= 70 ? '#e74c3c' : pct >= 40 ? '#f1c40f' : '#2ecc71');
    // Fix: guard log argument — f can be 0 causing log(20/0.1) but Math.max protects it
    const hoursLeft = f > 20
      ? Math.ceil(Math.log(20 / Math.max(f, 0.1)) / Math.log(0.95))
      : 0;
    const safeHours = isFinite(hoursLeft) ? Math.max(0, hoursLeft) : 0;
    const daysLeft  = safeHours > 0 ? (safeHours / 24).toFixed(1) : 0;
    // Fix 6: escape muscle name
    const mSafe = _escHTML(m);
    return `
      <div class="fatigue-item">
        <div class="fatigue-icon">${EMOJI[m] || '⚡'}</div>
        <div class="fatigue-name">${mSafe}</div>
        <div class="fatigue-bar-wrap">
          <div class="fatigue-bar-fill" style="width:${pct}%;background:${col}"></div>
        </div>
        <div class="fatigue-status" style="color:${col}">${daysLeft > 0 ? `😴 ${daysLeft}d` : '✅'}</div>
      </div>`;
  }).join('');
}
window.renderFatigueGrid = renderFatigueGrid;

/* ============================================================
   AI Workout Generator
   ============================================================ */
function generateWorkoutFromDB(dayType) {
  const db = window.EXERCISE_DB || [];
  if (!db.length) return [];

  const readiness = Engine.state.readiness;
  const volMod    = Engine.getVolumeModifier();
  const phase     = Engine.getCurrentPhase();

  const muscleMap = {
    push:     ['chest', 'shoulders', 'arms'],
    pull:     ['back', 'arms'],
    legs:     ['legs'],
    core:     ['core'],
    fullbody: ['chest', 'back', 'legs', 'core'],
    cardio:   ['cardio'],
    recovery: ['core'],
  };
  const targets = muscleMap[dayType] || ['chest', 'back', 'legs', 'core'];
  const fatigueState = Engine.state.fatigue || {};

  const sortedTargets = [...targets].sort((a, b) => {
    // Fix 7.3: normalize fatigue to safe numbers before sort — NaN breaks Array.sort
    const fa = Number(fatigueState[a]); const fb = Number(fatigueState[b]);
    const sa = (isFinite(fa) && !isNaN(fa)) ? fa : 0;
    const sb = (isFinite(fb) && !isNaN(fb)) ? fb : 0;
    return sa - sb;
  });

  let eqKeys = ['bodyweight'];
  try {
    const eq    = JSON.parse(localStorage.getItem('equipment') || '[]');
    const eqMap = {
      'บาร์โหน': 'pullupbar', 'ดัมเบล': 'dumbbell', 'บาร์เบล': 'barbell',
      'เคเบิ้ลแมชชีน': 'cable', 'ลูกน้ำหนัก Kettlebell': 'kettlebell',
      'ยางยืด Resistance Band': 'band',
    };
    // Fix 7.2: log unrecognized keys instead of silently dropping
    const mapped = eq.map(e => {
      const m = eqMap[e];
      if (!m && typeof Logger !== 'undefined') Logger.debug('generateWorkout', 'Unknown equipment:', e);
      return m;
    }).filter(Boolean);
    eqKeys = [...eqKeys, ...mapped];
  } catch (e) {
    if (typeof Logger !== 'undefined') Logger.warn('generateWorkout', 'Equipment parse failed:', e?.message);
  }

  const available = db.filter(ex =>
    ex.equipment === 'bodyweight' || ex.equipment === 'cardio' || eqKeys.includes(ex.equipment)
  );

  const setsPerEx = Math.max(2, Math.round((phase.sets || 4) * volMod));
  const selected  = [];

  sortedTargets.forEach(muscle => {
    const pool  = available.filter(e => e.muscle === muscle);
    if (!pool.length) return;
    const count = dayType === 'fullbody' ? 2 : 3;
    const picks = fisherYates(pool).slice(0, count);
    picks.forEach(ex => {
      const prog = Engine.getProgression(ex.name);
      const load = Engine.suggestLoad(prog.weight || 0, muscle);
      selected.push({
        name:        ex.name,
        nameTH:      ex.nameTH || ex.name,
        muscle:      ex.muscle,
        equipment:   ex.equipment,
        sets:        setsPerEx,
        reps:        prog.reps || ex.reps || phase.reps || 10,
        weight:      load,
        rest:        ex.rest || phase.restTime || '60s',
        tips:        ex.tips || '',
        progression: prog.suggestion || '',
        fatigueLevel: Math.round(isFinite(+fatigueState[muscle]) ? +fatigueState[muscle] : 0),
        phaseName:   phase.nameTH,
      });
    });
  });

  return selected;
}
window.generateWorkoutFromDB = generateWorkoutFromDB;

/* ============================================================
   Auto Weekly Adjust — Fix 8: UTC-based day check (not local getDay())
   getDay() returns local timezone day → wrong across timezones
   Use ISO date string which is always UTC-based
   ============================================================ */
function weeklyAdjust() {
  if (!window.Engine || !Engine.state) return; // Fix 13: state guard

  const now      = new Date();
  const todayStr = now.toISOString().split('T')[0]; // UTC date "2026-03-09"

  // Fix 8: profile-aware key (profile switching would get same weekly adjust otherwise)
  const pid = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
            || localStorage.getItem('operator_active_profile');
  const adjustKey = pid ? `weekly_adjust_date_${pid}` : 'weekly_adjust_date';

  // Already ran today
  if (localStorage.getItem(adjustKey) === todayStr) return;

  // Fix 8: check UTC day-of-week (0=Sunday) not local getDay()
  const utcDay = now.getUTCDay();
  if (utcDay !== 0) return;

  localStorage.setItem(adjustKey, todayStr);
  const result = Engine.advanceWeek();

  const msg = result.isDeload
    ? `🔄 Deload Week! Week ${result.weekNumber} — ลด Volume 40%`
    : `✅ Week ${result.weekNumber} เริ่มต้น — ${result.phaseTH} — Readiness ${Math.round(Engine.state.readiness || 0)}%`;

  if (typeof showToast === 'function') showToast(msg);
  renderReadiness();
  renderMuscleGrid();
}
window.weeklyAdjust = weeklyAdjust;

/* ============================================================
   AI Fatigue Analysis — Fix 9: don't rely on window-overrideable globals
   Use scoped function references with strict existence check
   ============================================================ */
async function aiAdjustBeforeGenerate() {
  if (!window.Engine || !Engine.state) return '⚠️ Engine not ready';

  const r     = Math.round(Engine.state.readiness || 0);
  const lb    = Engine.getReadinessLabel();
  const phase = Engine.getCurrentPhase();

  // Fix 4: fatigue null guard
  const fatigue     = Engine.state.fatigue     || {};
  const weeklyVol   = Engine.state.weeklyVolume || {};

  const fatigueSummary = Object.entries(fatigue)
    .map(([m, f]) => {
      const sf = isFinite(+f) ? +f : 0;
      return `${m}: fatigue ${Math.round(sf)}% → ready ${Math.round(100 - sf)}%`;
    })
    .join('\n');

  const volSummary = Object.entries(weeklyVol)
    .map(([m, v]) => `${m}: ${Math.round(isFinite(+v) ? +v : 0).toLocaleString()} kg/wk`)
    .join('\n');

  const prompt = `Fatigue Analysis (Exponential Decay Model):
${fatigueSummary}

Weekly Volume:
${volSummary}

Current Phase: ${phase.nameTH} (Intensity ${(phase.intensity * 100).toFixed(0)}%)
Overall Readiness: ${r}% — ${lb.label}
Volume Modifier: ${(Engine.getVolumeModifier() * 100).toFixed(0)}%

วิเคราะห์:
1. กล้ามเนื้อที่ควรพัก + ควรรออีกกี่วัน
2. กล้ามเนื้อที่ฝึกได้ทันที
3. ควรเพิ่มหรือลด volume? ระบุ % ด้วย
4. คำแนะนำสำหรับ Phase ${phase.nameTH}

ตอบสั้นกระชับ ภาษาไทย ใช้ emoji`;

  // Fix 9: verify AI function references exist as actual functions, not window overrides
  const _getKey      = (typeof getActiveKey      === 'function') ? getActiveKey      : null;
  const _getProvider = (typeof getProvider       === 'function') ? getProvider       : null;
  const _askGemini   = (typeof askGeminiRaw      === 'function') ? askGeminiRaw      : null;
  const _askOpenAI   = (typeof askOpenAIRaw      === 'function') ? askOpenAIRaw      : null;

  const apiKey = _getKey ? (_getKey() || '') : '';
  if (!apiKey || apiKey.length < 10) {
    return `📊 Readiness: ${r}% — ${lb.label}\n💡 ${lb.advice}\nPhase: ${phase.nameTH}\n\n(ใส่ API Key เพื่อให้ AI วิเคราะห์เพิ่มเติม)`;
  }

  if (!_getProvider || (!_askGemini && !_askOpenAI)) {
    return `📊 Readiness: ${r}% — ${lb.label}\n💡 ${lb.advice}\n(AI provider not available)`;
  }

  try {
    const provider = _getProvider();
    if (provider === 'gemini' && _askGemini) return await _askGemini(prompt, apiKey, 150);
    if (_askOpenAI) return await _askOpenAI([
      { role: 'system', content: 'คุณคือโค้ชทหาร วิเคราะห์ฟิตเนสสั้นกระชับ' },
      { role: 'user',   content: prompt },
    ], apiKey, 150);
    return `📊 Readiness: ${r}% — ${lb.label}`;
  } catch (e) {
    return `📊 Readiness: ${r}% — ${lb.label}\n⚠️ AI: ${e.message}`;
  }
}
window.aiAdjustBeforeGenerate = aiAdjustBeforeGenerate;

/* ============================================================
   SAFE FETCH HELPER
   ============================================================ */
window.safeFetch = async (url, options) => {
  let r;
  try { r = await fetch(url, options); }
  catch (e) { throw new Error('Network error: ' + e.message); }
  if (!r.ok) {
    const hints = { 400:'Bad request', 401:'Invalid API key', 403:'No permission', 429:'Rate limit exceeded', 500:'Server error', 503:'Service unavailable' };
    throw new Error(`API ${r.status}: ${hints[r.status] || r.statusText}`);
  }
  // Fix 10: handle non-JSON responses gracefully
  const contentType = r.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    return r.json();
  }
  // Fallback: try JSON parse, if it fails return as text wrapped in object
  const text = await r.text();
  try { return JSON.parse(text); }
  catch { return { raw: text }; }
};

/* ============================================================
   FITNESENGINE SHIM
   ============================================================ */
window.FitnessEngine = {
  init:                  (p)   => { if (p) Engine.state.profile = p; Store.save(Engine.state); renderReadiness(); },
  // Fix 11: deep clone prevents external mutation of nested objects (fatigue, weeklyVolume etc.)
  getState:              ()    => JSON.parse(JSON.stringify(Engine.state)),
  dailyRecovery:         ()    => Engine.triggerRecovery(),
  triggerDailyRecovery:  ()    => Engine.triggerRecovery(),
  getCurrentPhase:       ()    => Engine.getCurrentPhase(),
  getReadinessLabel:     ()    => Engine.getReadinessLabel(),
  getVolumeModifier:     ()    => Engine.getVolumeModifier(),
  analyzeHistory:        ()    => ({
    readiness:       Math.round(Engine.state.readiness),
    currentPhase:    Engine.getCurrentPhase(),
    weekNumber:      Engine.state.weekNumber,
    trend:           'stable',
    deloadActive:    Engine.state.weekNumber % 4 === 0,
    thisWeekSessions: 0,
    recommendation:  [Engine.getReadinessLabel().advice],
  }),
  generateWorkout:       (dt)  => generateWorkoutFromDB(dt),
  logWorkout:            (exs) => Engine.logWorkout(exs),
  generateYearPlan:      ()    => Engine.getPhases().map((p, i) => ({ ...p, weekRange: `สัปดาห์ ${i*12+1}–${i*12+12}`, isCurrent: i === Engine.state.phaseIndex % 4 })),
  autoAdjustWeek:        ()    => Engine.advanceWeek(),
  renderReadinessWidget: (id)  => { const el = document.getElementById(id); if (el) renderReadiness(); },
  renderFatigueWidget:   (id)  => { const el = document.getElementById(id); if (!el) return; el.id = 'fatigue-grid'; renderFatigueGrid(); },
  renderYearPlanWidget:  (id)  => {
    const el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = window.FitnessEngine.generateYearPlan().map(p => `
      <div class="phase-card${p.isCurrent ? ' phase-current' : ''}">
        <div class="phase-card-header">
          <span class="phase-card-num">Phase ${p.id}</span>
          <span class="phase-card-name">${p.nameTH}</span>
          <span class="phase-card-weeks">${p.weekRange}</span>
        </div>
        <div style="font-size:12px;color:#9a9a9a;margin:4px 0">${p.desc}</div>
        <div style="font-size:11px;color:#7a7a80">${p.sets}×${p.reps} · พัก ${p.restTime} · Intensity ${(p.intensity*100).toFixed(0)}%</div>
        ${p.isCurrent ? '<div style="color:#78cc55;font-size:12px;margin-top:6px;font-weight:700">▶ กำลังฝึกอยู่</div>' : ''}
      </div>`).join('');
  },
};

/* ============================================================
   [HF-2] HOURLY RECOVERY TICK
   Fix 12: Use a private symbol-based key to prevent accidental overwrite
   before clearInterval fires (HMR / module-reload safety)
   ============================================================ */
(function _installEngineTick() {
  // Clear any existing tick — even if _engineTick was overwritten, try both paths
  try { if (window._engineTick) { clearInterval(window._engineTick); window._engineTick = null; } } catch {}
  // Use a well-known key (not guessable by accident, but still clearable from outside)
  window._engineTick = setInterval(() => {
    if (!window.Engine || !Engine.state) return; // Fix 13: guard state ready
    Engine.triggerRecovery();
    if (typeof renderReadiness  === 'function') renderReadiness();
    if (typeof renderMuscleGrid === 'function') renderMuscleGrid();
  }, 3_600_000);
})();

/* ============================================================
   DOM-READY: initial render + weekly check
   Fix 13: Guard Engine.state before any render call
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  // Wait one microtask to ensure ProfileUI routing ran first (it fires at window.load+1200ms)
  // weeklyAdjust + renders are non-critical UI so a slight delay is fine
  if (!window.Engine || !Engine.state) return;
  weeklyAdjust();
  renderReadiness();
  renderMuscleGrid();
  renderRank();
});

/* ============================================================
   STARTUP LOG
   Fix 14: guard Engine.state before calling methods that access it
   ============================================================ */
try {
  if (window.Engine && Engine.state) {
    console.log(
      `%c[ProductionEngine v2.0] Loaded%c  Rank: ${Engine.getRank().emoji} ${Engine.getRank().name}  |  Readiness: ${Math.round(Engine.state.readiness)}%  |  Phase: ${Engine.getCurrentPhase().nameTH}`,
      'color:#78cc55;font-weight:bold', 'color:#aaa'
    );
  }
} catch (e) {
  console.log('%c[ProductionEngine v2.0] Loaded', 'color:#78cc55;font-weight:bold');
}
