/* ================================================================
   STORAGE DB — storage/db.js
   Tactical Adaptive Training OS — Offline-First Storage

   ✅ Features:
     IndexedDB สำหรับ history ยาว (localStorage มีจำกัด ~5MB)
     localStorage สำหรับ state ปัจจุบัน (fast read)
     Auto-migrate จาก localStorage → IndexedDB
     Sync two-way: IDB ↔ localStorage
   ================================================================ */
'use strict';

const TrainingDB = (() => {

  const DB_NAME    = 'TacticalTrainingOS';
  const DB_VERSION = 2;
  const STORES = {
    WORKOUTS:  'workouts',   // log ทุก session
    PROGRAMS:  'programs',   // AI/local program cache
    TRENDS:    'trends',     // weekly trend snapshots
    SETTINGS:  'settings',   // user settings backup
  };

  let _db = null;
  let _ready = false;
  const _queue = [];

  /* ----------------------------------------------------------
     init — เปิด IndexedDB
  ---------------------------------------------------------- */
  async function init() {
    if (_db) return _db;

    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);

      req.onupgradeneeded = e => {
        const db = e.target.result;

        // workouts store: date index สำหรับ query ช่วงเวลา
        if (!db.objectStoreNames.contains(STORES.WORKOUTS)) {
          const ws = db.createObjectStore(STORES.WORKOUTS, { keyPath: 'id', autoIncrement: true });
          ws.createIndex('date',    'date',    { unique: false });
          ws.createIndex('muscle',  'muscle',  { unique: false });
          ws.createIndex('week',    'week',    { unique: false });
        }

        // programs store: key = date string
        if (!db.objectStoreNames.contains(STORES.PROGRAMS)) {
          db.createObjectStore(STORES.PROGRAMS, { keyPath: 'key' });
        }

        // trends store: key = week number
        if (!db.objectStoreNames.contains(STORES.TRENDS)) {
          db.createObjectStore(STORES.TRENDS, { keyPath: 'week' });
        }

        // settings store
        if (!db.objectStoreNames.contains(STORES.SETTINGS)) {
          db.createObjectStore(STORES.SETTINGS, { keyPath: 'key' });
        }

        console.log('[TrainingDB] Schema upgraded to v' + DB_VERSION);
      };

      req.onsuccess = e => {
        _db = e.target.result;
        _ready = true;
        // flush queue
        _queue.forEach(fn => fn(_db));
        _queue.length = 0;
        console.log('%c[TrainingDB] IndexedDB ready', 'color:#78cc55');
        resolve(_db);
      };

      req.onerror = e => {
        console.warn('[TrainingDB] IndexedDB unavailable — falling back to localStorage only');
        _ready = false;
        resolve(null); // ไม่ reject — graceful fallback
      };
    });
  }

  /* ----------------------------------------------------------
     _getDB — ให้ db instance หรือ null ถ้าไม่พร้อม
  ---------------------------------------------------------- */
  function _getDB() {
    return _db;
  }

  /* ----------------------------------------------------------
     _tx — helper สร้าง transaction
  ---------------------------------------------------------- */
  function _tx(storeName, mode = 'readonly') {
    const db = _getDB();
    if (!db) return null;
    try {
      return db.transaction([storeName], mode).objectStore(storeName);
    } catch {
      return null;
    }
  }

  /* ----------------------------------------------------------
     logWorkout — บันทึก workout session
     @param session { exercises[], date, muscle, volume, week }
  ---------------------------------------------------------- */
  async function logWorkout(session) {
    // Always save to localStorage first (fast)
    _lsSaveWorkout(session);

    const store = _tx(STORES.WORKOUTS, 'readwrite');
    if (!store) return false;

    return new Promise(resolve => {
      const entry = {
        date:      session.date     || new Date().toISOString().split('T')[0],
        week:      session.week     || _getWeekNumber(),
        muscle:    session.muscle   || 'mixed',
        volume:    session.volume   || 0,
        exercises: session.exercises || [],
        xpGained:  session.xpGained || 0,
        readiness: session.readiness || 100,
        intensity: session.intensity || 'normal',
        ts:        Date.now(),
      };

      const req = store.add(entry);
      req.onsuccess = () => resolve(true);
      req.onerror   = () => {
        console.warn('[TrainingDB] logWorkout failed');
        resolve(false);
      };
    });
  }

  /* ----------------------------------------------------------
     getWorkouts — ดึง workouts ย้อนหลัง N วัน
  ---------------------------------------------------------- */
  async function getWorkouts(days = 30) {
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000)
      .toISOString().split('T')[0];

    const store = _tx(STORES.WORKOUTS, 'readonly');
    if (!store) return _lsGetWorkouts(days);

    return new Promise(resolve => {
      const results = [];
      const index   = store.index('date');
      const range   = IDBKeyRange.lowerBound(cutoff);
      const cursor  = index.openCursor(range);

      cursor.onsuccess = e => {
        const c = e.target.result;
        if (c) { results.push(c.value); c.continue(); }
        else resolve(results);
      };
      cursor.onerror = () => resolve(_lsGetWorkouts(days));
    });
  }

  /* ----------------------------------------------------------
     saveProgram — บันทึก program สำหรับสัปดาห์นี้
  ---------------------------------------------------------- */
  async function saveProgram(program) {
    const key   = 'week_' + _getWeekNumber();
    const entry = { key, program, ts: Date.now() };

    // localStorage ก่อน (quick access) — profile-aware
    try {
      const lsKey = _profileId() ? `weekly_program_${_profileId()}` : 'weekly_program';
      localStorage.setItem(lsKey, JSON.stringify(program));
    } catch {}

    const store = _tx(STORES.PROGRAMS, 'readwrite');
    if (!store) return false;

    return new Promise(resolve => {
      const req = store.put(entry);
      req.onsuccess = () => resolve(true);
      req.onerror   = () => resolve(false);
    });
  }

  /* ----------------------------------------------------------
     getCurrentProgram — ดึง program สัปดาห์นี้
  ---------------------------------------------------------- */
  async function getCurrentProgram() {
    // ลอง localStorage ก่อน (fast path) — profile-aware
    try {
      const lsKey = _profileId() ? `weekly_program_${_profileId()}` : 'weekly_program';
      const raw = localStorage.getItem(lsKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') return parsed;
      }
    } catch {}

    // Fallback: IndexedDB
    const key   = 'week_' + _getWeekNumber();
    const store = _tx(STORES.PROGRAMS, 'readonly');
    if (!store) return null;

    return new Promise(resolve => {
      const req = store.get(key);
      req.onsuccess = e => resolve(e.target.result?.program || null);
      req.onerror   = () => resolve(null);
    });
  }

  /* ----------------------------------------------------------
     saveTrendSnapshot — บันทึก weekly trend
  ---------------------------------------------------------- */
  async function saveTrendSnapshot(trend) {
    const week  = _getWeekNumber();
    const store = _tx(STORES.TRENDS, 'readwrite');
    if (!store) return false;

    return new Promise(resolve => {
      const req = store.put({ week, trend, ts: Date.now() });
      req.onsuccess = () => resolve(true);
      req.onerror   = () => resolve(false);
    });
  }

  /* ----------------------------------------------------------
     getTrendHistory — ดึง trend ย้อนหลัง N สัปดาห์
  ---------------------------------------------------------- */
  async function getTrendHistory(weeks = 4) {
    const currentWeek = _getWeekNumber();
    const store       = _tx(STORES.TRENDS, 'readonly');
    if (!store) return [];

    const results = [];
    for (let i = 0; i < weeks; i++) {
      const week = currentWeek - i;
      await new Promise(resolve => {
        const req = store.get(week);
        req.onsuccess = e => {
          if (e.target.result) results.push(e.target.result);
          resolve();
        };
        req.onerror = () => resolve();
      });
    }
    return results;
  }

  /* ----------------------------------------------------------
     backupSettings — backup settings ลง IDB
  ---------------------------------------------------------- */
  async function backupSettings() {
    const pid = _profileId();
    const baseKeys = ['ai_provider', 'openai_api_key', 'gemini_api_key', 'profile_v1',
                      'equipment', 'train_location', 'custom_goal', 'operator_profiles_v1',
                      'operator_active_profile'];
    // Add per-profile keys if active
    const profileKeys = pid ? [
      `operator_production_${pid}`,
      `operator_attributes_${pid}`,
      `operator_rank_${pid}`,
      `operator_career_${pid}`,
      `weekly_program_${pid}`,
    ] : ['operator_production_v1'];

    const keys = [...baseKeys, ...profileKeys];
    const store = _tx(STORES.SETTINGS, 'readwrite');
    if (!store) return false;

    const promises = keys.map(key => {
      const val = localStorage.getItem(key);
      if (!val) return Promise.resolve();
      return new Promise(resolve => {
        const req = store.put({ key, value: val, ts: Date.now() });
        req.onsuccess = () => resolve();
        req.onerror   = () => resolve();
      });
    });

    await Promise.all(promises);
    return true;
  }

  /* ----------------------------------------------------------
     restoreSettings — คืน settings จาก IDB ถ้า localStorage ว่าง
  ---------------------------------------------------------- */
  async function restoreSettings() {
    const store = _tx(STORES.SETTINGS, 'readonly');
    if (!store) return false;

    return new Promise(resolve => {
      const req = store.getAll();
      req.onsuccess = e => {
        const entries = e.target.result || [];
        let restored = 0;
        entries.forEach(({ key, value }) => {
          if (!localStorage.getItem(key) && value) {
            try {
              localStorage.setItem(key, value);
              restored++;
            } catch {}
          }
        });
        if (restored > 0) console.log(`[TrainingDB] Restored ${restored} settings from IDB`);
        resolve(restored > 0);
      };
      req.onerror = () => resolve(false);
    });
  }

  /* ----------------------------------------------------------
     getStats — สถิติรวม
  ---------------------------------------------------------- */
  async function getStats() {
    const store = _tx(STORES.WORKOUTS, 'readonly');
    if (!store) {
      return { totalSessions: 0, source: 'localStorage' };
    }

    return new Promise(resolve => {
      const req = store.count();
      req.onsuccess = e => resolve({ totalSessions: e.target.result, source: 'indexeddb' });
      req.onerror   = () => resolve({ totalSessions: 0, source: 'error' });
    });
  }

  /* ----------------------------------------------------------
     PRIVATE: localStorage fallbacks — multi-profile aware
  ---------------------------------------------------------- */
  function _profileId() {
    return (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
         || localStorage.getItem('operator_active_profile') || '';
  }

  function _lsSaveWorkout(session) {
    try {
      const key  = _profileId() ? `workout_log_${_profileId()}` : 'workout_log';
      const log  = JSON.parse(localStorage.getItem(key) || '[]');
      log.push({ ...session, ts: Date.now() });
      if (log.length > 50) log.splice(0, log.length - 50);
      localStorage.setItem(key, JSON.stringify(log));
    } catch {}
  }

  function _lsGetWorkouts(days) {
    try {
      const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000)
        .toISOString().split('T')[0];
      const key = _profileId() ? `workout_log_${_profileId()}` : 'workout_log';
      const log = JSON.parse(localStorage.getItem(key) || '[]');
      return log.filter(w => (w.date || '') >= cutoff);
    } catch { return []; }
  }

  function _getWeekNumber() {
    const now  = new Date();
    const start = new Date(now.getFullYear(), 0, 1);
    return Math.ceil(((now - start) / 86400000 + start.getDay() + 1) / 7);
  }

  /* ----------------------------------------------------------
     isAvailable — ตรวจ IndexedDB support
  ---------------------------------------------------------- */
  function isAvailable() {
    return typeof indexedDB !== 'undefined' && _ready;
  }

  /* ----------------------------------------------------------
     Public API
  ---------------------------------------------------------- */
  return {
    init,
    logWorkout,
    getWorkouts,
    saveProgram,
    getCurrentProgram,
    saveTrendSnapshot,
    getTrendHistory,
    backupSettings,
    restoreSettings,
    getStats,
    isAvailable,
  };
})();

window.TrainingDB = TrainingDB;

// Auto-init on load
TrainingDB.init().then(db => {
  if (db) TrainingDB.restoreSettings();
});

console.log('%c[TrainingDB] Loaded — IndexedDB + localStorage hybrid', 'color:#78cc55');
