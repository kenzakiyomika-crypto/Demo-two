/* ================================================================
   GAME LOOP  —  game_loop.js
   Phase C: Risk/Reward UI + Battle Feedback + Session Report

   Connects ALL systems into visible game experience:
     renderRiskDial()        — Pre-session tension UI
     renderBattleLog()       — Real-time set outcomes
     renderSessionReport()   — Post-session S/A/B/C report
     renderMetaOverlay()     — Character sheet overlay
     patchSaveWorkout()      — Hook into existing saveWorkout

   Design:
     ไม่แตะ engine.js, app.js โดยตรง
     ทุกอย่างผ่าน event system + DOM injection
     Safe to load after all other scripts

   Load order: LAST (after meta_system.js)
   ================================================================ */
'use strict';

/* ============================================================
   STYLES (inject once)
   ============================================================ */
const GAME_LOOP_CSS = `
/* ── Risk Dial ──────────────────────────── */
.risk-dial-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,0.85);
  z-index: 9000; display: flex; align-items: center; justify-content: center;
  animation: fadeIn 0.3s ease;
}
.risk-dial-box {
  background: #1a1a24; border: 1px solid #333;
  border-radius: 16px; padding: 24px; width: 340px; max-width: 92vw;
}
.risk-dial-title { font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 4px; }
.risk-dial-sub   { font-size: 12px; color: #777; margin-bottom: 18px; }
.risk-option {
  border: 1px solid #333; border-radius: 12px; padding: 14px 16px;
  margin-bottom: 10px; cursor: pointer; transition: all 0.2s;
  background: #111;
}
.risk-option:hover  { border-color: #555; background: #1e1e2e; transform: translateY(-1px); }
.risk-option.active { border-color: var(--col, #78cc55); background: #1e2e1e; }
.risk-option-label  { font-weight: 700; font-size: 14px; color: #fff; margin-bottom: 4px; }
.risk-option-desc   { font-size: 12px; color: #888; }
.risk-warning { background: #2a1a0a; border: 1px solid #e67e22; border-radius: 8px;
  padding: 10px 14px; font-size: 12px; color: #e67e22; margin-bottom: 14px; }
.risk-confirm-btn {
  width: 100%; padding: 12px; background: #78cc55; color: #111;
  border: none; border-radius: 10px; font-weight: 800; font-size: 15px;
  cursor: pointer; margin-top: 6px; transition: opacity 0.2s;
}
.risk-confirm-btn:hover { opacity: 0.88; }

/* ── Battle Log ─────────────────────────── */
.battle-log-panel {
  background: #0f0f18; border: 1px solid #2a2a3a; border-radius: 12px;
  padding: 14px; margin: 12px 0; max-height: 280px; overflow-y: auto;
}
.battle-log-entry {
  display: flex; align-items: center; gap: 10px;
  padding: 8px 0; border-bottom: 1px solid #1a1a2a; font-size: 13px;
  animation: slideIn 0.3s ease;
}
.battle-log-entry:last-child { border-bottom: none; }
.battle-log-dmg  { font-size: 18px; font-weight: 800; min-width: 64px; color: #e74c3c; }
.battle-log-dmg.crit  { color: #f39c12; text-shadow: 0 0 8px #f39c12; }
.battle-log-xp   { color: #78cc55; font-size: 12px; min-width: 46px; }
.battle-log-combo{ color: #9b59b6; font-size: 11px; }
.battle-log-name { color: #ccc; flex: 1; }
.battle-log-narr { font-size: 11px; color: #666; margin-left: auto; }

/* ── Session Report ─────────────────────── */
.session-report-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,0.92);
  z-index: 9100; display: flex; align-items: center; justify-content: center;
  animation: fadeIn 0.4s ease;
}
.session-report-box {
  background: #13131d; border: 1px solid #333; border-radius: 20px;
  padding: 28px 24px; width: 360px; max-width: 94vw; max-height: 90vh;
  overflow-y: auto; text-align: center;
}
.report-grade {
  font-size: 64px; font-weight: 900; line-height: 1;
  margin-bottom: 4px;
  background: linear-gradient(135deg, #f39c12, #e74c3c);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.report-grade.S { background: linear-gradient(135deg, #f1c40f, #f39c12); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.report-grade.A { background: linear-gradient(135deg, #2ecc71, #27ae60); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.report-grade.B { background: linear-gradient(135deg, #3498db, #2980b9); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.report-grade.C { background: linear-gradient(135deg, #95a5a6, #7f8c8d); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.report-title   { font-size: 22px; font-weight: 800; color: #fff; margin: 8px 0; }
.report-stats-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin: 18px 0;
}
.report-stat {
  background: #1c1c2c; border-radius: 10px; padding: 12px;
}
.report-stat-val { font-size: 22px; font-weight: 800; color: #fff; }
.report-stat-lbl { font-size: 11px; color: #666; margin-top: 2px; }
.report-events   { margin: 12px 0; }
.report-event-item {
  background: #1e1a0e; border: 1px solid #f39c12; border-radius: 8px;
  padding: 10px; margin: 6px 0; font-size: 13px; color: #f39c12; font-weight: 700;
}
.report-close-btn {
  width: 100%; padding: 13px; background: #78cc55; color: #111;
  border: none; border-radius: 12px; font-weight: 800; font-size: 16px;
  cursor: pointer; margin-top: 12px;
}
.report-unlocks { margin: 10px 0; text-align: left; }
.report-unlock-item {
  background: #0e1e1e; border: 1px solid #2ecc71; border-radius: 8px;
  padding: 10px; margin: 6px 0; font-size: 12px; color: #2ecc71;
}

/* ── Meta Overlay ───────────────────────── */
.meta-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,0.88);
  z-index: 9200; display: flex; align-items: flex-start; justify-content: center;
  overflow-y: auto; padding: 20px 0;
}
.meta-overlay-box {
  background: #12121c; border: 1px solid #333; border-radius: 16px;
  width: 360px; max-width: 94vw; padding: 20px;
}
.meta-overlay-close {
  position: absolute; top: 12px; right: 14px;
  background: none; border: none; color: #888; font-size: 22px; cursor: pointer;
}
.meta-hud-inner { font-size: 13px; }
.meta-section    { margin-bottom: 14px; padding-bottom: 14px; border-bottom: 1px solid #1e1e2e; }
.meta-section:last-child { border-bottom: none; }
.meta-title      { font-size: 18px; font-weight: 800; color: #fff; }
.meta-subtitle   { font-size: 12px; color: #666; margin-top: 2px; }
.meta-label      { font-size: 11px; font-weight: 700; color: #555; text-transform: uppercase;
  letter-spacing: 0.8px; margin-bottom: 8px; }
.meta-stats-row  { display: flex; gap: 10px; }
.meta-stat       { flex: 1; background: #1c1c2c; border-radius: 8px; padding: 10px; text-align: center; }
.meta-stat-val   { font-size: 20px; font-weight: 800; color: #fff; }
.meta-stat-lbl   { font-size: 10px; color: #666; }
.meta-skills-list{ display: flex; flex-direction: column; gap: 6px; }
.meta-skill-item { background: #1a2a1a; border-radius: 8px; padding: 8px 10px;
  display: flex; flex-direction: column; gap: 2px; }
.meta-skill-next { background: #1a1a1a; border-radius: 8px; padding: 8px 10px;
  display: flex; flex-direction: column; gap: 2px; opacity: 0.6; }
.meta-bonus-pills{ display: flex; flex-wrap: wrap; gap: 6px; }
.meta-pill       { padding: 3px 9px; border-radius: 20px; font-size: 11px; font-weight: 700; }
.meta-pill.crit  { background: #3a1a00; color: #f39c12; }
.meta-pill.xp    { background: #0a2a0a; color: #2ecc71; }
.meta-pill.dmg   { background: #2a0a0a; color: #e74c3c; }
.meta-pill.special { background: #0a1a2a; color: #3498db; }

/* ── Animations ────────────────────────── */
@keyframes fadeIn  { from { opacity: 0; }              to { opacity: 1; } }
@keyframes slideIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
`;

(function injectGameLoopStyles() {
  if (document.getElementById('game-loop-styles')) return;
  const style = document.createElement('style');
  style.id = 'game-loop-styles';
  style.textContent = GAME_LOOP_CSS;
  document.head.appendChild(style);
})();

/* ============================================================
   GAME LOOP SINGLETON
   ============================================================ */
const GameLoop = {

  _selectedMode: 'normal',
  _currentBattleLog: [],

  /* ----------------------------------------------------------
     showRiskDial — Pre-session modal
     @param onConfirm  fn(mode)
  ---------------------------------------------------------- */
  showRiskDial(onConfirm) {
    if (typeof ConversionLayer === 'undefined') {
      onConfirm?.('normal');
      return;
    }

    const dial = ConversionLayer.getRiskDialState();
    this._selectedMode = dial.recommended;

    const optionsHTML = dial.options.map(opt => `
      <div class="risk-option ${opt.id === dial.recommended ? 'active' : ''}"
           style="--col:${opt.color}"
           data-mode="${opt.id}"
           onclick="GameLoop._selectMode('${opt.id}', this)">
        <div class="risk-option-label" style="color:${opt.color}">${opt.label}</div>
        <div class="risk-option-desc">${opt.desc}</div>
      </div>`).join('');

    const el = document.createElement('div');
    el.className = 'risk-dial-overlay';
    el.id = 'risk-dial-overlay';
    el.innerHTML = `
      <div class="risk-dial-box">
        <div class="risk-dial-title">⚔️ เลือกโหมดการฝึก</div>
        <div class="risk-dial-sub">
          Readiness ${dial.readiness}% · Streak ${dial.streak} วัน · ACWR ${dial.acwr.ratio.toFixed(2)}
        </div>
        ${dial.warning ? `<div class="risk-warning">${dial.warning}</div>` : ''}
        ${optionsHTML}
        <button class="risk-confirm-btn" onclick="GameLoop._confirmMode()">
          ▶ เริ่มฝึก
        </button>
      </div>`;

    document.body.appendChild(el);
    this._riskConfirmCallback = onConfirm;
  },

  _selectMode(mode, el) {
    this._selectedMode = mode;
    document.querySelectorAll('.risk-option').forEach(o => o.classList.remove('active'));
    el.classList.add('active');
  },

  _confirmMode() {
    const overlay = document.getElementById('risk-dial-overlay');
    if (overlay) overlay.remove();
    this._riskConfirmCallback?.(this._selectedMode);
  },

  /* ----------------------------------------------------------
     renderBattleLog — แสดง set outcomes ใน workout modal
  ---------------------------------------------------------- */
  renderBattleLog(containerId = 'battle-log-container') {
    let el = document.getElementById(containerId);
    if (!el) return;

    if (!this._currentBattleLog.length) {
      el.innerHTML = '<div style="color:#555;text-align:center;padding:12px;font-size:12px">ยังไม่มีข้อมูล — บันทึก set แล้วดูผลที่นี่</div>';
      return;
    }

    const html = this._currentBattleLog.map(o => `
      <div class="battle-log-entry">
        <div class="battle-log-dmg ${o.isCrit ? 'crit' : ''}">
          ${o.isCrit ? '⚡' : '💥'} ${o.damage}
        </div>
        <div>
          <div class="battle-log-name">${o.name} ${o.sets}×${o.reps}${o.weight > 0 ? ' @' + o.weight + 'kg' : ''}</div>
          <div class="battle-log-xp">+${o.xp} XP ${o.combo > 1 ? `<span class="battle-log-combo">× Combo ${o.combo}</span>` : ''}</div>
        </div>
        <div class="battle-log-narr">${o.narrative}</div>
      </div>`).join('');

    el.innerHTML = `<div class="battle-log-panel">${html}</div>`;
  },

  /* ----------------------------------------------------------
     addToBattleLog — เพิ่ม outcome จาก 1 set
  ---------------------------------------------------------- */
  addToBattleLog(exerciseData) {
    if (typeof ConversionLayer === 'undefined') return null;
    const outcome = ConversionLayer.computeSetOutcome(exerciseData);
    this._currentBattleLog.push(outcome);
    this.renderBattleLog();
    return outcome;
  },

  clearBattleLog() {
    this._currentBattleLog = [];
    ConversionLayer?.resetSession?.();
  },

  /* ----------------------------------------------------------
     showSessionReport — Post-session overlay
  ---------------------------------------------------------- */
  showSessionReport(sessionResult, newUnlocks = []) {
    const r = sessionResult;

    const gradeDesc = {
      S: '🏆 PERFECT! ทุก set คือ Critical!',
      A: '⭐ Excellent! สม่ำเสมอมาก',
      B: '👍 Good Session! Combo สูง',
      C: '💪 Solid Work! ฝึกต่อไป',
    };

    const eventsHTML = (r.events || []).map(ev => `
      <div class="report-event-item">${ev.label}<br><small style="font-weight:400">${ev.desc}</small></div>
    `).join('');

    const unlocksHTML = (newUnlocks || []).map(u => `
      <div class="report-unlock-item">🔓 ${u.nameTH || u.name} — ${u.desc}</div>
    `).join('');

    const el = document.createElement('div');
    el.className = 'session-report-overlay';
    el.id = 'session-report-overlay';
    el.innerHTML = `
      <div class="session-report-box">
        <div class="report-grade ${r.grade}">${r.grade}</div>
        <div class="report-title">${gradeDesc[r.grade] || 'Session Complete!'}</div>

        <div class="report-stats-grid">
          <div class="report-stat">
            <div class="report-stat-val" style="color:#e74c3c">⚔️ ${r.totalDamage.toLocaleString()}</div>
            <div class="report-stat-lbl">Total Damage</div>
          </div>
          <div class="report-stat">
            <div class="report-stat-val" style="color:#78cc55">+${r.totalXP}</div>
            <div class="report-stat-lbl">XP Gained</div>
          </div>
          <div class="report-stat">
            <div class="report-stat-val" style="color:#f39c12">⚡ ×${r.maxCombo}</div>
            <div class="report-stat-lbl">Max Combo</div>
          </div>
          <div class="report-stat">
            <div class="report-stat-val" style="color:#9b59b6">${r.critCount}</div>
            <div class="report-stat-lbl">Crits</div>
          </div>
        </div>

        ${r.streakBonus > 1 ? `
          <div style="background:#1e1a00;border:1px solid #f1c40f;border-radius:8px;padding:10px;
              margin:8px 0;font-size:13px;color:#f1c40f">
            🔥 Streak Bonus ×${r.streakBonus} Applied!
          </div>` : ''}

        ${eventsHTML ? `<div class="report-events">${eventsHTML}</div>` : ''}

        ${unlocksHTML ? `<div class="report-unlocks">${unlocksHTML}</div>` : ''}

        <div style="color:#555;font-size:11px;margin-bottom:8px">
          Vol: ${Math.round(r.totalVolume).toLocaleString()} kg · ${r.exerciseCount} exercises · Class: ${r.classMod?.label}
        </div>

        <button class="report-close-btn" onclick="GameLoop._closeReport()">
          ✅ Continue
        </button>
      </div>`;

    document.body.appendChild(el);
  },

  _closeReport() {
    const el = document.getElementById('session-report-overlay');
    if (el) el.remove();
    // Re-render meta HUD if exists
    if (typeof MetaSystem !== 'undefined') {
      MetaSystem.renderMetaHUD('meta-hud');
    }
  },

  /* ----------------------------------------------------------
     showMetaOverlay — Character Sheet popup
  ---------------------------------------------------------- */
  showMetaOverlay() {
    if (document.getElementById('meta-overlay')) return;

    const el = document.createElement('div');
    el.className = 'meta-overlay';
    el.id = 'meta-overlay';
    el.innerHTML = `
      <div class="meta-overlay-box" style="position:relative">
        <button class="meta-overlay-close" onclick="GameLoop.closeMetaOverlay()">✕</button>
        <div style="font-size:16px;font-weight:800;color:#fff;margin-bottom:16px">📋 Character Sheet</div>
        <div id="meta-hud-overlay"></div>
      </div>`;
    document.body.appendChild(el);

    if (typeof MetaSystem !== 'undefined') {
      MetaSystem.renderMetaHUD('meta-hud-overlay');
    }
  },

  closeMetaOverlay() {
    const el = document.getElementById('meta-overlay');
    if (el) el.remove();
  },

  /* ----------------------------------------------------------
     patchSaveWorkout — Monkey-patch existing saveWorkout
     Wraps the original function to inject game outcomes
  ---------------------------------------------------------- */
  patchSaveWorkout() {
    const original = window.saveWorkout;
    if (!original || typeof original !== 'function') {
      console.warn('[GameLoop] saveWorkout not found — patch deferred');
      return false;
    }

    window.saveWorkout = async function _patchedSaveWorkout() {
      // Collect exercises from DOM (same as original)
      const entries   = [...document.querySelectorAll('.exercise-entry')];
      const exercises = entries.map(e => {
        const selects = e.querySelectorAll('select');
        const inputs  = e.querySelectorAll('input');
        const typeEl  = document.getElementById('wk-type');
        const type    = typeEl?.value || 'fullbody';
        return {
          name:   selects[0]?.value || 'Exercise',
          sets:   Number(inputs[0]?.value) || 1,
          reps:   Number(inputs[1]?.value) || 10,
          weight: Number(inputs[2]?.value) || 0,
          muscle: (typeof _guessMuscleFromWorkoutType === 'function')
            ? _guessMuscleFromWorkoutType(type) : 'core',
        };
      });

      // Compute game session result BEFORE saving
      let sessionResult = null;
      let newUnlocks    = [];
      if (exercises.length > 0 && typeof ConversionLayer !== 'undefined') {
        GameLoop.clearBattleLog();
        sessionResult = ConversionLayer.computeSessionResult(exercises);

        // Apply to meta system
        const OE = window.OPERATOR_ENGINE;
        if (OE && typeof MetaSystem !== 'undefined') {
          newUnlocks = MetaSystem.checkUnlocks(sessionResult, OE.state);
        }

        // Apply ACWR + grade history
        ConversionLayer.applyGameOutcome(sessionResult);
      }

      // Call original saveWorkout
      await original.call(this);

      // Show session report after save
      if (sessionResult) {
        setTimeout(() => {
          GameLoop.showSessionReport(sessionResult, newUnlocks);
        }, 600);
      }
    };

    console.log('%c[GameLoop] saveWorkout patched ✅', 'color:#78cc55');
    return true;
  },

  /* ----------------------------------------------------------
     init — setup everything
  ---------------------------------------------------------- */
  init() {
    // Patch saveWorkout
    const patched = this.patchSaveWorkout();
    if (!patched) {
      // Retry after DOM ready if scripts haven't loaded yet
      document.addEventListener('DOMContentLoaded', () => this.patchSaveWorkout());
    }

    // Render meta HUD if container exists
    document.addEventListener('DOMContentLoaded', () => {
      if (typeof MetaSystem !== 'undefined') {
        MetaSystem.renderMetaHUD('meta-hud');
      }
    });

    console.log('%c[GameLoop] Initialized — RPG Fitness Engine Active ⚔️', 'color:#e74c3c;font-weight:bold');
  },
};

window.GameLoop = GameLoop;

/* ============================================================
   AUTO-INIT after all scripts loaded
   ============================================================ */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => GameLoop.init());
} else {
  GameLoop.init();
}
