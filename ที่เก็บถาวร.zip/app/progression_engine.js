/* ================================================================
   PROGRESSION ENGINE — engine/progression_engine.js
   Tactical Adaptive Training OS

   ทำงานร่วมกับ engine.js (ProductionEngine)
   ต่อยอด getProgression เดิม → ฉลาดขึ้น 10x

   ✅ Features:
     analyzeExercise()    — วิเคราะห์ history 5+ sessions
     detectPlateau()      — 3 sessions ไม่ขึ้น → plateau
     getNextProgression() — แนะนำ sets/reps/weight ขั้นต่อไป
     getVariation()       — แนะนำ variation เมื่อ plateau
     checkVolumeThreshold() — auto-deload เมื่อ weekly vol เกิน
     getOverallProgress() — progress summary ทุก exercise
   ================================================================ */
'use strict';

const ProgressionEngine = {

  /* ----------------------------------------------------------
     CONFIG
  ---------------------------------------------------------- */
  CONFIG: {
    PLATEAU_SESSIONS:       3,     // จำนวน session ที่ไม่ขึ้น → plateau
    REP_INCREMENT:          1,     // เพิ่ม reps ต่อ session
    WEIGHT_INCREMENT_PCT:   0.025, // เพิ่มน้ำหนัก 2.5% เมื่อ rep ถึง ceiling
    REP_CEILING_OFFSET:     2,     // ถ้า reps เกิน target+2 → เพิ่มน้ำหนัก
    DELOAD_THRESHOLD_MULT:  2.0,   // volume > avg*2 → deload flag
    MIN_SESSIONS_FOR_ANALYSIS: 3,  // ต้องมีอย่างน้อย 3 sessions

    // Volume thresholds per muscle (sets per week) — การฝึกทหาร
    VOLUME_THRESHOLDS: {
      chest:     20,  // sets/week
      back:      22,
      legs:      18,
      shoulders: 16,
      arms:      14,
      core:      24,
    },
  },

  /* ----------------------------------------------------------
     analyzeExercise — วิเคราะห์ history ของ exercise หนึ่ง
     @param name  exercise name (lowercase)
     @returns AnalysisResult object
  ---------------------------------------------------------- */
  analyzeExercise(name) {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return this._emptyAnalysis(name);

    const key     = (name || '').toLowerCase().trim();
    const history = OE.state.exerciseHistory?.[key] || [];

    if (history.length < this.CONFIG.MIN_SESSIONS_FOR_ANALYSIS) {
      return {
        name,
        sessions:    history.length,
        status:      'new',
        statusTH:    '🆕 เริ่มต้น — สะสมข้อมูลต่อ',
        trend:       'insufficient_data',
        plateau:     false,
        suggestion:  'เก็บ 3 sessions ก่อนวิเคราะห์',
        nextSets:    3,
        nextReps:    history[history.length - 1]?.reps || 10,
        nextWeight:  history[history.length - 1]?.weight || 0,
      };
    }

    const recent  = history.slice(-5);   // 5 session ล่าสุด
    const plateau = this.detectPlateau(recent);
    const trend   = this._calcTrend(recent);
    const next    = this.getNextProgression(recent, plateau);

    return {
      name,
      sessions:   history.length,
      recent,
      plateau,
      trend,
      ...next,
    };
  },

  /* ----------------------------------------------------------
     detectPlateau — ตรวจว่า 3 session ล่าสุดไม่มีความก้าวหน้า
     คำนวณจาก total volume (sets × reps × weight) ต่อ session
  ---------------------------------------------------------- */
  detectPlateau(sessions) {
    if (!sessions || sessions.length < this.CONFIG.PLATEAU_SESSIONS) return false;

    const recent = sessions.slice(-this.CONFIG.PLATEAU_SESSIONS);
    const volumes = recent.map(s => {
      const reps   = typeof s.reps === 'string' ? parseInt(s.reps) || 0 : (s.reps || 0);
      const weight = s.weight > 0 ? s.weight : 1;
      return s.sets * reps * weight;
    });

    // plateau ถ้า volume ไม่เพิ่มขึ้นเกิน 2% ใน 3 session
    // FIX [Medium]: guard both first and last for 0 to prevent false plateau detection
    const first = volumes[0] || 0;
    const last  = volumes[volumes.length - 1] || 0;
    // If both are 0 (e.g. new user, no weight data), not a plateau — insufficient data
    if (first === 0 && last === 0) return false;
    const denominator = first > 0 ? first : 1; // avoid div/0 if only first is 0
    const growth = (last - first) / denominator;

    return growth < 0.02; // < 2% growth = plateau
  },

  /* ----------------------------------------------------------
     getNextProgression — คำแนะนำ session ถัดไป
  ---------------------------------------------------------- */
  getNextProgression(sessions, plateau = false) {
    if (!sessions || !sessions.length) {
      return { nextSets: 3, nextReps: 10, nextWeight: 0, status: 'new', statusTH: '🆕 เริ่มต้น', suggestion: 'เริ่ม 3×10' };
    }

    const last    = sessions[sessions.length - 1];
    const lastReps = typeof last.reps === 'string' ? parseInt(last.reps) || 10 : (last.reps || 10);

    if (plateau) {
      // Plateau → deintensify แล้วเพิ่ม variation
      return {
        nextSets:   last.sets,
        nextReps:   Math.max(6, lastReps - 2),
        nextWeight: +(last.weight * 1.05).toFixed(1),
        status:     'plateau',
        statusTH:   '⚠️ Plateau ตรวจพบ',
        suggestion: this.getVariation(last),
      };
    }

    // ปกติ: reps เต็ม target → เพิ่มน้ำหนัก / ยังไม่เต็ม → เพิ่ม rep
    const prev = sessions.length >= 2 ? sessions[sessions.length - 2] : null;
    const prevReps = prev ? (typeof prev.reps === 'string' ? parseInt(prev.reps) || lastReps : prev.reps) : lastReps;

    // ถ้า reps ขึ้นมา 2+ ครั้งติดกัน → เพิ่มน้ำหนัก
    if (prev && lastReps >= prevReps + 2) {
      const newWeight = +(last.weight * (1 + this.CONFIG.WEIGHT_INCREMENT_PCT)).toFixed(1);
      return {
        nextSets:   last.sets,
        nextReps:   Math.max(6, lastReps - 2),
        nextWeight: newWeight,
        status:     'progression',
        statusTH:   '💪 เพิ่มน้ำหนัก',
        suggestion: `⬆️ เพิ่มน้ำหนักเป็น ${newWeight} กก. (ลด rep เป็น ${Math.max(6, lastReps - 2)})`,
      };
    }

    // เพิ่ม reps ปกติ
    return {
      nextSets:   last.sets,
      nextReps:   lastReps + this.CONFIG.REP_INCREMENT,
      nextWeight: last.weight,
      status:     'progressing',
      statusTH:   '📈 กำลังพัฒนา',
      suggestion: `📈 เพิ่ม ${this.CONFIG.REP_INCREMENT} rep → ${lastReps + this.CONFIG.REP_INCREMENT} reps`,
    };
  },

  /* ----------------------------------------------------------
     getVariation — แนะนำ variation เมื่อ plateau
     ฐานข้อมูล variation สำหรับท่าหลัก (ทหาร-focused)
  ---------------------------------------------------------- */
  getVariation(lastSession) {
    const name = (lastSession?.name || '').toLowerCase();

    const variationMap = {
      'push up':        '🔄 ลอง Archer Push Up หรือ Weighted Push Up',
      'วิดพื้น':         '🔄 ลอง วิดพื้น Archer หรือ Decline Push Up',
      'pull up':        '🔄 ลอง Weighted Pull Up หรือ L-Sit Pull Up',
      'ดึงข้อ':          '🔄 ลอง Commando Pull Up หรือ Weighted',
      'sit up':         '🔄 ลอง Hanging Leg Raise หรือ Dragon Flag',
      'situps':         '🔄 ลอง Hanging Leg Raise หรือ Dragon Flag',
      'plank':          '🔄 ลอง RKC Plank หรือ Plank Walkout',
      'run':            '🔄 เพิ่ม Tempo Run หรือ Hill Sprint',
      'วิ่ง':            '🔄 เพิ่ม Tempo Run หรือ Fartlek',
      'squat':          '🔄 ลอง Bulgarian Split Squat',
      'pushups':        '🔄 ลอง Archer Push Up หรือ Explosive Push Up',
      'pullups':        '🔄 ลอง Commando Pull Up หรือ Typewriter Pull Up',
    };

    for (const [key, suggestion] of Object.entries(variationMap)) {
      if (name.includes(key)) return suggestion;
    }

    return '🔄 ลองเพิ่ม Tempo (3-1-3) หรือเปลี่ยน grip width';
  },

  /* ----------------------------------------------------------
     checkVolumeThreshold — ตรวจ weekly volume เทียบ threshold
     คืน object ต่อ muscle: { ok, load, recommendation }
  ---------------------------------------------------------- */
  checkVolumeThreshold() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return {};

    const weeklyVol   = OE.state.weeklyVolume || {};
    const thresholds  = this.CONFIG.VOLUME_THRESHOLDS;
    const result      = {};

    Object.entries(thresholds).forEach(([muscle, threshold]) => {
      // แปลง kg volume เป็น sets estimate (สมมติ avg 10 reps × 1kg)
      const vol = weeklyVol[muscle] || 0;
      const setsEst = Math.round(vol / 10);

      const ratio = threshold > 0 ? setsEst / threshold : 0;

      result[muscle] = {
        setsEstimate: setsEst,
        threshold,
        ratio,
        ok:           ratio < 1.0,
        deloadNeeded: ratio > 1.5,
        load:         ratio >= 1.5 ? 'high'
                    : ratio >= 0.8 ? 'moderate'
                    : ratio >= 0.4 ? 'low'
                    : 'minimal',
        recommendation: ratio > 1.5
          ? `🔴 ${muscle}: Volume สูงเกิน — Deload ลด 40%`
          : ratio > 1.0
            ? `🟠 ${muscle}: Volume ใกล้ threshold — ระวัง`
            : null,
      };
    });

    return result;
  },

  /* ----------------------------------------------------------
     getOverallProgress — progress summary ทุก exercise
     ใช้สำหรับ Explain Mode และ Trend Display
  ---------------------------------------------------------- */
  getOverallProgress() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return { exercises: [], improving: 0, plateaued: 0, total: 0 };

    const history = OE.state.exerciseHistory || {};
    const exercises = [];
    let improving = 0, plateaued = 0;

    Object.keys(history).forEach(name => {
      const analysis = this.analyzeExercise(name);
      exercises.push(analysis);
      if (analysis.plateau)              plateaued++;
      else if (analysis.status === 'progressing' || analysis.status === 'progression') improving++;
    });

    // Sort: plateau ก่อน → improving ต่อ → new
    exercises.sort((a, b) => {
      const score = x => x.plateau ? 0 : x.status === 'progressing' ? 2 : 1;
      return score(a) - score(b);
    });

    const volumeStatus = this.checkVolumeThreshold();
    const deloadNeeded = Object.values(volumeStatus).some(v => v.deloadNeeded);

    return {
      exercises,
      improving,
      plateaued,
      total:       exercises.length,
      deloadNeeded,
      volumeStatus,
    };
  },

  /* ----------------------------------------------------------
     _calcTrend — คำนวณ trend ของ volume ใน recent sessions
  ---------------------------------------------------------- */
  _calcTrend(sessions) {
    if (!sessions || sessions.length < 2) return 'insufficient';

    const vols = sessions.map(s => {
      const reps   = typeof s.reps === 'string' ? parseInt(s.reps) || 0 : (s.reps || 0);
      const weight = s.weight > 0 ? s.weight : 1;
      return s.sets * reps * weight;
    });

    const first = vols[0] || 0;
    const last  = vols[vols.length - 1] || 0;
    // FIX [Medium]: guard against false trend when both are 0
    if (first === 0 && last === 0) return 'stable';
    const denominator = first > 0 ? first : 1;
    const pct   = ((last - first) / denominator) * 100;

    if (pct > 10)  return 'improving';
    if (pct > 2)   return 'slight_improvement';
    if (pct > -5)  return 'stable';
    return 'declining';
  },

  _emptyAnalysis(name) {
    return { name, sessions: 0, status: 'new', statusTH: '🆕 ยังไม่มีข้อมูล', plateau: false, suggestion: 'เริ่มบันทึก', nextSets: 3, nextReps: 10, nextWeight: 0 };
  },
};

window.ProgressionEngine = ProgressionEngine;
console.log('%c[ProgressionEngine] Loaded', 'color:#78cc55');
