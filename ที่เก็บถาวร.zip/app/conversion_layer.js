/* ================================================================
   CONVERSION LAYER  —  conversion_layer.js
   The Missing Bridge: Fitness World → Game World

   Architecture:
     computeSetOutcome()   — แปลง 1 set → damage / xp / combo
     computeSessionResult()— รวม set outcomes → session report
     applyGameOutcome()    — inject ผล → Engine + Meta + UI
     getRiskDialState()    — คำนวณ tension ก่อน session
     getComboMultiplier()  — streak × progression bonus

   Formula Design:
     Damage   = Volume × SFR × ClassMod × CritMul × FatiguePenalty
     XP       = Volume/50 × QualityMod × PhaseMod
     Combo    = ต่อเนื่อง progressive sets ← ProgressionEngine
     Critical = (streak × 2%) + (progressing × 10%) + (overload × 5%)

   Load order: after ascension_engine.js, before app.js
   Safe: extends globals, never overwrites existing state
   ================================================================ */
'use strict';

/* ============================================================
   CLASS MODIFIERS — แต่ละ goal type มี playstyle ต่างกัน
   ============================================================ */
const CLASS_MODIFIERS = {
  fat_loss:  { damageMod: 0.80, xpMod: 1.20, label: '🔥 Burner',    comboThreshold: 3 },
  muscle:    { damageMod: 1.20, xpMod: 1.00, label: '💪 Builder',   comboThreshold: 4 },
  military:  { damageMod: 1.00, xpMod: 1.50, label: '🎖️ Operator',  comboThreshold: 2 },
  general:   { damageMod: 1.00, xpMod: 1.00, label: '⚡ Fighter',   comboThreshold: 3 },
};

/* ============================================================
   PHASE MODIFIERS — XP bonus ตาม training phase
   ============================================================ */
const PHASE_XP_MODS = {
  'Foundation':  1.0,
  'Hypertrophy': 1.2,
  'Strength':    1.5,
  'Peak':        2.0,
};

/* ============================================================
   NARRATIVE POOL — text ที่แสดงใน UI
   ============================================================ */
const NARRATIVES = {
  critical:    ['⚡ CRITICAL HIT!', '💥 DEVASTATING BLOW!', '🔥 ON FIRE!', '⚡ PERFECT REP!'],
  progressing: ['💪 Pushing Forward!', '📈 Progress Detected!', '🔝 Getting Stronger!'],
  plateau:     ['😤 Plateau...', '⚠️ Adaptation needed', '🔄 Change required'],
  deload:      ['🧘 Recovery Mode', '💤 Smart Rest', '♻️ Active Recovery'],
  combo:       ['🔥 Combo ×', '⚡ Chain ×', '💥 Streak ×'],
  normal:      ['✅ Solid Set!', '💪 Good Work!', '🎯 On Target!'],
};

function _pickNarrative(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

/* ============================================================
   CONVERSION LAYER SINGLETON
   ============================================================ */
const ConversionLayer = {

  // Session combo tracker (reset each session)
  _sessionCombo: 0,
  _sessionCritCount: 0,
  _sessionDamageTotal: 0,
  _sessionXpTotal: 0,
  _sessionOutcomes: [],

  /* ----------------------------------------------------------
     resetSession — เรียกก่อนเริ่ม session ใหม่
  ---------------------------------------------------------- */
  resetSession() {
    this._sessionCombo       = 0;
    this._sessionCritCount   = 0;
    this._sessionDamageTotal = 0;
    this._sessionXpTotal     = 0;
    this._sessionOutcomes    = [];
  },

  /* ----------------------------------------------------------
     getClassMod — อ่าน goal จาก profile → class modifier
  ---------------------------------------------------------- */
  getClassMod() {
    try {
      const profile = (typeof getProfile === 'function') ? getProfile() : {};
      const goal    = profile.goal || 'general';
      return CLASS_MODIFIERS[goal] || CLASS_MODIFIERS.general;
    } catch {
      return CLASS_MODIFIERS.general;
    }
  },

  /* ----------------------------------------------------------
     computeSetOutcome — แปลง 1 set data → game outcome
     @param setData   { name, sets, reps, weight, muscle }
     @returns SetOutcome object
  ---------------------------------------------------------- */
  computeSetOutcome(setData) {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return this._fallbackOutcome(setData);

    const name   = (setData.name   || '').toLowerCase().trim();
    const sets   = Number(setData.sets)   || 1;
    const reps   = Number(setData.reps)   || 10;
    const weight = Number(setData.weight) > 0 ? Number(setData.weight) : 1;
    const muscle = setData.muscle || 'core';

    // ── Volume (physical truth) ────────────────────────────
    const volume = sets * reps * weight;

    // ── Exercise profile (SFR) ────────────────────────────
    const profile = this._getExerciseProfile(name);
    const sfr     = profile.stimulus / Math.max(profile.fatigueCost, 0.1);

    // ── Fatigue penalty ────────────────────────────────────
    const fatigue     = OE.state.fatigue[muscle] || 0;
    const fatigueMod  = fatigue > 70 ? 0.60 : fatigue > 40 ? 0.80 : 1.00;

    // ── Progression analysis ──────────────────────────────
    let progStatus = 'new';
    let isPlateau  = false;
    try {
      if (typeof ProgressionEngine !== 'undefined') {
        const analysis = ProgressionEngine.analyzeExercise(name);
        progStatus     = analysis.status || 'new';
        isPlateau      = analysis.plateau || false;
      }
    } catch {}

    // ── Class modifier ────────────────────────────────────
    const classMod = this.getClassMod();

    // ── Phase XP modifier ─────────────────────────────────
    const phase      = OE.getCurrentPhase?.() || { name: 'Foundation', nameTH: 'พื้นฐาน' };
    const phaseXpMod = PHASE_XP_MODS[phase.name] || 1.0;

    // ── Critical chance ───────────────────────────────────
    const streak     = OE.state.streak || 0;
    const critChance = Math.min(0.50,
      (streak   * 0.02) +                    // streak bonus max +20%
      (progStatus === 'progressing' ? 0.10 : 0) + // progressive reps
      (progStatus === 'progression' ? 0.15 : 0) + // weight increased
      (fatigue < 20 ? 0.05 : 0)              // fresh muscle
    );
    const isCrit = Math.random() < critChance;

    // ── Combo ─────────────────────────────────────────────
    const isCombo  = (progStatus === 'progressing' || progStatus === 'progression') && !isPlateau;
    if (isCombo) {
      this._sessionCombo++;
    } else if (isPlateau) {
      this._sessionCombo = 0;
    }
    const comboMul = 1 + Math.min(this._sessionCombo * 0.05, 0.50); // max +50%

    // ── Compute damage ───────────────────────────────────
    const baseDamage = volume * profile.stimulus * classMod.damageMod;
    const rawDamage  = baseDamage * fatigueMod * (isCrit ? 1.5 : 1.0) * comboMul;
    const damage     = isFinite(rawDamage) ? Math.max(0, Math.floor(rawDamage)) : 0;

    // ── Compute XP ────────────────────────────────────────
    const baseXP  = Math.max(1, volume / 50);
    const qualMod = isPlateau ? 0.70 : isCrit ? 1.5 : isCombo ? 1.2 : 1.0;
    const rawXP   = baseXP * classMod.xpMod * phaseXpMod * qualMod * fatigueMod;
    const xp      = isFinite(rawXP) ? Math.max(1, Math.floor(rawXP)) : 1;

    // ── Stamina cost ──────────────────────────────────────
    const rawStamina  = volume * profile.fatigueCost * 0.001;
    const staminaCost = isFinite(rawStamina) ? Math.floor(rawStamina) : 0;

    // ── Narrative ─────────────────────────────────────────
    let narrative;
    if (isCrit)    narrative = _pickNarrative(NARRATIVES.critical);
    else if (isPlateau) narrative = _pickNarrative(NARRATIVES.plateau);
    else if (this._sessionCombo >= 3) narrative = _pickNarrative(NARRATIVES.combo) + this._sessionCombo;
    else if (isCombo) narrative = _pickNarrative(NARRATIVES.progressing);
    else narrative = _pickNarrative(NARRATIVES.normal);

    // ── Accumulate session totals ─────────────────────────
    if (isCrit) this._sessionCritCount++;
    this._sessionDamageTotal += damage;
    this._sessionXpTotal     += xp;

    const outcome = {
      // Input
      name, sets, reps, weight, volume, muscle,
      // Game output
      damage, xp, staminaCost,
      isCrit, critChance: +(critChance * 100).toFixed(0),
      combo: this._sessionCombo,
      comboMul: +comboMul.toFixed(2),
      // Status
      progStatus, isPlateau, isCombo,
      sfr: +sfr.toFixed(2),
      fatigueMod: +fatigueMod.toFixed(2),
      fatigue: Math.round(fatigue),
      // Narrative
      narrative,
      phase: phase.nameTH,
    };

    this._sessionOutcomes.push(outcome);
    return outcome;
  },

  /* ----------------------------------------------------------
     computeSessionResult — รวม outcomes ของทั้ง session
     @param exercises   array ของ exercise data
     @returns SessionResult
  ---------------------------------------------------------- */
  computeSessionResult(exercises) {
    this.resetSession();

    const outcomes = (exercises || []).map(ex => this.computeSetOutcome(ex));

    const OE      = window.OPERATOR_ENGINE;
    const streak  = OE?.state?.streak || 0;
    const level   = OE?.state?.level  || 1;

    // Streak bonus (bonus damage on top of session total)
    const streakBonus = streak >= 7 ? 1.20
                      : streak >= 3 ? 1.10
                      : 1.00;

    const totalDamage  = Math.floor(this._sessionDamageTotal * streakBonus);
    const totalXP      = this._sessionXpTotal;
    const critCount    = this._sessionCritCount;
    // FIX [High]: Math.max(...emptyArray) returns -Infinity; use fallback for empty outcomes
    const maxCombo     = outcomes.length ? Math.max(...outcomes.map(o => o.combo || 0)) : 0;

    // Grade calculation
    const grade = critCount >= 3      ? 'S'
                : critCount >= 1      ? 'A'
                : maxCombo >= 3       ? 'B'
                : 'C';

    // Event triggers
    const events = this._checkEventTriggers(outcomes, streak, OE);

    return {
      outcomes,
      totalDamage,
      totalXP,
      totalVolume: outcomes.reduce((s, o) => s + o.volume, 0),
      critCount,
      maxCombo,
      streakBonus: +streakBonus.toFixed(2),
      grade,
      events,
      exerciseCount: outcomes.length,
      classMod: this.getClassMod(),
    };
  },

  /* ----------------------------------------------------------
     applyGameOutcome — นำ result ไป apply ใน Engine + Meta + UI
     @param sessionResult  จาก computeSessionResult()
  ---------------------------------------------------------- */
  applyGameOutcome(sessionResult) {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return;

    // Store grade history in ascension state
    try {
      if (!OE.state._ascension) OE.state._ascension = {};
      if (!OE.state._ascension.gradeHistory) OE.state._ascension.gradeHistory = [];
      OE.state._ascension.gradeHistory.push({
        date:  new Date().toISOString().split('T')[0],
        grade: sessionResult.grade,
        damage: sessionResult.totalDamage,
        xp:     sessionResult.totalXP,
        combo:  sessionResult.maxCombo,
      });
      // Keep last 50 sessions
      if (OE.state._ascension.gradeHistory.length > 50) {
        OE.state._ascension.gradeHistory = OE.state._ascension.gradeHistory.slice(-50);
      }
    } catch {}

    // Log to ACWR if available
    try {
      if (typeof ACWREngine !== 'undefined') {
        const exercises = sessionResult.outcomes.map(o => ({
          sets: o.sets, reps: o.reps, weight: o.weight, rpe: o.isCrit ? 9 : 7,
        }));
        ACWREngine.logSession(exercises);
      }
    } catch {}

    // Update meta unlock checks
    MetaSystem.checkUnlocks(sessionResult, OE.state);

    // Persist
    try {
      // FIX [High]: use profile-aware storage key
      const pid = (typeof StorageEngine !== 'undefined' ? StorageEngine.getActiveProfileId() : null)
               || localStorage.getItem('operator_active_profile');
      const storeKey = pid ? `operator_production_${pid}` : 'operator_production_v1';
      OE.state.lastUpdate = Date.now();
      localStorage.setItem(storeKey, JSON.stringify(OE.state));
    } catch(e) {
      if (typeof Logger !== 'undefined') Logger.saveFail('ConversionLayer', e);
    }
  },

  /* ----------------------------------------------------------
     getRiskDialState — Risk/Reward state ก่อน session
     ใช้ readiness + ACWR → แสดง tension choices
  ---------------------------------------------------------- */
  getRiskDialState() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return { mode: 'normal', options: [] };

    const readiness = Math.round(OE.state.readiness);
    const streak    = OE.state.streak || 0;

    // ACWR check
    let acwr = { ratio: 1.0, zone: 'optimal' };
    try {
      if (typeof ACWREngine !== 'undefined') acwr = ACWREngine.calculate();
    } catch {}

    const options = [];

    // HIGH readiness → offer PUSH mode
    if (readiness >= 80 && streak >= 3) {
      options.push({
        id:    'push',
        label: '🔥 PUSH MODE',
        desc:  `+50% XP, +Critical Chance, Fatigue Cost ×1.3`,
        xpMul:      1.5,
        critBonus:  0.15,
        fatigueMul: 1.3,
        color: '#e74c3c',
        risk: 'high',
      });
    }

    // Normal mode always available
    options.push({
      id:    'normal',
      label: '⚡ STANDARD',
      desc:  'ฝึกตามแผน — balanced XP & recovery',
      xpMul:      1.0,
      critBonus:  0.0,
      fatigueMul: 1.0,
      color: '#2ecc71',
      risk: 'normal',
    });

    // LOW readiness → RECOVERY quest
    if (readiness < 60) {
      options.push({
        id:    'recovery',
        label: '🧘 RECOVERY QUEST',
        desc:  `Active Recovery — +20% XP, restore fatigue`,
        xpMul:      1.2,
        critBonus:  0,
        fatigueMul: 0.3,
        color: '#3498db',
        risk: 'low',
      });
    }

    // INJURY RISK warning
    const warning = acwr.ratio > 1.5
      ? '⚠️ Injury Risk สูง — ACWR เกิน 1.5'
      : acwr.ratio < 0.8
      ? '💤 Undertrained — เพิ่ม volume ได้'
      : null;

    return {
      readiness,
      streak,
      acwr,
      options,
      warning,
      recommended: readiness >= 80 && streak >= 3 ? 'push'
                 : readiness < 60 ? 'recovery'
                 : 'normal',
    };
  },

  /* ----------------------------------------------------------
     _checkEventTriggers — special events based on performance
  ---------------------------------------------------------- */
  _checkEventTriggers(outcomes, streak, OE) {
    const events = [];

    // Boss Fight trigger: 3+ sessions ในสัปดาห์
    const workouts = OE?.state?.workoutsCompleted || 0;
    if (workouts > 0 && workouts % 10 === 0) {
      events.push({ type: 'boss', label: '👹 BOSS UNLOCKED!', desc: `${workouts} workouts — Boss Fight Mode!` });
    }

    // Streak milestone
    if (streak === 7)  events.push({ type: 'streak', label: '🔥 7-DAY STREAK!', desc: 'Weekly Champion!' });
    if (streak === 30) events.push({ type: 'streak', label: '⭐ MONTHLY LEGEND!', desc: '30 days unbroken!' });

    // All crits
    if (outcomes.length >= 3 && outcomes.every(o => o.isCrit)) {
      events.push({ type: 'perfect', label: '💥 PERFECT SESSION!', desc: 'All exercises: Critical!' });
    }

    // Combo milestone
    // FIX [High]: Math.max(...emptyArray) returns -Infinity; guard for empty outcomes
    const maxCombo = outcomes.length ? Math.max(...outcomes.map(o => o.combo || 0)) : 0;
    if (maxCombo >= 5) {
      events.push({ type: 'combo', label: `⚡ COMBO ×${maxCombo}!`, desc: 'Unstoppable progress streak!' });
    }

    return events;
  },

  /* ----------------------------------------------------------
     _getExerciseProfile — ดึง SFR profile จาก ascension_engine
  ---------------------------------------------------------- */
  _getExerciseProfile(name) {
    const defaultProfile = { stimulus: 1.0, fatigueCost: 1.0 };
    if (!name) return defaultProfile;

    // Try ascension_engine EXERCISE_PROFILES first
    if (typeof EXERCISE_PROFILES !== 'undefined') {
      // exact match
      if (EXERCISE_PROFILES[name]) return EXERCISE_PROFILES[name];
      // partial match
      for (const [key, prof] of Object.entries(EXERCISE_PROFILES)) {
        if (name.includes(key) || key.includes(name)) return prof;
      }
    }
    return defaultProfile;
  },

  /* ----------------------------------------------------------
     _fallbackOutcome — ถ้าไม่มี Engine
  ---------------------------------------------------------- */
  _fallbackOutcome(setData) {
    const vol = (setData.sets || 1) * (setData.reps || 10) * (setData.weight || 1);
    return {
      damage: Math.floor(vol * 1.0), xp: Math.floor(vol / 50),
      isCrit: false, combo: 0, comboMul: 1, staminaCost: 0,
      narrative: '💪 Solid Set!', progStatus: 'new', isPlateau: false,
      volume: vol, phase: 'Base',
    };
  },
};

window.ConversionLayer = ConversionLayer;
console.log('%c[ConversionLayer] Loaded — Fitness→Game Bridge Active', 'color:#f39c12;font-weight:bold');
