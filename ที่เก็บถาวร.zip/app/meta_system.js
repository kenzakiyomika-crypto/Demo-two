/* ================================================================
   META SYSTEM  —  meta_system.js
   RPG Progression Layer: Character Sheet + Skill Tree + Passives

   Architecture:
     CharacterSheet  — stats derived from training history
     SkillTree       — passives unlocked by consistency/volume
     EquipmentSystem — "equipment" bonuses from milestone achievements
     checkUnlocks()  — called after each session by ConversionLayer
     renderMetaHUD() — inject stats into UI

   Design Principle:
     ทุก skill/passive ต้องมาจากการฝึกจริง
     ไม่มี pay-to-win, ไม่มี random unlock
     "ฝึก deadlift 10 ครั้ง → ปลดล็อก 'Iron Back' passive"

   Load order: after conversion_layer.js, before app.js
   ================================================================ */
'use strict';

/* ============================================================
   SKILL TREE DEFINITION
   condition: fn(state, history) → boolean
   effect:    applied in ConversionLayer computations
   ============================================================ */
const SKILL_DEFINITIONS = [

  // ── Tier 1: Novice Passives (ปลดล็อกง่าย) ──────────────────

  {
    id: 'iron_will',
    name: 'Iron Will',
    nameTH: '🧠 Iron Will',
    desc: 'ฝึก 3 วันติดกัน — Critical Chance +5%',
    tier: 1,
    condition: (state) => (state.streak || 0) >= 3,
    effect: { critBonus: 0.05 },
    unlockMsg: '🧠 Iron Will ปลดล็อก! (+5% Crit)',
  },
  {
    id: 'volume_runner',
    name: 'Volume Runner',
    nameTH: '📦 Volume Runner',
    desc: 'Total Volume เกิน 10,000 kg — XP ×1.1',
    tier: 1,
    condition: (state) => (state.totalVolume || 0) >= 10000,
    effect: { xpMul: 0.10 },
    unlockMsg: '📦 Volume Runner ปลดล็อก! (+10% XP)',
  },
  {
    id: 'consistent',
    name: 'Consistent',
    nameTH: '📅 Consistent',
    desc: 'ฝึกครบ 10 sessions — Combo threshold ลด 1',
    tier: 1,
    condition: (state) => (state.workoutsCompleted || 0) >= 10,
    effect: { comboThresholdReduction: 1 },
    unlockMsg: '📅 Consistent ปลดล็อก! (Combo ง่ายขึ้น)',
  },

  // ── Tier 2: Specialist Passives ────────────────────────────

  {
    id: 'iron_back',
    name: 'Iron Back',
    nameTH: '🔝 Iron Back',
    desc: 'ฝึก back exercise 10 ครั้ง — Back SFR +15%',
    tier: 2,
    condition: (state) => _countMuscleHistory(state, 'back') >= 10,
    effect: { muscleSFRBonus: { back: 0.15 } },
    unlockMsg: '🔝 Iron Back ปลดล็อก! (Back SFR +15%)',
  },
  {
    id: 'leg_day_legend',
    name: 'Leg Day Legend',
    nameTH: '🦵 Leg Day Legend',
    desc: 'ฝึก legs 8 ครั้ง — Leg damage +20%',
    tier: 2,
    condition: (state) => _countMuscleHistory(state, 'legs') >= 8,
    effect: { muscleDmgBonus: { legs: 0.20 } },
    unlockMsg: '🦵 Leg Day Legend ปลดล็อก! (Leg Damage +20%)',
  },
  {
    id: 'operator_core',
    name: 'Operator Core',
    nameTH: '🎯 Operator Core',
    desc: 'ฝึก core 12 ครั้ง — Core XP ×1.3 + Stamina regen +10%',
    tier: 2,
    condition: (state) => _countMuscleHistory(state, 'core') >= 12,
    effect: { muscleXPBonus: { core: 0.30 }, staminaRegen: 0.10 },
    unlockMsg: '🎯 Operator Core ปลดล็อก! (Core XP +30%)',
  },
  {
    id: 'streak_warrior',
    name: 'Streak Warrior',
    nameTH: '🔥 Streak Warrior',
    desc: 'Streak 7 วัน — ทุก session มี Streak Bonus +25%',
    tier: 2,
    condition: (state) => (state.streak || 0) >= 7,
    effect: { streakBonusBoost: 0.25 },
    unlockMsg: '🔥 Streak Warrior ปลดล็อก! (Streak ×1.25)',
  },

  // ── Tier 3: Elite Passives ──────────────────────────────────

  {
    id: 'plateau_breaker',
    name: 'Plateau Breaker',
    nameTH: '💥 Plateau Breaker',
    desc: 'ผ่าน plateau 3 ครั้ง — Plateau XP penalty หมดไป',
    tier: 3,
    condition: (state) => (_countPlateausBeaten(state)) >= 3,
    effect: { plateauXPPenaltyNegated: true },
    unlockMsg: '💥 Plateau Breaker! Plateau ไม่ penalty XP อีกแล้ว',
  },
  {
    id: 'special_forces',
    name: 'Special Forces',
    nameTH: '⭐ Special Forces',
    desc: 'Level 10+ — ทุก exercise +10% Critical Chance',
    tier: 3,
    condition: (state) => (state.level || 1) >= 10,
    effect: { critBonus: 0.10 },
    unlockMsg: '⭐ Special Forces ปลดล็อก! (+10% Crit Global)',
  },
  {
    id: 'volume_titan',
    name: 'Volume Titan',
    nameTH: '🏔️ Volume Titan',
    desc: 'Total Volume เกิน 100,000 kg — XP ×1.25 + Damage ×1.15',
    tier: 3,
    condition: (state) => (state.totalVolume || 0) >= 100000,
    effect: { xpMul: 0.25, damageMul: 0.15 },
    unlockMsg: '🏔️ Volume Titan! ร่างกายระดับตำนาน',
  },
];

/* ── Helper: count exercises by muscle from history ─────── */
function _countMuscleHistory(state, muscle) {
  const hist = state.exerciseHistory || {};
  let count = 0;
  for (const [name, sessions] of Object.entries(hist)) {
    // Check if exercise is associated with muscle
    if (typeof EXERCISE_PROFILES !== 'undefined') {
      const prof = Object.entries(EXERCISE_PROFILES).find(([k]) => name.includes(k));
      if (prof && prof[1].muscles?.includes(muscle)) {
        count += sessions.length;
      }
    } else {
      count += sessions.length; // fallback count all
    }
  }
  return count;
}

/* ── Helper: count times plateaus were overcome ─────────── */
function _countPlateausBeaten(state) {
  const meta = state._meta || {};
  return meta.plateausBeaten || 0;
}

/* ============================================================
   EQUIPMENT SYSTEM (milestones → gear bonuses)
   ============================================================ */
const EQUIPMENT_DEFINITIONS = [
  {
    id: 'recruit_vest',
    name: '🪖 Recruit Vest',
    desc: 'เริ่มต้นการฝึก — XP +5%',
    condition: (state) => (state.workoutsCompleted || 0) >= 1,
    effect: { xpMul: 0.05 },
  },
  {
    id: 'operator_belt',
    name: '🎖️ Operator Belt',
    desc: 'ฝึก 25 sessions — Damage +10%',
    condition: (state) => (state.workoutsCompleted || 0) >= 25,
    effect: { damageMul: 0.10 },
  },
  {
    id: 'iron_gauntlets',
    name: '🛡️ Iron Gauntlets',
    desc: 'Volume Titan achievement — Crit ×1.5 on compound lifts',
    condition: (state) => (state.totalVolume || 0) >= 50000,
    effect: { compoundCritMul: 1.5 },
  },
  {
    id: 'elite_dog_tags',
    name: '⭐ Elite Dog Tags',
    desc: 'Level 15 — ทุก passive bonus ×1.1',
    condition: (state) => (state.level || 1) >= 15,
    effect: { globalPassiveMul: 1.10 },
  },
];

/* ============================================================
   META SYSTEM SINGLETON
   ============================================================ */
const MetaSystem = {

  /* ----------------------------------------------------------
     getMetaState — อ่าน/สร้าง meta state
  ---------------------------------------------------------- */
  getMetaState() {
    const OE = window.OPERATOR_ENGINE;
    if (!OE) return {};
    if (!OE.state._meta) {
      OE.state._meta = {
        unlockedSkills:    [],
        unlockedEquipment: [],
        plateausBeaten:    0,
        totalCrits:        0,
        totalCombos:       0,
        perfectSessions:   0,
        bossesDefeated:    0,
        gradeCount:        { S: 0, A: 0, B: 0, C: 0 },
        lastUpdated:       Date.now(),
      };
    }
    return OE.state._meta;
  },

  /* ----------------------------------------------------------
     checkUnlocks — เรียกหลัง session ทุกครั้ง
     @param sessionResult  จาก ConversionLayer
     @param engineState    OE.state
  ---------------------------------------------------------- */
  checkUnlocks(sessionResult, engineState) {
    const meta     = this.getMetaState();
    const newUnlocks = [];

    // Update stats
    meta.totalCrits   += sessionResult.critCount || 0;
    meta.totalCombos  += sessionResult.maxCombo  || 0;
    if (sessionResult.grade === 'S') {
      meta.perfectSessions++;
      meta.gradeCount.S++;
    } else if (sessionResult.grade) {
      meta.gradeCount[sessionResult.grade] = (meta.gradeCount[sessionResult.grade] || 0) + 1;
    }

    // Check boss events
    const bossEvent = (sessionResult.events || []).find(e => e.type === 'boss');
    if (bossEvent) meta.bossesDefeated++;

    // Check skill unlocks
    for (const skill of SKILL_DEFINITIONS) {
      if (!meta.unlockedSkills.includes(skill.id)) {
        try {
          if (skill.condition(engineState)) {
            meta.unlockedSkills.push(skill.id);
            newUnlocks.push({ type: 'skill', ...skill });
          }
        } catch {}
      }
    }

    // Check equipment unlocks
    for (const equip of EQUIPMENT_DEFINITIONS) {
      if (!meta.unlockedEquipment.includes(equip.id)) {
        try {
          if (equip.condition(engineState)) {
            meta.unlockedEquipment.push(equip.id);
            newUnlocks.push({ type: 'equipment', ...equip });
          }
        } catch {}
      }
    }

    meta.lastUpdated = Date.now();

    // Notify UI of new unlocks
    if (newUnlocks.length > 0) {
      this._announceUnlocks(newUnlocks);
    }

    return newUnlocks;
  },

  /* ----------------------------------------------------------
     getActiveEffects — รวม effects ทั้งหมดจาก unlocked skills
  ---------------------------------------------------------- */
  getActiveEffects() {
    const meta   = this.getMetaState();
    const OE     = window.OPERATOR_ENGINE;
    const result = {
      critBonus:           0,
      xpMul:               0,
      damageMul:           0,
      streakBonusBoost:    0,
      staminaRegen:        0,
      muscleSFRBonus:      {},
      muscleDmgBonus:      {},
      muscleXPBonus:       {},
      plateauXPPenaltyNegated: false,
      comboThresholdReduction: 0,
    };

    const activeSkills = SKILL_DEFINITIONS.filter(s => meta.unlockedSkills?.includes(s.id));
    const activeEquip  = EQUIPMENT_DEFINITIONS.filter(e => meta.unlockedEquipment?.includes(e.id));

    // Check global passive multiplier from equipment
    const globalMul = activeEquip.find(e => e.effect.globalPassiveMul)?.effect.globalPassiveMul || 1.0;

    for (const skill of activeSkills) {
      const eff = skill.effect;
      if (eff.critBonus)    result.critBonus    += eff.critBonus * globalMul;
      if (eff.xpMul)        result.xpMul        += eff.xpMul * globalMul;
      if (eff.damageMul)    result.damageMul    += eff.damageMul * globalMul;
      if (eff.streakBonusBoost) result.streakBonusBoost += eff.streakBonusBoost;
      if (eff.staminaRegen) result.staminaRegen += eff.staminaRegen;
      if (eff.plateauXPPenaltyNegated) result.plateauXPPenaltyNegated = true;
      if (eff.comboThresholdReduction) result.comboThresholdReduction += eff.comboThresholdReduction;
      if (eff.muscleSFRBonus) {
        for (const [m, v] of Object.entries(eff.muscleSFRBonus)) {
          result.muscleSFRBonus[m] = (result.muscleSFRBonus[m] || 0) + v;
        }
      }
      if (eff.muscleDmgBonus) {
        for (const [m, v] of Object.entries(eff.muscleDmgBonus)) {
          result.muscleDmgBonus[m] = (result.muscleDmgBonus[m] || 0) + v;
        }
      }
    }

    for (const equip of activeEquip) {
      const eff = equip.effect;
      if (eff.xpMul)    result.xpMul    += eff.xpMul;
      if (eff.damageMul) result.damageMul += eff.damageMul;
      if (eff.critBonus) result.critBonus += eff.critBonus;
    }

    return result;
  },

  /* ----------------------------------------------------------
     getCharacterSheet — full character summary
  ---------------------------------------------------------- */
  getCharacterSheet() {
    const OE        = window.OPERATOR_ENGINE;
    if (!OE) return null;
    const state     = OE.state;
    const meta      = this.getMetaState();
    const effects   = this.getActiveEffects();
    const classMod  = (typeof ConversionLayer !== 'undefined') ? ConversionLayer.getClassMod() : CLASS_MODIFIERS.general;
    const rank      = OE.getRank?.() || { name: 'Recruit', emoji: '🪖' };
    const phase     = OE.getCurrentPhase?.() || { nameTH: 'Base' };

    const unlockedSkillDefs  = SKILL_DEFINITIONS.filter(s => meta.unlockedSkills?.includes(s.id));
    const unlockedEquipDefs  = EQUIPMENT_DEFINITIONS.filter(e => meta.unlockedEquipment?.includes(e.id));
    const nextSkills         = SKILL_DEFINITIONS
      .filter(s => !meta.unlockedSkills?.includes(s.id))
      .slice(0, 3);

    return {
      // Identity
      rank, phase,
      level:    state.level || 1,
      class:    classMod.label,
      xp:       state.xp || 0,
      xpToNext: OE.xpToNextLevel?.() || 300,

      // Stats
      totalVolume:  state.totalVolume || 0,
      workouts:     state.workoutsCompleted || 0,
      streak:       state.streak || 0,
      readiness:    Math.round(state.readiness || 100),

      // Meta
      skills:          unlockedSkillDefs,
      equipment:       unlockedEquipDefs,
      nextSkills,
      totalCrits:      meta.totalCrits || 0,
      perfectSessions: meta.perfectSessions || 0,
      bossesDefeated:  meta.bossesDefeated || 0,
      gradeCount:      meta.gradeCount || {},

      // Active bonuses summary
      effects,
      bonusSummary: this._buildBonusSummary(effects),
    };
  },

  /* ----------------------------------------------------------
     renderMetaHUD — inject into DOM element
  ---------------------------------------------------------- */
  renderMetaHUD(containerId = 'meta-hud') {
    const el    = document.getElementById(containerId);
    if (!el) return;

    const sheet = this.getCharacterSheet();
    if (!sheet) { el.innerHTML = '<div style="color:#888">Engine not loaded</div>'; return; }

    const effects = sheet.effects;
    const skillsHTML = sheet.skills.length
      ? sheet.skills.map(s => `
          <div class="meta-skill-item">
            <span>${s.nameTH}</span>
            <span style="color:#78cc55;font-size:11px">${s.desc}</span>
          </div>`).join('')
      : '<div style="color:#555;font-size:12px">ยังไม่มี skill — ฝึกต่อไป!</div>';

    const nextHTML = sheet.nextSkills.map(s => `
      <div class="meta-skill-next">
        <span style="color:#888">${s.nameTH}</span>
        <span style="color:#555;font-size:11px">${s.desc}</span>
      </div>`).join('');

    el.innerHTML = `
      <div class="meta-hud-inner">

        <div class="meta-section">
          <div class="meta-title">⚔️ ${sheet.class} — Lv.${sheet.level}</div>
          <div class="meta-subtitle">${sheet.rank.emoji} ${sheet.rank.name} · ${sheet.phase.nameTH}</div>
        </div>

        <div class="meta-section meta-stats-row">
          <div class="meta-stat"><div class="meta-stat-val">${sheet.streak}d</div><div class="meta-stat-lbl">Streak</div></div>
          <div class="meta-stat"><div class="meta-stat-val">${sheet.totalCrits}</div><div class="meta-stat-lbl">Crits</div></div>
          <div class="meta-stat"><div class="meta-stat-val">${sheet.perfectSessions}</div><div class="meta-stat-lbl">S-Grade</div></div>
          <div class="meta-stat"><div class="meta-stat-val">${sheet.bossesDefeated}</div><div class="meta-stat-lbl">Bosses</div></div>
        </div>

        ${effects.critBonus > 0 || effects.xpMul > 0 ? `
        <div class="meta-section">
          <div class="meta-label">🎯 Active Bonuses</div>
          <div class="meta-bonus-pills">
            ${effects.critBonus > 0  ? `<span class="meta-pill crit">+${(effects.critBonus*100).toFixed(0)}% Crit</span>` : ''}
            ${effects.xpMul    > 0  ? `<span class="meta-pill xp">+${(effects.xpMul*100).toFixed(0)}% XP</span>` : ''}
            ${effects.damageMul > 0  ? `<span class="meta-pill dmg">+${(effects.damageMul*100).toFixed(0)}% DMG</span>` : ''}
            ${effects.plateauXPPenaltyNegated ? `<span class="meta-pill special">✅ No Plateau Penalty</span>` : ''}
          </div>
        </div>` : ''}

        <div class="meta-section">
          <div class="meta-label">🔓 Skills Unlocked (${sheet.skills.length}/${SKILL_DEFINITIONS.length})</div>
          <div class="meta-skills-list">${skillsHTML}</div>
        </div>

        ${sheet.nextSkills.length ? `
        <div class="meta-section">
          <div class="meta-label" style="color:#555">⏳ Next Unlocks</div>
          <div class="meta-skills-list">${nextHTML}</div>
        </div>` : ''}

      </div>`;
  },

  /* ----------------------------------------------------------
     _announceUnlocks — toast notifications for new unlocks
  ---------------------------------------------------------- */
  _announceUnlocks(unlocks) {
    unlocks.forEach((unlock, i) => {
      setTimeout(() => {
        if (typeof showToast === 'function') {
          showToast(unlock.unlockMsg || `🔓 ${unlock.nameTH || unlock.name} ปลดล็อก!`);
        }
      }, i * 1500);
    });
  },

  /* ----------------------------------------------------------
     _buildBonusSummary — human-readable summary
  ---------------------------------------------------------- */
  _buildBonusSummary(effects) {
    const parts = [];
    if (effects.critBonus > 0)         parts.push(`+${(effects.critBonus*100).toFixed(0)}% Crit`);
    if (effects.xpMul > 0)             parts.push(`+${(effects.xpMul*100).toFixed(0)}% XP`);
    if (effects.damageMul > 0)         parts.push(`+${(effects.damageMul*100).toFixed(0)}% DMG`);
    if (effects.streakBonusBoost > 0)  parts.push(`Streak ×${(1 + effects.streakBonusBoost).toFixed(2)}`);
    if (effects.plateauXPPenaltyNegated) parts.push('No Plateau Penalty');
    return parts.join(' · ') || 'ยังไม่มี bonus';
  },
};

window.MetaSystem = MetaSystem;
console.log('%c[MetaSystem] Loaded — Skill Tree & Character Sheet Active', 'color:#9b59b6;font-weight:bold');
